﻿using AutoMapper;

namespace RGI.GHIP.CoreAPIs.Common
{
    public class ModelMapperProfile : Profile
    {
        public ModelMapperProfile()
        {
        }
    }
}
