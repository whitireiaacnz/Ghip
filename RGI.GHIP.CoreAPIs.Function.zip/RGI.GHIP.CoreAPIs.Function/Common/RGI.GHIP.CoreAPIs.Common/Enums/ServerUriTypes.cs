﻿namespace RGI.GHIP.CoreAPIs.Common.Enums
{
    public enum ServerUriTypes
    {
        Test,
        Production,
    }
}
