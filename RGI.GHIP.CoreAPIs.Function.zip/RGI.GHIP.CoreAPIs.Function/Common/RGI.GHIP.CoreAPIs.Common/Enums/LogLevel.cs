﻿namespace RGI.GHIP.CoreAPIs.Common.Enums
{
    public enum LogLevel
    {
        Off,
        Error,
        Warning,
        Info,
        Verbose,
    }
}
