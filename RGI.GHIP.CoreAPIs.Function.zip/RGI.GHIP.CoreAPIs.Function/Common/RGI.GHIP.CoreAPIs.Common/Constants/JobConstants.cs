namespace RGI.GHIP.CoreAPIs.Common.Constants
{
    public static class JobConstants
    {
        public const string PROCESSING = "Processing";

        public const string COMPLETED = "Completed";

        public const string ERROR = "Error";

        public const string SUCCESS = "Success";
    }
}