﻿namespace RGI.GHIP.CoreAPIs.Common.Constants
{
    public static class MinMaxValues
    {
        public const int MININDEX = 0;
    }
}
