﻿namespace RGI.GHIP.CoreAPIs.Common.Constants.Member
{
    public static class FieldsMaster
    {
        public const string RELATIONSHIP = "Relationship";

        public const string INSUREDNAME = "Insured Name";

        public const string SUMINSURED = "Sum Insured";

        public const string EMPLOYEEID = "Employee Id";

        public const string EMAILID = "Email Id";

        public const string ALLOWDELETION = "Allow Deletion";

        public const string ISHR = "isHR";

        public const string GRADE = "Grade";

        public const string GENDER = "Gender";

        public const string DATEOFBIRTH = "Date Of Birth";

        public const string PSI = "PSI";

        public const string ESI = "ESI";

        public const string TOPUP = "Topup";

        public const string DATEOFJOINING = "Date Of Joining";
    }
}
