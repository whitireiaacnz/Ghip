﻿namespace RGI.GHIP.CoreAPIs.Common.Constants.Member
{
    public static class MemberInputType
    {
        public const string SELECT = "select";

        public const string DROPDOWN = "dropdown";

        public const string INPUT = "input";
    }
}
