﻿using System.Collections.Generic;

namespace RGI.GHIP.CoreAPIs.Common.Constants.Member
{
    public class RelationshipMaster
    {
        public const string CHILD = "Children";

        public const string SON = "Son";

        public const string SPOUSE = "Spouse";

        public const string DAUGHTER = "Daughter";

        public const string PARENT = "Parent";

        public const string PARENTINLAW = "Parent-In-Law";

        public const string FATHERINLAW = "Father-In-Law";

        public const string MOTHERINLAW = "Mother-In-Law";

        public const string MOTHER = "Mother";

        public const string FATHER = "Father";

        public const string SELF = "Self";

        public const int SELFID = 1;

        public const string DEPENDENT = "Dependent";

        public static List<string> CHILDRENTYPE = new List<string>() { SON, DAUGHTER };

        public static List<string> PARENTTYPE = new List<string>() { FATHER, MOTHER };

        public static List<string> PARENTINLAWTYPE = new List<string>() { FATHERINLAW, MOTHERINLAW };

        public static List<string> RELATIONSHIPS = new List<string>() { SPOUSE, SON, DAUGHTER, MOTHER, FATHER, FATHERINLAW, MOTHERINLAW };
    }
}
