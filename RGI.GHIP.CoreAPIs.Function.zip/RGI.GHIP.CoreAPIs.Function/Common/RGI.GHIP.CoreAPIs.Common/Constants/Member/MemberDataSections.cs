﻿namespace RGI.GHIP.CoreAPIs.Common.Constants.Member
{
    public static class MemberDataSections
    {
        public const string CONTACTS = "Contact";

        public const string PROFILE = "Profile";

        public const string EMPLOYEEDETAILS = "Employee";

        public const string COMMON = "Common";

        public const string POLICY = "Policy";

        public static readonly string[] PROFILELIST = new string[] { PROFILE, CONTACTS };
    }
}
