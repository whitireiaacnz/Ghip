﻿namespace RGI.GHIP.CoreAPIs.Common.Constants.Member
{
    public static class Roles
    {
        public const string CP = "CP";

        public const string PE = "PE";

        public const string BUSINESSADMIN = "BusinessAdmin";

        public const string HR = "HR";

        public const string MEMBER = "Member";

        public const string CPHR = "CPHR";

        public const string CPMEMBER = "CPMember";

        public const string BROKER = "Broker";

        public const string SM = "SM";

        public const int BUSINESSADMINID = 1;

        public const int HRID = 3;

        public const int MEMBERID = 2;

        public const int CPHRID = 7;

        public const int CPMEMBERID = 6;

        public const int BROKERID = 4;

        public const int SMID = 5;
    }
}
