﻿namespace RGI.GHIP.CoreAPIs.Common.Constants
{
    public static class LoggerConstants
    {
        public const string UIACTION = "UIAction";

        public const string VALIDATION = "Validation";

        public const string ERROR = "Error";

        public const string EXCEPTION = "Exception";

        public const string BACKGROUNDTASK = "BackgroundTask";
    }
}
