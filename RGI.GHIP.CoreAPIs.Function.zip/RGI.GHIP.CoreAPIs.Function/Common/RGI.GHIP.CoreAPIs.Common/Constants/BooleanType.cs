﻿using System.Collections.Generic;

namespace RGI.GHIP.CoreAPIs.Common.Constants
{
    public static class BooleanType
    {
        public static List<string> TRUE = new List<string>() { "True", "Yes" };

        public static List<string> FALSE = new List<string>() { "False", "No" };
    }
}
