﻿using System.Collections.Generic;

namespace RGI.GHIP.CoreAPIs.Common.Constants.CorporatePortal
{
    public static class CredentialConstants
    {
        public static readonly string DATEOFBIRTH = "Date of Birth";

        public static readonly string EMPLOYEEID = "Employee Id";

        public static readonly string SYSTEMGENERATED = "System-generated";

        public static readonly string HEALTHID = "Health Id";

        public static readonly string EMPLOYEEIDCOPORATECODE = "EmployeeId@CorporateShortName";

        public static readonly string EMAILID = "Email ID";

        public static readonly List<string> PASSWORDTYPE = new List<string>() { DATEOFBIRTH, EMPLOYEEID, SYSTEMGENERATED };

        public static readonly List<string> USERNAMETYPE = new List<string>() { HEALTHID, EMPLOYEEIDCOPORATECODE, EMAILID };
    }
}
