﻿using System.Collections.Generic;

namespace RGI.GHIP.CoreAPIs.Common.Constants.CorporatePortal
{
    public static class DocumentConstants
    {
        public static readonly List<string> DOCUMENTTYPE = new List<string>() { "Claims", "Enrollment", "Policy", "Others" };
    }
}
