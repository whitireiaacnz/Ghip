using System.Collections.Generic;

namespace RGI.GHIP.CoreAPIs.Common.Constants.CorporatePortal
{
    public static class CPPolicyGracePeriodConstant
    {
        public static readonly string WEEK = "Week";

        public static readonly string MONTH = "Month";

        public static readonly string YEAR = "Year";

        public static readonly List<string> GRACEPERIODTYPE = new List<string>() { WEEK, MONTH, YEAR };
    }
}