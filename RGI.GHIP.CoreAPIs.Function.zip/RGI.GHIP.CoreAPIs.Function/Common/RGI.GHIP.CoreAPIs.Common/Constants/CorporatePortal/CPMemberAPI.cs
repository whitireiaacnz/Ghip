﻿namespace RGI.GHIP.CoreAPIs.Common.Constants.CorporatePortal
{
    public class CPMemberAPI
    {
        public static string BASEURL = Config.RGIAPI.BASEURL;

        public static string CORPORATEBASEURL = Config.RGIAPI.BASEURL + "corporateportalapi/";

        public static string AUTHORISATIONKEY = Config.RGIAPI.AUTHORISATIONKEY;

        public static string GETMEMBERFAMILY = CORPORATEBASEURL + "GetFamilyDetails";
    }
}
