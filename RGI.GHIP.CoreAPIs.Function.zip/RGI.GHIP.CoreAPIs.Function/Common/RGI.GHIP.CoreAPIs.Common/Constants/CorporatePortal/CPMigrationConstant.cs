﻿namespace RGI.GHIP.CoreAPIs.Common.Constants.CorporatePortal
{
    public class CPMigrationConstant
    {
        public static string WelcomeEmailTemplate = "<p><span style=\"font-family: Arial, Helvetica, sans-serif; " +
        "color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\"><span class=\"il\">Dear</span>&nbsp;" +
        "<span class=\"il\">Member</span>&nbsp;,&nbsp;</span><br style=\"font-family: Arial, Helvetica, sans-serif; " +
        "color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\" /><br style=\"font-family: Arial, " +
        "Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\" />" +
        "<span style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size:14.6667px;" +
        " background-color: #ffffff;\">Greetings from </span><span style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e;font-weight:bold; font-size:14.6667px; background-color: #ffffff;\"> Reliance General Insurance!</span><br style=\"font-family: Arial, " +
        "Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\" />" +
        "<br style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px;" +
        " background-color: #ffffff;\" /><span style=\"font-family: Arial, Helvetica, sans-serif; " +
        "color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\">" +
        "We hope you are doing safe and keeping healthy!.&nbsp;" +
        "</span><br style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px; " +
        "background-color: #ffffff;\" /><br style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e;" +
        " font-size: 14.6667px; background-color: #ffffff;\" /><span style=\"font-family: Arial," +
        " Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\">" +
        "It is our honor & privilege to associate with you as your trusted service provider. We are delighted to welcome you to our Reliance Family.&nbsp;</span>" +
        "<br style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px; " +
        "background-color: #ffffff;\" /><span style=\"font-family: Arial, Helvetica, sans-serif;" +
        " color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\">" +
        "</span><br style=\"font-family: Arial, Helvetica, sans-serif;" +
        " color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\" />" +
        "<span style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\">" +
        "In this technology revolution era, we urge you to <span style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e;font-weight:bold; font-style: italic; font-size: 14.6667px; background-color: #ffffff;\">GO Digital# Empower Yourself & Others!! </span>Access all the information on your finger tips. </span>" +
        "<br style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\" />" +
        "<span style=\"font-family: Arial, Helvetica,sans-serif; font-style: italic; font-weight: bold; color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\">Let’s begin this journey with YOU!!" +
        " </span><br style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\" />" +
        "<span style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\">" +
        " </span>" +
         "<br style=\"font-family: Arial, Helvetica, sans-serif;" +
        " color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\" />" +
        "<span style=\"font-family: Arial, Helvetica,sans-serif; color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\">A new, unique & employee-friendly portal which we introduce to you as <span style=\"font-family: Arial, Helvetica,sans-serif; color: #2196F3; font-size: 14.6667px; background-color: #ffffff;\">‘’Corporate Portal’’ </span>" +
       "<br style=\"font-family: Arial, Helvetica, sans-serif;color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\" /> is designed with a single sign on feature using AD logins. </span>" +
         "<br style=\"font-family: Arial, Helvetica, sans-serif;" +
        " color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\" />" +
        "<span style=\"font-family: Arial, Helvetica, sans-serif; font-style: italic; font-weight: bold; color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\">What makes it a unique portal? </span>" +
        "<br style=\"font-family: Arial, Helvetica, sans-serif;" +
        " color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\" />" +
        "<span style=\"font-family: Arial, Helvetica,sans-serif; color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\">The availability of end to end claim processing lifecycle features like. </span>" +
        "<br style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\" /><br style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\" /><span style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Download Health card&nbsp;</span><br style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\" /><span style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Locate Network provider</span>" +
        "<br style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\" /><span style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Intimate claim & upload documents,</span><br style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\" /><span style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Check claim status</span><br style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\" /><br style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\" />" +
        "<span style=\"font-family: Arial, Helvetica, sans-serif; font-style: italic; font-weight: bold; color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\">How to access your 'Rcare Customer portal’?:&nbsp;</span>" +
        "<br style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\" />" +
        "<span style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\">Step 1: click on&nbsp;</span>" +
        "{LoginURL}<span style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\">" +
        "&nbsp;to login to your account</span><br style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\" />" +
        "<span style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\">Step 2: Login with your credentials</span>" +
        "<br style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px;" +
        " background-color: #ffffff;\" /><span style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\">" +
        "Login ID:{UserName}</span>" +
        "<br style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\" /><span style=\"font-family: Arial, Helvetica, sans-serif;" +
        " margin: 0px; font-size: 14.6667px; color: #201f1e;" +
        " background-color: #ffffff;\">Password</span>" +
        "<span style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\">:" +
        "</span><span style=\"font-family: Arial, Helvetica, sans-serif; margin: 0px; font-size: 14.6667px; color: #201f1e; background-color: #ffffff;\">" +
        "{Password}</span>" +
         "<br style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px;" +
        " background-color: #ffffff;\" />" +
        "<br style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px;" +
        " background-color: #ffffff;\" /><span style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\"><span style=\"font-family: Arial, Helvetica, sans-serif;font-weight: bold; color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\"> Note: </span> If you are unable to log in please reset it with ‘Forgot Password’ option and new password will be received on your e-mail. ,</span>" +
        "<br style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px;" +
        " background-color: #ffffff;\" /><span style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\">Important: Please check (ü) ‘Log-in as Employee’</span>" +
        "<br style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px;" +
        " background-color: #ffffff;\" /><span style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\">We have created corporate portal logins for you, please login & access the unique features.</span>" +
        "<br style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px;" +
        " background-color: #ffffff;\" /><span style=\"font-family: Arial, Helvetica, sans-serif; font-style: italic; font-weight: bold; color: #2196F3; font-size: 14.6667px; background-color: #ffffff;\">Process</span>" +
        "<br style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px;" +
        " background-color: #ffffff;\" /><span style=\"font-family: Arial, Helvetica, sans-serif;font-style: italic;font-weight: bold; color: #c74212; font-size: 14.6667px; background-color: #ffffff;\">" +
        "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Cashless Process:</span>" +
        "<span style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\"> Employees can take print out of the e-cards and avail Cashless benefit at our Network Hospitals and if the hospital is Non-Network the employee can apply for Claim Reimbursement.</span>" +
         "<br style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px;" +
        " background-color: #ffffff;\" /><span style=\"font-family: Arial, Helvetica, sans-serif;font-style: italic;font-weight: bold; color: #c74212; font-size: 14.6667px; background-color: #ffffff;\">" +
        "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Reimbursement Process:</span>" +
        "<span style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\"> Employees can avail treatment from Non Network hospital & post discharge they can apply for reimbursement process.</span>" +
        "<br style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px;" +
        " background-color: #ffffff;\" /><span style=\"font-family: Arial, Helvetica,sans-serif;font-style: italic; font-weight: bold; color: #201f1e; font-size: 10px; background-color: #ffffff;\">" +
        "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Kindly submit the mandatory documents within 30 days from the date of discharge</span>" +
        "<br style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\" />" +
        "<br style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\" />" +
        "<span style=\"font-family: Arial, Helvetica, sans-serif; color: #2196F3;font-style: italic;font-weight: bold; font-size: 14.6667px; background-color: #ffffff;\"> Point of Contact:.</span>" +
        "<br style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\" />" +
        "<span style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\"> <table style=border-collapse: collapse; width: 100%; height: 63px; border=1> <tbody>" +
        "<tr style=height: 21px;>" + "<td style=width: 63.2188px; height: 21px; > Employees to Contact</td></tr> " +
          "<tr style=height: 21px;><td style=width: 105.219px; height: 21px;> &nbsp;Toll-Free number: 1800-3009</td>" +
          "</tr><tr style=height: 21px;> <td style=width: 105.219px; height: 21px;> &nbsp;E-mail ID:rgicl.rcarehealth@relianceada.com 1800-3009</td></tr> </tbody>" +
          "</table> </span>" +
         "<br style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px;" +
        " background-color: #ffffff;\" /><span style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e;" +
         "font-size: 14.6667px; background-color: #ffffff;\"><span style=\"font-family: Arial, Helvetica, sans-serif; color: #c74212;font-size: 15.6667px;font-weight: bold;font-style: italic; background-color: #ffffff;\">Self-i</span>, Single Mobile app for multiple transactions; Do Insurance Yourself!!" +
         "<br style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\" />" +
         "<br style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px;" +
        "background-color: #ffffff;\" /><span style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\">Click & Download our Mobile app Self-i app http://onelink.to/ep5mb4</span>" +
        "<br style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px;" +
        " background-color: #ffffff;\" /><span style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e;" + "font-size: 14.6667px; background-color: #ffffff;\">Know more about Self-i https://www.youtube.com/watch?v=V9leo48fy8M&feature=youtu.be</span>" +
        "<br style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px;" +
        " background-color: #ffffff;\" />" +
        "<br style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px;" +
        " background-color: #ffffff;\" /><span style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e;font-weight: bold; font-size: 14.6667px; background-color: #ffffff;\"> Assuring you best of our services. </span>" +
        "<br style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px;" +
        " background-color: #ffffff;\" />" +
        "<br style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px;" +
        " background-color: #ffffff;\" /><span style=\"font-family: Arial, Helvetica, sans-serif; color: #2196F3;font-weight: bold;font-style: italic; font-size: 14.6667px; background-color: #ffffff;\">#RegularlyExercise #StayFit #StayHealthy!!</span>" +
       "<br style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px;" +
        " background-color: #ffffff;\" />" +
        "<br style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px;" +
        " background-color: #ffffff;\" /><span style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px; background-color: #ffffff;\"> Warm Regards,</span>" +
         "<br style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e; font-size: 14.6667px;" +
        " background-color: #ffffff;\" /><span style=\"font-family: Arial, Helvetica, sans-serif; color: #201f1e;font-weight: bold; font-size: 14.6667px; background-color: #ffffff;\">RCare Health </span></p>";
    }
}
