﻿using System.Collections.Generic;

namespace RGI.GHIP.CoreAPIs.Common.Constants.CorporatePortal
{
    public static class EndorsementConstant
    {
        public const string ADDITION = "Addition";

        public const string MODIFICATION = "Modification";

        public const string DELETION = "Deletion";

        public const string FRESHENROLLMENT = "FreshEnrollement";

        public static List<string> LIST = new List<string>() { MODIFICATION, ADDITION, DELETION, FRESHENROLLMENT };
    }
}
