﻿using System.Collections.Generic;

namespace RGI.GHIP.CoreAPIs.Common.Constants
{
    // Define all custom policies
    public static class GhipPolicies
    {
        public const string ROLES = "Role";

        public static IEnumerable<string> Get()
        {
            yield return ROLES;
        }
    }
}
