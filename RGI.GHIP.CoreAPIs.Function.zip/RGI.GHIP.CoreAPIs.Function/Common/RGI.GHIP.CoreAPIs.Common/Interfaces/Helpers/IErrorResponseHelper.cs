﻿using System.Collections.Generic;
using FluentValidation.Results;
using Microsoft.AspNetCore.Mvc;
using RGI.GHIP.CoreAPIs.Common.Validators;

namespace RGI.GHIP.CoreAPIs.Common.Interfaces.Helpers
{
    public interface IErrorResponseHelper
    {
        List<ErrorResponseModel> GetErrorResponseModel(List<ErrorModel> errors);

        List<ErrorResponseModel> GetErrorResponseModel(List<ValidationResult> validationResults);

        List<ErrorResponseModel> GetErrorResponseModel(ValidationResult validationResults);

        List<ErrorResponseModel> GetErrorResponseModel(string errorMessage, string propertyName);

        List<ErrorResponseModel> GetErrorResponseModel(IActionResult actionResult, string propertyName);
    }
}
