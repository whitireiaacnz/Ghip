﻿namespace RGI.GHIP.CoreAPIs.Common.Interfaces.Helpers
{
    public interface IConversionHelper
    {
        string GetValueFromObject(object obj, string propertyName);
    }
}
