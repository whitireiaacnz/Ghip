﻿using System;

namespace RGI.GHIP.CoreAPIs.Common.Interfaces.Helpers
{
    public interface IDateHelper
    {
        int GetAgeFromDOB(DateTime dateOfBirth);

        DateTime GetDateFromOA(double dateOA);

        DateTime GetCurrentDateUtcNow();
    }
}
