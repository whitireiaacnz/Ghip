﻿using System;
using System.Runtime.CompilerServices;
using Microsoft.AspNetCore.Http;

namespace RGI.GHIP.CoreAPIs.Common.Interfaces.Logging
{
    public interface ILogger
    {
        void Init();

        void Info(
            string message,
            [CallerMemberName] string memberName = "",
            [CallerFilePath] string sourceFilePath = "",
            object data = null,
            string[] tags = null,
            [CallerLineNumber] int sourceLineNumber = 0);

        void APIInfo(
        HttpContext httpContext,
        [CallerMemberName] string memberName = "",
        [CallerFilePath] string sourceFilePath = "",
        object data = null,
        string[] tags = null,
        [CallerLineNumber] int sourceLineNumber = 0);

        void Error(
            Exception e,
            object data = null,
            string[] tags = null,
            [CallerMemberName] string memberName = "",
            [CallerFilePath] string sourceFilePath = "",
            [CallerLineNumber] int sourceLineNumber = 0);

        void LogApiData(
            string apiData,
            object data = null,
            [CallerMemberName] string memberName = "",
            [CallerFilePath] string sourceFilePath = "",
            [CallerLineNumber] int sourceLineNumber = 0,
            string[] tags = null);

        void Error(
            string e,
            object data = null,
            string[] tags = null,
            [CallerMemberName] string memberName = "",
            [CallerFilePath] string sourceFilePath = "",
            [CallerLineNumber] int sourceLineNumber = 0);
    }
}