using Microsoft.AspNetCore.Http;

namespace RGI.GHIP.CoreAPIs.Common.Interfaces.Utility
{
    public interface IFileValidationUtility
    {
        public void ValidateIncomingFile(IFormFile file, string extension);
    }
}