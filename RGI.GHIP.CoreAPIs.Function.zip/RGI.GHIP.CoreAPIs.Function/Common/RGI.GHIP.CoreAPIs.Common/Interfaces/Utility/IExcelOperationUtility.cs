﻿using System.IO;
using ClosedXML.Excel;
using Microsoft.AspNetCore.Http;

namespace RGI.GHIP.CoreAPIs.Common.Interfaces.Utility
{
    public interface IExcelOperationUtility
    {
        IXLWorksheets ReadExcel(Stream stream);

        public IXLWorksheets ReadExcel(IFormFile file);
    }
}