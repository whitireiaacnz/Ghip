﻿namespace RGI.GHIP.CoreAPIs.Common.Interfaces.Utility
{
    public interface IRandomValueGenerator
    {
        string CreateRandomPasswordWithRandomLength();

        string KeyGenerator();

        string GenerateUId(int length);
    }
}
