﻿using Microsoft.AspNetCore.Mvc;
using RGI.GHIP.CoreAPIs.Common.Models;
using RGI.GHIP.CoreAPIs.Common.Models.Email;

namespace RGI.GHIP.CoreAPIs.Common.Interfaces.Utility
{
    public interface ISendEmailUtility
    {
        public IActionResult SendEmailWithApi(EmailModel emailModel);

        public IActionResult SendSMSWithApi(SMSSendModel smsModel);
    }
}
