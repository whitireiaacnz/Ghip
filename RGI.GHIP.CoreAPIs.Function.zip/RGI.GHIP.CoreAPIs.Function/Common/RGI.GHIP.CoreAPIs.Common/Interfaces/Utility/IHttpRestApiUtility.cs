﻿namespace RGI.GHIP.CoreAPIs.Common.Interfaces.Utility
{
    public interface IHttpRestApiUtility
    {
        public TResponse GetResponse<TResponse>(string url, string authorisation = null, string key = "Output");

        public TResponseBody PostResponse<TRequestBody, TResponseBody>(string url, TRequestBody body, string authorisation = null, string key = "Output");
    }
}
