namespace RGI.GHIP.CoreAPIs.Common.Interfaces.Utility
{
    public interface IDynamicVariableUtility
    {
        public string ReplaceDynamicVariables<T>(T model, string template);

        public string GetPlainTextEmail(string template);
    }
}