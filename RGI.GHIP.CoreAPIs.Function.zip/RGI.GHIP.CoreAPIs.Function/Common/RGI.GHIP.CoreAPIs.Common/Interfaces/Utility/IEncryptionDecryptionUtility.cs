﻿namespace RGI.GHIP.CoreAPIs.Common.Interfaces.Utility
{
    public interface IEncryptionDecryptionUtility
    {
        public string DecryptPBKDF2(string cipherText, string password);

        public string EncryptAES(string plainText, string key);

        public string EncryptStringSymmetric(string plainText, byte[] key, byte[] iv);

        public string EncryptText(string key, string plainText);

        public string DecryptText(string key, string cipherText);
    }
}
