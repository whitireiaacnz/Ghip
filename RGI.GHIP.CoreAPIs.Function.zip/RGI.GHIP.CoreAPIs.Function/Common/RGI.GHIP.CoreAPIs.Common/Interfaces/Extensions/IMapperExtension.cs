﻿using System.Collections.Generic;

namespace RGI.GHIP.CoreAPIs.Common.Interfaces.IMapper
{
    public interface IMapperExtension
    {
        TDestination MapObjectTo<TDestination>(object source);

        List<TDestination> MapListTo<TDestination, TSource>(List<TSource> sourceList);

        TDestination MapToExisting<TDestination, TSource>(TDestination destination, TSource source);

        TMemberModel MapJsonToModel<TMemberModel>(string fieldsJson);
    }
}
