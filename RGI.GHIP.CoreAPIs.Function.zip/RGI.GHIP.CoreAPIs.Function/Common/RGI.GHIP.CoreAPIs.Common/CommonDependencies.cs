﻿using Microsoft.Extensions.DependencyInjection;
using RGI.GHIP.CoreAPIs.Common.Helpers;
using RGI.GHIP.CoreAPIs.Common.Interfaces;
using RGI.GHIP.CoreAPIs.Common.Interfaces.Helpers;
using RGI.GHIP.CoreAPIs.Common.Interfaces.IMapper;
using RGI.GHIP.CoreAPIs.Common.Interfaces.Logging;
using RGI.GHIP.CoreAPIs.Common.Interfaces.Utility;
using RGI.GHIP.CoreAPIs.Common.Logging;
using RGI.GHIP.CoreAPIs.Common.Mapper;
using RGI.GHIP.CoreAPIs.Common.Utility;

namespace RGI.GHIP.CoreAPIs.Common
{
    public static class CommonDependencies
    {
        public static void Initialize(IServiceCollection services)
        {
            RegisterLogger(services);

            RegisterUtility(services);

            RegisterHelpers(services);

            RegisterExtensions(services);
        }

        private static void RegisterExtensions(IServiceCollection services)
        {
            services.AddTransient<IMapperExtension, MapperExtension>();
        }

        private static void RegisterLogger(IServiceCollection services)
        {
            services.AddTransient<ILogger, Logger>();
            services.AddTransient<IStackFrameHelper, StackFrameHelper>();
            services.AddTransient<ISeriLogger, SeriLogger>();
            services.AddApplicationInsightsTelemetry();
        }

        private static void RegisterUtility(IServiceCollection services)
        {
            services.AddTransient<IExcelOperationUtility, ExcelOperationUtility>();
            services.AddTransient<IRandomValueGenerator, RandomValueGenerator>();
            services.AddTransient<ISendEmailUtility, SendEmailUtility>();
            services.AddTransient<IHttpRestApiUtility, HttpRestApiUtility>();
            services.AddTransient<IEncryptionDecryptionUtility, EncryptionDecryptionUtility>();
            services.AddTransient<IDynamicVariableUtility, DynamicVariableUtility>();
            services.AddTransient<IFileValidationUtility, FileValidationUtility>();
        }

        private static void RegisterHelpers(IServiceCollection services)
        {
            services.AddTransient<IDateHelper, DateHelper>();
            services.AddTransient<IErrorResponseHelper, ErrorResponseHelper>();
            services.AddTransient<IConversionHelper, ConversionHelper>();
        }
    }
}
