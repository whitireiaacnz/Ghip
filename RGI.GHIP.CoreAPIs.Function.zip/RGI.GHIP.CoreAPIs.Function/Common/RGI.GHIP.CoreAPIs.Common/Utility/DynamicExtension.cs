﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;

namespace RGI.GHIP.CoreAPIs.Common.Utility
{
    public static class DynamicExtension
    {
        private const string REGEXPATTERNFORPROPERTYNAME = @"^({PropertyName})[\d]*$";

        public static ExpandoObject ToDynamic(this object obj)
        {
            // Add Them to a new Expando
            ExpandoObject expando = new ExpandoObject();
            return Merge(expando, obj);
        }

        public static ExpandoObject ToDynamic(this IDictionary<string, object> dictionary)
        {
            var expando = new ExpandoObject();
            var expandoDic = (IDictionary<string, object>)expando;

            // go through the items in the dictionary and copy over the key value pairs)
            foreach (var kvp in dictionary)
            {
                // if the value can also be turned into an ExpandoObject, then do it!
                if (kvp.Value is IDictionary<string, object>)
                {
                    var expandoValue = ((IDictionary<string, object>)kvp.Value).ToDynamic();
                    expandoDic.Add(kvp.Key, expandoValue);
                }
                else if (kvp.Value is ICollection)
                {
                    // iterate through the collection and convert any string-object dictionaries
                    // along the way into expando objects
                    var itemList = new List<object>();
                    foreach (var item in (ICollection)kvp.Value)
                    {
                        if (item is IDictionary<string, object>)
                        {
                            var expandoItem = ((IDictionary<string, object>)item).ToDynamic();
                            itemList.Add(expandoItem);
                        }
                        else
                        {
                            itemList.Add(item);
                        }
                    }

                    expandoDic.Add(kvp.Key, itemList);
                }
                else
                {
                    expandoDic.Add(kvp);
                }
            }

            return expando;
        }

        public static ExpandoObject Merge(ExpandoObject expandoObject, object otherObject)
        {
            if (expandoObject == null)
            {
                throw new ArgumentNullException(nameof(expandoObject));
            }

            if (otherObject == null)
            {
                throw new ArgumentNullException(nameof(otherObject));
            }

            // Get Properties Using Reflections
            if (otherObject is ExpandoObject)
            {
                var keyValuePairs = ((ExpandoObject)otherObject).AsEnumerable();
                foreach (KeyValuePair<string, object> property in keyValuePairs)
                {
                    expandoObject = AddProperty(expandoObject, property.Key, property.Value);
                }
            }
            else
            {
                BindingFlags flags = BindingFlags.Public | BindingFlags.Instance;
                PropertyInfo[] properties = otherObject.GetType().GetProperties(flags);

                // Add other object properties into expando object.
                foreach (PropertyInfo property in properties)
                {
                    expandoObject = AddProperty(expandoObject, property.Name, property.GetValue(otherObject));
                }
            }

            return expandoObject;
        }

        public static ExpandoObject AddProperty(ExpandoObject expandoObject, string propertyName, object propertyValue)
        {
            if (expandoObject == null)
            {
                throw new ArgumentNullException(nameof(expandoObject));
            }

            if (string.IsNullOrEmpty(propertyName))
            {
                throw new ArgumentNullException(nameof(propertyName), "Property name can not be empty or null");
            }

            if (propertyValue == null || string.IsNullOrEmpty(propertyValue.ToString()))
            {
                return expandoObject;
            }

            // Take use of the IDictionary implementation
            var expandoDict = expandoObject as IDictionary<string, object>;

            // if dynamic object already contains same property then it will add number after property name,
            // like if there is TagUuid property already exists and user try to add it again then it name should be TagUuid1 and so on.
            if (expandoDict.ContainsKey(propertyName))
            {
                if (expandoDict[propertyName] == null || string.IsNullOrEmpty(expandoDict[propertyName].ToString()))
                {
                    expandoDict[propertyName] = propertyValue;
                }
                else if (expandoDict[propertyName] != propertyValue)
                {
                    string pattern = REGEXPATTERNFORPROPERTYNAME.Replace("{PropertyName}", propertyName);
                    var matchedProperties =
                        expandoDict.Where(x => Regex.IsMatch(x.Key, pattern, RegexOptions.IgnoreCase));
                    propertyName = $"{propertyName}{matchedProperties.Count()}";
                }
            }

            expandoDict.Add(propertyName, propertyValue);

            return expandoDict as ExpandoObject;
        }
    }
}
