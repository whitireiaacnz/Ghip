using System;
using System.Reflection;
using RGI.GHIP.CoreAPIs.Common.Extensions;
using RGI.GHIP.CoreAPIs.Common.Interfaces.Utility;

namespace RGI.GHIP.CoreAPIs.Common.Utility
{
    public class DynamicVariableUtility : IDynamicVariableUtility
    {
        public string ReplaceDynamicVariables<T>(T model, string template)
        {
            string val = template;
            foreach (PropertyInfo property in model.GetType().GetProperties())
            {
                var value = property.GetValue(model);

                if (property.PropertyType.FullName == "System.DateTime")
                {
                    val = val.Replace("{" + property.Name + "}", DateTime.Parse(value.ToString()).Getddmmmyyyy());
                    continue;
                }

                if (value != null)
                {
                    val = val.Replace("{" + property.Name + "}", value.ToString());
                }
            }

            return val;
        }

        public string GetPlainTextEmail(string template)
        {
            string plainEmail = template.Replace("{", " ").Replace("}", " ");

            return plainEmail;
        }
    }
}