﻿using Microsoft.AspNetCore.Mvc;
using RestSharp;
using RGI.GHIP.CoreAPIs.Common.Interfaces.Utility;
using RGI.GHIP.CoreAPIs.Common.Models;
using RGI.GHIP.CoreAPIs.Common.Models.Email;

namespace RGI.GHIP.CoreAPIs.Common.Utility
{
    public class SendEmailUtility : ISendEmailUtility
    {
        public IActionResult SendEmailWithApi(EmailModel emailModel)
        {
            string url = Config.EmailSendApi;
            RestClient client = new RestClient(url);
            var request = new RestRequest(Method.POST);
            request.AddHeader("api_key", Config.EmailSendApiKey);
            request.AddHeader("Content-Type", "application/json");
            request.AddJsonBody(Newtonsoft.Json.JsonConvert.SerializeObject(emailModel));
            IRestResponse response = client.Execute(request);

            if (response.StatusCode.ToString() == "Accepted")
            {
                return new OkResult();
            }
            else
            {
                return new BadRequestObjectResult(response.Content);
            }
        }

        public IActionResult SendSMSWithApi(SMSSendModel smsModel)
        {
            if (string.IsNullOrEmpty(smsModel.MobileNumber) || string.IsNullOrWhiteSpace(smsModel.MobileNumber))
            {
                return new BadRequestObjectResult("Mobile no. cannot be empty.");
            }

            string url = Config.SMSSendApi;
            RestClient client = new RestClient(url);
            var request = new RestRequest(Method.POST);
            request.AddHeader("Authorization", Config.SMSSendApiKey);
            request.AddHeader("Content-Type", "application/json");
            request.AddJsonBody(Newtonsoft.Json.JsonConvert.SerializeObject(smsModel));
            IRestResponse response = client.Execute(request);

            bool isSuccess = false;

            Newtonsoft.Json.Linq.JObject obj = new Newtonsoft.Json.Linq.JObject();
            try
            {
                obj = Newtonsoft.Json.Linq.JObject.Parse(response.Content);
                if (obj["status"].ToString() == "Failure")
                {
                    isSuccess = false;
                }

                if (obj["status"].ToString() == "Success")
                {
                    isSuccess = true;
                }
            }
            catch (System.Exception)
            {
            }

            if (response.StatusCode.ToString() == "OK" && isSuccess)
            {
                return new OkObjectResult(obj["smsTokenId"].ToString());
            }
            else
            {
                return new BadRequestObjectResult(response.Content);
            }
        }
    }
}
