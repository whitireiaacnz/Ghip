using System;
using System.Collections.Generic;

namespace RGI.GHIP.CoreAPIs.Common.Utility
{
    public static class SessionManager
    {
        private static readonly Dictionary<string, DateTime> expiredAccessTokens = new Dictionary<string, DateTime>();

        public static void ExpireToken(string accessToken)
        {
            expiredAccessTokens.Add(accessToken, DateTime.Now);
        }

        public static bool IsTokenExpired(string accessToken)
        {
            return expiredAccessTokens.ContainsKey(accessToken);
        }
    }
}