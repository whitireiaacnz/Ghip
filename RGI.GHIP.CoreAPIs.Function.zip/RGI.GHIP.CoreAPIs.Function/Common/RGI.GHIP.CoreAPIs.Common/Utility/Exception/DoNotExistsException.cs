﻿using System;

namespace RGI.GHIP.CoreAPIs.Common.Utility
{
    public class DoNotExistsException : Exception
    {
        public DoNotExistsException(string? message = "Do not exists")
        : base(message)
        {
        }

        public DoNotExistsException(string message, Exception innerException)
        : base(message, innerException)
        {
        }
    }
}
