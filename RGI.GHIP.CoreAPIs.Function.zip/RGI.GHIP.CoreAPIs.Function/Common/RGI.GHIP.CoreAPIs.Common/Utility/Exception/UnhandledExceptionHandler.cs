﻿using System;
using System.Threading.Tasks;
using RGI.GHIP.CoreAPIs.Common.Constants;
using RGI.GHIP.CoreAPIs.Common.Interfaces;

namespace RGI.GHIP.CoreAPIs.Common.Utility
{
    public class UnhandledExceptionHandler
    {
        private static bool _isExceptionHandlingConfigured = false;
        private static bool _shouldSwallowUnhanldedException = false;
        private readonly ISeriLogger _seriLogger;

        public UnhandledExceptionHandler(ISeriLogger seriLogger)
        {
            _seriLogger = seriLogger;
        }

        public bool IsExceptionHandlingConfigures => _isExceptionHandlingConfigured;

        public void ConfigureUnhandledExceptionHandler(bool shouldSwallowUnhandledException)
        {
            if (_isExceptionHandlingConfigured)
            {
                throw new ApplicationException("Exception handling already initialized");
            }

            _shouldSwallowUnhanldedException = shouldSwallowUnhandledException;
            AppDomain.CurrentDomain.UnhandledException += CurrentDomain_UnhandledException;
            TaskScheduler.UnobservedTaskException += TaskScheduler_UnobservedTaskException;
            _isExceptionHandlingConfigured = true;
        }

        private void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            // ISeriLogger seriLogger = ContainerManager.Container.Resolve<ISeriLogger>();
            Exception exception = e.ExceptionObject as Exception;
            _seriLogger.Exception(exception, message: "Main domain unhandled exception", tags: new[] { LoggerConstants.EXCEPTION });

            if (!_shouldSwallowUnhanldedException)
            {
                throw exception;
            }
        }

        private void TaskScheduler_UnobservedTaskException(object sender, UnobservedTaskExceptionEventArgs e)
        {
            // ISeriLogger seriLogger = ContainerManager.Container.Resolve<ISeriLogger>();
            _seriLogger.Exception(e.Exception, message: "TaskScheduler unobsorved exception", tags: new[] { LoggerConstants.EXCEPTION });

            if (!_shouldSwallowUnhanldedException)
            {
                throw e.Exception;
            }
        }
    }
}
