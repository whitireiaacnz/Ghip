﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using RGI.GHIP.CoreAPIs.Common.Validators;

namespace RGI.GHIP.CoreAPIs.Common.Utility
{
    [Serializable]
    public class MemberException : Exception
    {
        public MemberException()
        {
        }

        public MemberException(string message)
            : base(message)
        {
        }

        public MemberException(List<ErrorModel> errors)
        {
            Errors = errors;
        }

        public MemberException(List<ErrorResponseModel> errors)
        {
            ErrorModels = errors;
        }

        public MemberException(string message, string messageType)
        : base(message)
        {
            MessageType = messageType;
        }

        public MemberException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        protected MemberException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        public virtual List<ErrorModel> Errors { get; }

        public virtual List<ErrorResponseModel> ErrorModels { get; }

        public virtual string MessageType { get; }
    }
}
