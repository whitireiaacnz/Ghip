﻿using System;
using System.Collections.Generic;
using FluentValidation.Results;
using RGI.GHIP.CoreAPIs.Common.Validators;

namespace RGI.GHIP.CoreAPIs.Common.Utility
{
    public class CustomExceptionJson : Exception
    {
        public CustomExceptionJson(IList<ValidationFailure> validationFailures)
        {
            var errorResponse = new ErrorResponseModel();
            foreach (var error in validationFailures)
            {
                var errorModel = new ErrorModel
                {
                    FieldName = error.PropertyName,
                    Message = error.ErrorMessage,
                };

                errorResponse.Errors.Add(errorModel);
            }

            ErrorResponse = errorResponse;
        }

        public CustomExceptionJson(string message)
        {
            var errorResponse = new ErrorResponseModel();
            var errorModel = new ErrorModel
            {
                FieldName = string.Empty,
                Message = message,
            };

            errorResponse.Errors.Add(errorModel);

            ErrorResponse = errorResponse;
        }

        public CustomExceptionJson(string fieldName, string message)
        {
            var errorResponse = new ErrorResponseModel();
            var errorModel = new ErrorModel
            {
                FieldName = fieldName,
                Message = message,
            };

            errorResponse.Errors.Add(errorModel);

            ErrorResponse = errorResponse;
        }

        public virtual ErrorResponseModel ErrorResponse { get; }
    }
}
