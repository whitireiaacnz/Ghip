﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using RGI.GHIP.CoreAPIs.Common.Interfaces.Logging;
using RGI.GHIP.CoreAPIs.Common.Models;
using RGI.GHIP.CoreAPIs.Common.Utility;
using RGI.GHIP.CoreAPIs.Common.Validators;

namespace RGI.GHIP.CoreAPIs.Utility
{
    public class GlobalExceptionHandler
    {
        private readonly RequestDelegate _next;
        private readonly ILogger _logger;

        public GlobalExceptionHandler(
            RequestDelegate next,
            ILogger logger)
        {
            _logger = logger;
            _next = next;
        }

        public async Task InvokeAsync(HttpContext httpContext)
        {
            try
            {
                await _next(httpContext);
            }
            catch (MemberException ex)
            {
                _logger.Error($"Something went wrong: {ex}");
                await HandleMemberExceptionAsync(httpContext, ex);
            }
            catch (CustomException ex)
            {
                _logger.Error($"Something went wrong: {ex}");
                await HandleCustomExceptionAsync(httpContext, ex);
            }
            catch (CustomExceptionJson ex)
            {
                _logger.Error($"Something went wrong: {ex}");
                await HandleCustomExceptionJsonAsync(httpContext, ex);
            }
            catch (UnauthorizedAccessException ex)
            {
                _logger.Error($"Something went wrong: {ex}");
                await HandleUnauthorizedExceptionAsync(httpContext);
            }
            catch (DoNotExistsException ex)
            {
                _logger.Error($"Something went wrong: {ex}");
                await HandleNotFoundExceptionAsync(httpContext, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.Error($"Something went wrong: {ex}");
                await HandleExceptionAsync(httpContext);
            }
        }

        private static Task HandleUnauthorizedExceptionAsync(HttpContext context)
        {
            context.Response.ContentType = "application/json";
            context.Response.StatusCode = (int)HttpStatusCode.Forbidden;

            return context.Response.WriteAsync(new ErrorDetails()
            {
                StatusCode = context.Response.StatusCode,
                Message = "Forbidden, You do not have access.",
            }.ToString());
        }

        private static Task HandleNotFoundExceptionAsync(HttpContext context, string message)
        {
            context.Response.ContentType = "application/json";
            context.Response.StatusCode = (int)HttpStatusCode.NotFound;

            return context.Response.WriteAsync(new ErrorDetails()
            {
                StatusCode = context.Response.StatusCode,
                Message = message,
            }.ToString());
        }

        private static Task HandleExceptionAsync(HttpContext context)
        {
            context.Response.ContentType = "application/json";
            context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;

            return context.Response.WriteAsync(new ErrorDetails()
            {
                StatusCode = context.Response.StatusCode,
                Message = "Internal server error.",
            }.ToString());
        }

        private static Task HandleCustomExceptionJsonAsync(HttpContext context, CustomExceptionJson exception)
        {
            context.Response.ContentType = "application/json";
            context.Response.StatusCode = (int)HttpStatusCode.BadRequest;

            return context.Response.WriteAsync(
            JsonConvert.SerializeObject(
            exception.ErrorResponse,
            new JsonSerializerSettings
            {
                ContractResolver = new Newtonsoft.Json.Serialization.CamelCasePropertyNamesContractResolver(),
            }));
        }

        private static Task HandleCustomExceptionAsync(HttpContext context, Exception exception)
        {
            context.Response.ContentType = "application/json";
            context.Response.StatusCode = (int)HttpStatusCode.BadRequest;

            return context.Response.WriteAsync(new ErrorDetails()
            {
                StatusCode = context.Response.StatusCode,
                Message = exception.Message,
            }.ToString());
        }

        private static Task HandleMemberExceptionAsync(HttpContext context, MemberException exception)
        {
            context.Response.ContentType = "application/json";
            context.Response.StatusCode = (int)HttpStatusCode.BadRequest;
            if (exception.ErrorModels != null && exception.ErrorModels.Count > 0)
            {
                return context.Response.WriteAsync(
                    JsonConvert.SerializeObject(exception.ErrorModels));
            }

            if (exception.Errors != null && exception.Errors.Count > 0)
            {
                return context.Response.WriteAsync(
                    JsonConvert.SerializeObject(GetErrorResponseModel(exception.Errors)));
            }

            return context.Response.WriteAsync(JsonConvert.SerializeObject(
                GetErrorResponseModel(exception.Message, exception.MessageType)));
        }

        private static List<ErrorResponseModel> GetErrorResponseModel(List<ErrorModel> errors)
        {
            List<ErrorResponseModel> errorResponses = new List<ErrorResponseModel>
            {
                new ErrorResponseModel
                {
                    Errors = errors,
                },
            };

            return errorResponses;
        }

        private static BadRequestObjectResult GetErrorResponseModel(string errorMessage, string propertyName)
        {
            List<ErrorResponseModel> errorResponses = new List<ErrorResponseModel>();
            ErrorResponseModel errorResponse = new ErrorResponseModel();

            var errorModel = new ErrorModel
            {
                FieldName = errorMessage,
                Message = propertyName,
            };

            errorResponse.Errors.Add(errorModel);

            if (errorResponse.Errors.Count > 0)
            {
                errorResponses.Add(errorResponse);
            }

            return new BadRequestObjectResult(new { errorResponses });
        }
    }
}
