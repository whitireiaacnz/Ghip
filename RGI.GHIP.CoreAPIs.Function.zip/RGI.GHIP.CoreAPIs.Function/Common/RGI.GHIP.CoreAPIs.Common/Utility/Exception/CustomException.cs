﻿using System;
using System.Runtime.Serialization;

namespace RGI.GHIP.CoreAPIs.Common.Utility
{
    [Serializable]
    public class CustomException : Exception
    {
        public CustomException()
        {
        }

        public CustomException(string message)
            : base(message)
        {
        }

        public CustomException(string message, string type)
            : base(message)
        {
            MessageType = type;
        }

        public CustomException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        protected CustomException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        public virtual string MessageType { get; }
    }
}