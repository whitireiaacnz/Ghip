﻿using System;
using System.Collections.Generic;
using System.Text;
using RGI.GHIP.CoreAPIs.Common.Interfaces.Utility;

namespace RGI.GHIP.CoreAPIs.Common.Utility
{
    public class RandomValueGenerator : IRandomValueGenerator
    {
        private const string CHARACTERS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        private static readonly Random _random = new Random();
        private readonly Dictionary<int, StringBuilder> _stringBuilders = new Dictionary<int, StringBuilder>();

        public string CreateRandomPasswordWithRandomLength()
        {
            char[] symbols = "$@#_".ToCharArray();
            char[] lowercase = "abcdefghijklmnopqrstuvwxyz".ToCharArray();
            char[] uppercase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".ToCharArray();
            char[] numbers = "0123456789".ToCharArray();
            char[] allChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789$@#_".ToCharArray();
            Random random = new Random();

            int length = 14;
            char[] password = new char[length];

            // get the requirements out of the way
            password[0] = lowercase[random.Next(lowercase.Length)];
            password[1] = uppercase[random.Next(uppercase.Length)];
            password[2] = numbers[random.Next(numbers.Length)];
            password[3] = symbols[random.Next(symbols.Length)];

            // populate rest of the password with random chars
            for (int i = 4; i < length; i++)
            {
                password[i] = allChars[random.Next(allChars.Length)];
            }

            // shuffle it up
            for (int i = 0; i < length; i++)
            {
                int randomPosition = random.Next(length);
                char temp = password[i];
                password[i] = password[randomPosition];
                password[randomPosition] = temp;
            }

            return new string(password);
        }

        public string KeyGenerator(int length, List<char> exclusionList)
        {
            var sb = new StringBuilder();
            for (var i = 0; i < length; i++)
            {
                var ch = Convert.ToChar(Convert.ToInt32(Math.Floor((62 * _random.NextDouble()) + 48)));
                while (exclusionList.Contains(ch))
                {
                    ch = Convert.ToChar(Convert.ToInt32(Math.Floor((62 * _random.NextDouble()) + 65)));
                }

                sb.Append(ch);
            }

            return sb.ToString();
        }

        public string KeyGenerator()
        {
            Random random = new Random();

            // Minimum size 8. Max size is number of all allowed chars.
            int size = random.Next(3, 8);
            return GenerateUId(size);
        }

        public string GenerateUId(int length)
        {
            StringBuilder result;
            if (!_stringBuilders.TryGetValue(length, out result))
            {
                result = new StringBuilder();
                _stringBuilders[length] = result;
            }

            result.Clear();

            for (int i = 0; i < length; i++)
            {
                result.Append(CHARACTERS[_random.Next(CHARACTERS.Length)]);
            }

            return result.ToString();
        }
    }
}
