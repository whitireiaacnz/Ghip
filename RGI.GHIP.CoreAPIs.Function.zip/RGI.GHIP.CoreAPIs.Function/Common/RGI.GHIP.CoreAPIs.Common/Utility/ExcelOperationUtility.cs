﻿using System.IO;
using ClosedXML.Excel;
using Microsoft.AspNetCore.Http;
using RGI.GHIP.CoreAPIs.Common.Interfaces.Logging;
using RGI.GHIP.CoreAPIs.Common.Interfaces.Utility;

namespace RGI.GHIP.CoreAPIs.Common.Utility
{
    public class ExcelOperationUtility : IExcelOperationUtility
    {
        private readonly ILogger _logger;

        public ExcelOperationUtility(ILogger logger)
        {
            _logger = logger;
        }

        public IXLWorksheets ReadExcel(Stream stream)
        {
            _logger.Info("Open the Excel file using ClosedXML.");
            using XLWorkbook workBook = new XLWorkbook(stream);
            IXLWorksheets workSheets = workBook.Worksheets;

            return workSheets;
        }

        public IXLWorksheets ReadExcel(IFormFile file)
        {
            _logger.Info("Open the Excel file using ClosedXML.");
            using XLWorkbook workBook = new XLWorkbook(file.OpenReadStream());
            IXLWorksheets workSheets = workBook.Worksheets;

            return workSheets;
        }
    }
}
