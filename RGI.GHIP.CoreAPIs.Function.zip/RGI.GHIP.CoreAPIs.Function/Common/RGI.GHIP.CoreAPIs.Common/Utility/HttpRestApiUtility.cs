﻿using System;
using System.Net.Http;
using Newtonsoft.Json.Linq;
using RestSharp;
using RGI.GHIP.CoreAPIs.Common.Interfaces.IMapper;
using RGI.GHIP.CoreAPIs.Common.Interfaces.Utility;

namespace RGI.GHIP.CoreAPIs.Common.Utility
{
    public class HttpRestApiUtility : IHttpRestApiUtility
    {
        private readonly IMapperExtension _mapper;

        public HttpRestApiUtility(IMapperExtension mapper)
        {
            _mapper = mapper;
        }

        public TResponse GetResponse<TResponse>(string url, string authorisation = null, string key = "Output")
        {
            RestClient client = new RestClient(url);
            var request = new RestRequest(Method.GET);
            request.AddHeader("Authorization", authorisation);
            request.AddHeader("Content-Type", "application/json");
            IRestResponse response = client.Execute(request);

            if (response.StatusCode.ToString() == "OK"
            && JObject.Parse(response.Content)["Message"].ToString() == "Success")
            {
                /*if (JObject.Parse(response.Content)["Output"].Value<string>() == null)
                {
                    return default(TResponse);
                }
*/
                try
                {
                    return JObject.Parse(response.Content)[key].ToObject<TResponse>();
                }
                catch (Exception)
                {
                    return default;
                }
            }
            else if (response.StatusCode.ToString() == "OK"
            && JObject.Parse(response.Content)["Message"].ToString() == "No Data Available")
            {
                return default;
            }
            else
            {
                throw new CustomExceptionJson("RGI Exception", JObject.Parse(response.Content)["Error"].ToString());
            }
        }

        public TResponseBody PostResponse<TRequestBody, TResponseBody>(
        string url,
        TRequestBody body,
        string authorisation = null,
        string key = "Output")
        {
            RestClient client = new RestClient(url);

            var request = new RestRequest(Method.POST);
            request.AddHeader("Authorization", authorisation);
            request.AddHeader("Content-Type", "application/json");
            request.AddJsonBody(body);
            HttpClient httpClient = new HttpClient();
            httpClient.Timeout = TimeSpan.FromMinutes(10);
            IRestResponse response = client.Execute(request);

            if (response.StatusCode.ToString() == "OK"
            && (JObject.Parse(response.Content)["Message"].ToString() == "Success" || JObject.Parse(response.Content)["Message"].ToString() == "Declaration Saved Successfully"))
            {
                try
                {
                    return JObject.Parse(response.Content)[key].Value<TResponseBody>();
                }
                catch (Exception)
                {
                    return default;
                }
            }
            else
            {
                throw new CustomExceptionJson("RGI Exception", JObject.Parse(response.Content)["Error"].ToString());
            }
        }
    }
}
