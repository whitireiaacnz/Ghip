using Microsoft.AspNetCore.Http;
using RGI.GHIP.CoreAPIs.Common.Extensions;
using RGI.GHIP.CoreAPIs.Common.Interfaces.Utility;

namespace RGI.GHIP.CoreAPIs.Common.Utility
{
    public class FileValidationUtility : IFileValidationUtility
    {
        public void ValidateIncomingFile(IFormFile file, string extension)
        {
            var checkFilesize = file.Length / 1024;
            if (checkFilesize > 5000)
            {
                {
                    throw new CustomExceptionJson("File Size shoud be less than 5MB");
                }
            }

            if (extension != ".jpg" && extension != ".jpeg" && extension != ".xlsx"
             && extension != ".png" && extension != ".doc" && extension != ".docx"
              && extension != ".pdf" && extension != ".rar" && extension != ".zip")
            {
                {
                    throw new CustomExceptionJson("File type not valid");
                }
            }

            if (!ValidFileExtension.IsValidFile(file))
            {
                throw new CustomExceptionJson("File format or file extension is not valid");
            }
        }
    }
}