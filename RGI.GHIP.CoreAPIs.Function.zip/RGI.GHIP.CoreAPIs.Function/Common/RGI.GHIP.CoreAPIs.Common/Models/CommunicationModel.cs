﻿using System;

namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class CommunicationModel : ModelBase
    {
        public Guid Id { get; set; }

        public string Type { get; set; }

        public string To { get; set; }

        public string RefId { get; set; }

        public string UserName { get; set; }

        public DateTime EmailSentAt { get; set; }

        public string EmailSentError { get; set; }

        public DateTime SMSSentAt { get; set; }

        public string SMSSentError { get; set; }
    }
}
