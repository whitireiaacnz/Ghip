namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class JobModel : ModelBase
    {
        public int Id { get; set; }

        public int? PePolicyId { get; set; }

        public string Status { get; set; }

        public string? Errors { get; set; }

        public string? MemberFileURL { get; set; }

        public string JobCreatedBy { get; set; }
    }
}