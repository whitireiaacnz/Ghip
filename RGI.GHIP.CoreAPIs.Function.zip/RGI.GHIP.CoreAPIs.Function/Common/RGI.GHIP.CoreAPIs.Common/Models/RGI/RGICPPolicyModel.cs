﻿using System;

namespace RGI.GHIP.CoreAPIs.Common.Models.RGI
{
    public class RGICPPolicyModel
    {
        public int Id { get; set; }

        public string PolicyNo { get; set; }

        public DateTime? PolicyStartDate { get; set; }

        public DateTime? PolicyEndDate { get; set; }

        public string ProductCode { get; set; }

        public string SMCode { get; set; }

        public string SMName { get; set; }

        public string BrokerCode { get; set; }

        public string BrokerName { get; set; }

        public string InsuredName { get; set; }

        public int? BranchIdPk { get; set; }

        public byte? FamilySize { get; set; }

        public DateTime? RGIUpdatedAt { get; set; }

        public string? RGICreatedBy { get; set; }

        public string GraceType { get; set; }

        public string GracePeriod { get; set; }

        public string PolicyType { get; set; }

        public bool? IsDependentCovered { get; set; }

        public bool IsActive { get; set; }

        public DateTime InsertedAt { get; set; }

        public string InsertedBy { get; set; }
    }
}
