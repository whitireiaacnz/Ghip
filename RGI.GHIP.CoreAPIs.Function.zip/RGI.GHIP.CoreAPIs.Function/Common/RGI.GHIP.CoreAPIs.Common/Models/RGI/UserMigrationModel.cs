namespace RGI.GHIP.CoreAPIs.Common.Models.RGI
{
    public class UserMigrationModel : ModelBase
    {
        public int Id { get; set; }

        public string UserName { get; set; }

        public string UserNameType { get; set; }

        public string PasswordType { get; set; }

        public string Email { get; set; }

        public string DOB { get; set; }

        public string EmployeeId { get; set; }

        public string GhipCorporateId { get; set; }

        public string RGICorporateId { get; set; }

        public string IdentityServerId { get; set; }
    }
}