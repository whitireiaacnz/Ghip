﻿using System;

namespace RGI.GHIP.CoreAPIs.Common.Models.RGI
{
    public class RGISMMasterModel
    {
        public int EmployeeIdPk { get; set; }

        public int? ReportingEmployeeIdPk { get; set; }

        public int? SystemSmId { get; set; }

        public string SmVertical { get; set; }

        public string SmChannel { get; set; }

        public DateTime DateOfBirth { get; set; }

        public DateTime DateOfJoining { get; set; }

        public DateTime? DateOfResigning { get; set; }

        public DateTime? SystemDateOfResigining { get; set; }

        public string EmployeeDesignation { get; set; }

        public string EmployeeDepartment { get; set; }

        public int EmployeeBranchIdFk { get; set; }

        public string EmployeeHrFunction { get; set; }

        public string EmployeeFunction { get; set; }

        public string EmployeeName { get; set; }

        public string EmployeeCode { get; set; }

        public string Fax { get; set; }

        public DateTime RGICreatedAt { get; set; }

        public string RGICreatedBy { get; set; }

        public DateTime? RGIUpdatedAt { get; set; }

        public string RGIUpdatedBy { get; set; }

        public DateTime? RGIDeletedAt { get; set; }

        public string RGIDeletedBy { get; set; }

        public string Field1 { get; set; }

        public string Field2 { get; set; }

        public bool EmployeeArc { get; set; }

        public string Title { get; set; }

        public string FirstName { get; set; }

        public string MiddleName { get; set; }

        public string LastName { get; set; }

        public string Gendor { get; set; }

        public bool? ResgnInProgress { get; set; }

        public DateTime? LastWorkingDate { get; set; }

        public string Status { get; set; }

        public int? DirectRepAuth { get; set; }

        public int? FunctionalRepAuth { get; set; }

        public DateTime? DateOfOffer { get; set; }

        public string JobCode { get; set; }

        public string CostCenterCode { get; set; }

        public string OmCode { get; set; }

        public string Grade { get; set; }

        public string ContactNo { get; set; }

        public string Email { get; set; }

        public string PositionCode { get; set; }

        public bool? SpokeType { get; set; }

        public string SpokeBranch { get; set; }

        public string RecruitmentType { get; set; }

        public DateTime? EmployeeTransferDate { get; set; }

        public DateTime? ConfirmationDate { get; set; }

        public bool? ConfirmationStatus { get; set; }
    }
}
