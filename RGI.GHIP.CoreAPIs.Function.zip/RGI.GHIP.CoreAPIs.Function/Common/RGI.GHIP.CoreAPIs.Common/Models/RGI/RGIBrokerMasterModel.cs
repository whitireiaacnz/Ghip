﻿using System;

namespace RGI.GHIP.CoreAPIs.Common.Models.RGI
{
    public class RGIBrokerMasterModel
    {
        public int VendorIdPk { get; set; }

        public string VendorSapCode { get; set; }

        public string VendorNewSapCode { get; set; }

        public string AccountGroup { get; set; }

        public string AgentOrBrokerCode { get; set; }

        public string Address { get; set; }

        public string CityOrVillage { get; set; }

        public string District { get; set; }

        public string State { get; set; }

        public string Country { get; set; }

        public string PinCode { get; set; }

        public string TelePhone { get; set; }

        public string Mobile { get; set; }

        public string Email { get; set; }

        public string Fax { get; set; }

        public string VendorType { get; set; }

        public string VendorName { get; set; }

        public string AgentOrBrokerIrdaCode { get; set; }

        public DateTime? LicenseValidTo { get; set; }

        public string BranchCode { get; set; }

        public string ServiceTaxNumber { get; set; }

        public string PaymentTerms { get; set; }

        public string CompanyCode { get; set; }

        public string BankAccNo { get; set; }

        public string BankName { get; set; }

        public string BankBranchName { get; set; }

        public string ReconcilationAcct { get; set; }

        public string TaxCd { get; set; }

        public string PanNo { get; set; }

        public DateTime? CreatedDateSap { get; set; }

        public string ChannelCode { get; set; }

        public string SubChannelName { get; set; }

        public string BusinessTypeCode { get; set; }

        public string AccountTypeCode { get; set; }

        public double? InitialAmount { get; set; }

        public double? UsageAmount { get; set; }

        public int? CreditDays { get; set; }

        public DateTime CreatedDate { get; set; }

        public DateTime RGICreatedAt { get; set; }

        public string RGICreatedBy { get; set; }

        public DateTime? RGIUpdatedAt { get; set; }

        public string RGIUpdatedBy { get; set; }

        public DateTime? RGIDeletedAt { get; set; }

        public string RGIDeletedBy { get; set; }

        public string Field1 { get; set; }

        public string Field2 { get; set; }

        public bool Active { get; set; }

        public bool VendorArc { get; set; }
    }
}
