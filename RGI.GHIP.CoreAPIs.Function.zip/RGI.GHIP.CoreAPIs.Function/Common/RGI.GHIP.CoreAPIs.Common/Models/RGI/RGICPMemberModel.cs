﻿using System;

namespace RGI.GHIP.CoreAPIs.Common.Models.RGI
{
    public class RGICPMemberModel
    {
        public int Id { get; set; }

        public string PolicyNo { get; set; }

        public int? PolicyId { get; set; }

        public string EmployeeId { get; set; }

        public string UHID { get; set; }

        public string Insuredname { get; set; }

        public DateTime? DOB { get; set; }

        public string Gender { get; set; }

        public string Address1 { get; set; }

        public string Address2 { get; set; }

        public string City { get; set; }

        public string Taluka { get; set; }

        public string District { get; set; }

        public int? Pincode { get; set; }

        public string State { get; set; }

        public string MobileNo { get; set; }

        public string EmailId { get; set; }

        public string Webreferenceno { get; set; }

        public int? CommCode { get; set; }

        public bool? IsActive { get; set; }

        public DateTime? RGICreatedAt { get; set; }

        public DateTime? DOJ { get; set; }

        public string Relationship { get; set; }

        public string EnrollType { get; set; }

        public DateTime InsertedAt { get; set; }

        public int MemberIdPK { get; set; }
    }
}
