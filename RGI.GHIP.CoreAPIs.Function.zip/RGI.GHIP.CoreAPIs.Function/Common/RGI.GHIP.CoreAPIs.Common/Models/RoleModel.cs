﻿namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class RoleModel : ModelBase
    {
        public int Id { get; set; }

        public string RoleType { get; set; }
    }
}
