﻿using System;

namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class UserModel : ModelBase
    {
        public int Id { get; set; }

        public string IdentityServiceUserId { get; set; }

        public string UserId { get; set; }

        public string UserType { get; set; }

        public string UserName { get; set; }

        public DateTime LastLoggedInAt { get; set; }

        public DateTime LastResetAt { get; set; }

        public int ResetCount { get; set; }

        public bool IsDisabled { get; set; }

        public int RoleId { get; set; }
    }
}
