﻿namespace RGI.GHIP.CoreAPIs.Common.Models.Config
{
    public class RGIAPIConfigModel
    {
        public string BASEURL { get; set; }

        public string AUTHORISATIONKEY { get; set; }
    }
}
