﻿namespace RGI.GHIP.CoreAPIs.Common.Models.Config
{
    public sealed class SSOConfigModel
    {
        public string CorporateKey { get; set; }

        public string UserCodeKey { get; set; }
    }
}
