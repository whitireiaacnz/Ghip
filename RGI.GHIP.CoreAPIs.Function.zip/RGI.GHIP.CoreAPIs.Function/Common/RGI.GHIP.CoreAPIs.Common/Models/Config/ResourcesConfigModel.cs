﻿namespace RGI.GHIP.CoreAPIs.Common.Models.Config
{
    public sealed class ResourcesConfigModel
    {
        public string GhipDB { get; set; }

        public string StorageKey { get; set; }
    }
}
