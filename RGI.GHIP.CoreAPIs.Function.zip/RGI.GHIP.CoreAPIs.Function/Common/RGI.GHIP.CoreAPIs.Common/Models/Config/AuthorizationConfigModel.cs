namespace RGI.GHIP.CoreAPIs.Common.Models.Config
{
    public sealed class AuthorizationConfigModel
    {
        public string TestKey { get; set; }

        public string DecryptionKey { get; set; }

        public string IdentityDecryptionKey { get; set; }
    }
}