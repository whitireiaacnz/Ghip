﻿namespace RGI.GHIP.CoreAPIs.Common.Models.Config
{
    public class CommunicationConfigModel
    {
    }
}
