﻿namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class ValidatorModel
    {
        public string Name { get; set; }

        public string Regex { get; set; }

        public string Message { get; set; }
    }
}
