﻿namespace RGI.GHIP.CoreAPIs.Common.Validators
{
    public class ErrorModel
    {
        public string FieldName { get; set; }

        public string Message { get; set; }
    }
}