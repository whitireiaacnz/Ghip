﻿using System.Collections.Generic;

namespace RGI.GHIP.CoreAPIs.Common.Validators
{
    public class ErrorResponseModel
    {
        public List<ErrorModel> Errors { get; set; } = new List<ErrorModel>();
    }
}
