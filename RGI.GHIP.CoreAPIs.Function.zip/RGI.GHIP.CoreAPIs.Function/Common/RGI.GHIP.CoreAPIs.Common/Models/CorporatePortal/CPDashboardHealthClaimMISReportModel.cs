﻿namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal
{
    public class CPDashboardHealthClaimMISReportModel : ModelBase
    {
        public int Fresh_Settled_ApprovedCount { get; set; }

        public float Fresh_Settled_ApprovedAmount { get; set; }

        public int Fresh_Settled_RejectedCount { get; set; }

        public float Fresh_Settled_RejectedAmount { get; set; }

        public int Fresh_Settled_Closed_CancelledCount { get; set; }

        public float Fresh_Settled_Closed_CancelledAmount { get; set; }

        public int Fresh_UnderPro_OpenIntimationsCount { get; set; }

        public int Fresh_UnderPro_QueriedCount { get; set; }

        public float Fresh_UnderPro_QueriedAmount { get; set; }

        public int Fresh_UnderPro_WIPCount { get; set; }

        public float Fresh_UnderPro_WIPAmount { get; set; }

        public int Fresh_SubTotalCount { get; set; }

        public float Fresh_SubTotalAmount { get; set; }

        public int Enhancement_Settled_ApprovedCount { get; set; }

        public float Enhancement_Settled_ApprovedAmount { get; set; }

        public int Enhancement_Settled_RejectedCount { get; set; }

        public float Enhancement_Settled_RejectedAmount { get; set; }

        public int Enhancement_Settled_Closed_CancelledCount { get; set; }

        public float Enhancement_Settled_Closed_CancelledAmount { get; set; }

        public int Enhancement_UnderPro_QueriedCount { get; set; }

        public float Enhancement_UnderPro_QueriedAmount { get; set; }

        public int Enhancement_UnderPro_WIPCount { get; set; }

        public float Enhancement_UnderPro_WIPAmount { get; set; }

        public int Enhancement_SubTotalCount { get; set; }

        public float Enhancement_SubTotalAmount { get; set; }

        public int PrePost_Settled_RejectedCount { get; set; }

        public float PrePost_Settled_RejectedAmount { get; set; }

        public int PrePost_Settled_Closed_CancelledCount { get; set; }

        public float PrePost_Settled_Closed_CancelledAmount { get; set; }

        public int PrePost_UnderPro_QueriedCount { get; set; }

        public float PrePost_UnderPro_QueriedAmount { get; set; }

        public int PrePost_UnderPro_WIPCount { get; set; }

        public float PrePost_UnderPro_WIPAmount { get; set; }

        public int PrePost_SubTotalCount { get; set; }

        public float PrePost_SubTotalAmount { get; set; }
    }
}
