﻿namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal
{
    public class CPPolicyAllowedSumInsuredModel
    {
        public int GradeId { get; set; }

        public int SumInsured { get; set; }

        public string GradeDescription { get; set; }
    }
}
