﻿namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal
{
    public class ApproveRejectModel
    {
        public string Remark { get; set; }

        public bool IsApproved { get; set; }

        public bool IsRejected { get; set; }
    }
}
