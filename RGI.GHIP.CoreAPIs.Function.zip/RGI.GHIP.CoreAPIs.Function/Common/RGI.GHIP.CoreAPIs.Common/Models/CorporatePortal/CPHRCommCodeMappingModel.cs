﻿using System;

namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal
{
    public class CPHRCommCodeMappingModel : ModelBase
    {
        public Guid Id { get; set; }

        public Guid HRId { get; set; }

        public Guid PolicyId { get; set; }

        public string CommunicationCode { get; set; }
    }
}
