namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal
{
    public class CPClaimQueriedModel
    {
        public string ClaimNo { get; set; }

        public bool IsQueried { get; set; }
    }
}