﻿namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal
{
    public class CPHealthClaimMISModel
    {
        public string POLICYNO { get; set; }

        public string POLICYNAME { get; set; }

        public string INSUREDNAME { get; set; }

        public string CLAIMANTNAME { get; set; }

        public string MEMBERUHID { get; set; }

        public string CLAIMANTAGE { get; set; }

        public string GENDER { get; set; }

        public string RELATIONSHIPWITHINSURED { get; set; }

        public string SUMINSURED { get; set; }

        public string BALANCESUMINSURED { get; set; }

        public string CLAIMREFNUMBER { get; set; }

        public string CLAIMNO { get; set; }

        public string INTIMATIONDATE { get; set; }

        public string CLAIMCLASSIFICATION { get; set; }

        public string FILERECEIVEDDATE { get; set; }

        public string DATEOFADMISSION { get; set; }

        public string DATEOFDISCHARGE { get; set; }

        public string AILMENT { get; set; }

        public string ICDCODE_OF_DISEASE { get; set; }

        public string FINALCLAIMSTATUS { get; set; }

        public string HOSPITALNAME { get; set; }

        public string HOSPITALLOCATION { get; set; }

        public string HOSPITALDISTRICT { get; set; }

        public string HOSPITALSTATE { get; set; }

        public string LASTQUERYRESPONSEDATE { get; set; }

        public string LASTQUERYRAISEDDATE { get; set; }

        public string REJECTEDDATE { get; set; }

        public string REJECTEDREMARKS { get; set; }

        public string CLOSEDDATE { get; set; }

        public string CLOSEDREMARKS { get; set; }

        public string CLAIMEDAMOUNT { get; set; }

        public string DEDUCTIONAMOUNT { get; set; }

        public string DEDUCTIONDETAILS { get; set; }

        public string PAYABLEAMOUNT { get; set; }

        public string SERVICETAX { get; set; }

        public string EDUCATIONCESS { get; set; }

        public string HIGHEREDUCATIONCESS { get; set; }

        public string PAYABLEAMOUNTINCLUDINGSERVICETAX { get; set; }

        public string PAYEENAME { get; set; }

        public string ETRANSACTIONNOCHEQUENO { get; set; }

        public string ETRANSACTIONDATECHEQUEDATE { get; set; }
    }
}
