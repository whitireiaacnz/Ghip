﻿using System.Collections.Generic;

namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal
{
    public class CPCorporatesAndPoliciesModel
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string LogoImage { get; set; }

        public string Code { get; set; }

        public List<CPPolicyModel> Policies { get; set; }
    }
}
