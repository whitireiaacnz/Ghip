﻿namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal.Member.PolicyCoverage
{
    public class CPCoverageSubTypeBeniftsModel
    {
        // public List<CPBenifitsRowColModel> Benefit { get; set; }
    }
}
