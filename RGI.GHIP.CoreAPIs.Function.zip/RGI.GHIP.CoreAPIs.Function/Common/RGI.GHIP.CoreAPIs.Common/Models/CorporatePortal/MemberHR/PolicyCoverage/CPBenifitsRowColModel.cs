﻿using System.Collections.Generic;
using RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal.MemberHR.PolicyCoverage;

namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal.Member.PolicyCoverage
{
    public class CPBenifitsRowColModel
    {
        public string HeaderTextField { get; set; }

        public List<CPCoverageValueFieldModel> ColumnField { get; set; }

        public List<CPCoverageValueFieldModel> RowField { get; set; }
    }
}
