﻿namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal.MemberHR.PolicyCoverage
{
    public class CPCoverageValueFieldModel
    {
        public string ValueField { get; set; }
    }
}
