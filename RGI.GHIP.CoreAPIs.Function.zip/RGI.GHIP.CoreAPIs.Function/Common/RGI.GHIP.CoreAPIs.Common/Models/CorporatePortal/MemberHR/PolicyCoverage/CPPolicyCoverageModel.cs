﻿using System.Collections.Generic;

namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal.Member.PolicyCoverage
{
    public class CPPolicyCoverageModel
    {
        public List<CPHealthCoverageModel> CoverageHealth { get; set; }
    }
}
