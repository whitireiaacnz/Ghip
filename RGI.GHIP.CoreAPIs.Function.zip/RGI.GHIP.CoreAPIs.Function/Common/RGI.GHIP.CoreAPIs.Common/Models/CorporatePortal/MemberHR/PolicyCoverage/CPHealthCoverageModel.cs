﻿using System.Collections.Generic;

namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal.Member.PolicyCoverage
{
    public class CPHealthCoverageModel
    {
        public string DisplayTextField { get; set; }

        public string DisplayDescrptionField { get; set; }

        public List<CPCoverageSubTypeModel> CoverageListField { get; set; }
    }
}
