﻿using System.Collections.Generic;

namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal.Member
{
    public class FamilyDetailsResponseModel
    {
        public List<CPMemberFamilyModel> FamilyDetailsResponse { get; set; }
    }
}
