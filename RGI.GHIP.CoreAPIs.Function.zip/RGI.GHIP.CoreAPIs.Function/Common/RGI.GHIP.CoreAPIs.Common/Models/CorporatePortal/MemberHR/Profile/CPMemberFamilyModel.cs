﻿using System;

namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal.Member
{
    public class CPMemberFamilyModel
    {
        public string AccountNumber { get; set; }

        public string Address1 { get; set; }

        public string Address2 { get; set; }

        public int? Age { get; set; }

        public int? BalanceSI { get; set; }

        public string BankBranckAddress { get; set; }

        public string BankName { get; set; }

        public string City { get; set; }

        public string CommCode { get; set; }

        public DateTime? DOB { get; set; }

        public DateTime? DOC { get; set; }

        public DateTime? DOE { get; set; }

        public DateTime? DOJ { get; set; }

        public DateTime? DOS { get; set; }

        public string DeviationRemark { get; set; }

        public string District { get; set; }

        public string EliteStatus { get; set; }

        public string EmailID { get; set; }

        public DateTime? EndorsementEffectiveDate { get; set; }

        public string EndorsementNo { get; set; }

        public string EndorsementType { get; set; }

        public int? EnrollmentID { get; set; }

        public string FatherNameHusbandName { get; set; }

        public string FreshRenew { get; set; }

        public string Grade { get; set; }

        public string ISDeviation { get; set; }

        public string ISSelfCovered { get; set; }

        public string IfscCodeoftheBank { get; set; }

        public string InsuredName { get; set; }

        public string IsActive { get; set; }

        public string MemberIdEmpId { get; set; }

        public string MicrNo { get; set; }

        public string MobileNo { get; set; }

        public string MoidifiedTime { get; set; }

        public string OLDTPAUHID { get; set; }

        public string PED { get; set; }

        public string PanNoOfTheInsured { get; set; }

        public string PaymentDispatchCode { get; set; }

        public int? Pincode { get; set; }

        public int? PolicyId { get; set; }

        public string PolicyNo { get; set; }

        public string ProposerName { get; set; }

        public string RelationShipId { get; set; }

        public string ServiceLocation { get; set; }

        public string Sex { get; set; }

        public string State { get; set; }

        public int? SumInsured { get; set; }

        public string TPA { get; set; }

        public string Taluka { get; set; }

        public string TopUpSI { get; set; }

        public string UHID { get; set; }

        public string Vas { get; set; }

        public string WebReferenceNo { get; set; }

        public DateTime? CreatedTime { get; set; }
    }
}
