﻿namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal.Member.IntimateClaims
{
    public class CPIntimateClaimDocumentSummaryModel
    {
        public string DocTypeId { get; set; }

        public string FileBytes { get; set; }

        public string FileName { get; set; }
    }
}
