﻿using System.Collections.Generic;

namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal.Member.IntimateClaims
{
    public class CPIntimateClaimModel
    {
        public string InsuredName { get; set; }

        public string UHIDNumber { get; set; }

        public string EmployeeID { get; set; }

        public string MobileNumber { get; set; }

        public string EmailID { get; set; }

        public string PatientName { get; set; }

        public string PatientUHID { get; set; }

        public string PatientMobileNo { get; set; }

        public string PolicyName { get; set; }

        public string PolicyNumber { get; set; }

        public string PolicyStartDate { get; set; }

        public string PolicyEndDate { get; set; }

        public string IntimatorName { get; set; }

        public string IntimationType { get; set; }

        public string AdmissionDate { get; set; }

        public string DoctorName { get; set; }

        public string DiagnosisDetails { get; set; }

        public string HospitalId { get; set; }

        public string HospitalName { get; set; }

        public string Address1 { get; set; }

        public string Address2 { get; set; }

        public string Address3 { get; set; }

        public string State { get; set; }

        public string City { get; set; }

        public string District { get; set; }

        public string Pincode { get; set; }

        public string Remarks { get; set; }

        public List<CPIntimateClaimDocumentSummaryModel> DocumentList { get; set; }
    }
}
