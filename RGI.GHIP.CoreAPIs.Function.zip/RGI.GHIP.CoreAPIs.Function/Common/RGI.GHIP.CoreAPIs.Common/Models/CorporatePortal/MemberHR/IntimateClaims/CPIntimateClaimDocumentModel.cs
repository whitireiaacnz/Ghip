﻿namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal.Member.IntimateClaims
{
    public class CPIntimateClaimDocumentModel
    {
        public string DocumentId { get; set; }

        public bool Active { get; set; }

        public int Applicability { get; set; }

        public string Description { get; set; }

        public string DisplayOrder { get; set; }

        public string DocumentType { get; set; }

        public string IsDefaultSet { get; set; }

        public bool IsMandatory { get; set; }

        public bool IsDeleted { get; set; }
    }
}
