﻿namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal.Member
{
    public class NetworkHospitalModel
    {
        public int? UniqueId { get; set; }

        public int? HospitalId { get; set; }

        public string HospitalName { get; set; }

        public string ContactPerson { get; set; }

        public string Address1 { get; set; }

        public string Address2 { get; set; }

        public string City { get; set; }

        public int? CityId { get; set; }

        public string District { get; set; }

        public string State { get; set; }

        public string Country { get; set; }

        public string MobileNo { get; set; }

        public string PhoneNo { get; set; }

        public string EmailID { get; set; }

        public string Pincode { get; set; }
    }
}
