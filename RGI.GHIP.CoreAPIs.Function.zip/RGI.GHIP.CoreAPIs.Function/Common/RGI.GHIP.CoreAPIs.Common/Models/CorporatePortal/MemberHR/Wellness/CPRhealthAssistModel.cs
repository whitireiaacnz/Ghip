﻿namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal.MemberHR.Wellness
{
    public class CPRhealthAssistModel
    {
        public string PolicyNo { get; set; }

        public string Name { get; set; }

        public string EmployeeId { get; set; }

        public string EmailId { get; set; }

        public string MobileNo { get; set; }
    }
}
