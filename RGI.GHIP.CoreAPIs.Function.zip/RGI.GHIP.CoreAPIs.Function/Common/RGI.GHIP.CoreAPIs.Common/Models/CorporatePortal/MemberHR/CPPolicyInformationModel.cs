﻿namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal.MemberHR
{
    public class CPPolicyInformationModel
    {
        public string Active_Insured { get; set; }

        public string Total_Endorsements { get; set; }

        public string Cashless_Claims { get; set; }

        public string Reimbursement_Claims { get; set; }
    }
}
