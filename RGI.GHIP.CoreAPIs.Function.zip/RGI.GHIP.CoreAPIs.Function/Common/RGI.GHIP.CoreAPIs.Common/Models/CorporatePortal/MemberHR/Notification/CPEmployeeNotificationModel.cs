﻿using System;

namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal.MemberHR.Notification
{
    public class CPEmployeeNotificationModel
    {
        public Guid Id { get; set; }

        public string Subject { get; set; }

        public string Content { get; set; }

        public string File { get; set; }

        public bool IsAllCorporate { get; set; }

        public int SpecificCorporate { get; set; }

        public bool IsForAllPolicy { get; set; }

        public Guid SpecificPolicy { get; set; }

        public bool IsForHR { get; set; }

        public bool IsForMember { get; set; }

        public string NotificationBy { get; set; }

        public DateTime EffectiveDateFrom { get; set; }

        public DateTime EffectiveDateTo { get; set; }

        public Guid EmployeeMappingId { get; set; }

        public Guid NotificationId { get; set; }

        public bool IsSeen { get; set; }

        public DateTime SeenAt { get; set; }
    }
}
