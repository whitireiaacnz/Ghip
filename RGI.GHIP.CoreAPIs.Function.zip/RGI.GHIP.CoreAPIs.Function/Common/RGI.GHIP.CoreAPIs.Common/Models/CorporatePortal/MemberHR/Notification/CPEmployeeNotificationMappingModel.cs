﻿using System;

namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal
{
    public class CPEmployeeNotificationMappingModel : ModelBase
    {
        public Guid Id { get; set; }

        public Guid EmployeeMappingId { get; set; }

        public Guid NotificationId { get; set; }

        public bool IsSeen { get; set; }

        public DateTime SeenAt { get; set; }

        public CPNotificationModel Notification { get; set; }

        public CPCorporateEmployeeModel Employee { get; set; }
    }
}
