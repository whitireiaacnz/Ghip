﻿using System;

namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal.MemberHR.TrackClaim
{
    public class CPFamilyClaimDetailsModel
    {
        public string ClaimNo { get; set; }

        public string ClaimType { get; set; }

        public DateTime AdmissionDate { get; set; }

        public string HospitalName { get; set; }

        public string PolicyName { get; set; }

        public string PolicyNo { get; set; }

        public string ClaimStatus { get; set; }

        public string InwardNumber { get; set; }

        public string InsuredName { get; set; }

        public string EmployeeID { get; set; }
    }
}
