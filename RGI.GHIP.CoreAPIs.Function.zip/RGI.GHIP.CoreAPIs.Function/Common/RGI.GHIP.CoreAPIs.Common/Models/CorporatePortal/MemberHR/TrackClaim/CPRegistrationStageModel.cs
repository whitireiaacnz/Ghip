﻿namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal.MemberHR.TrackClaim
{
    public class CPRegistrationStageModel
    {
        public string HeaderText { get; set; }

        public bool IsCurrentState { get; set; }

        public bool IsStageCompleted { get; set; }

        public string CompletionDate { get; set; }

        public string RegistrationNo { get; set; }

        public string RegistrationStatus { get; set; }
    }
}
