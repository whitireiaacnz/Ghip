﻿namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal.MemberHR.TrackClaim
{
    public class CPSettlementStageModel
    {
        public string HeaderText { get; set; }

        public bool IsCurrentState { get; set; }

        public bool IsStageCompleted { get; set; }

        public string CompletionDate { get; set; }
    }
}
