﻿namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal.MemberHR.TrackClaim
{
    public class CPClaimJourneyModel
    {
        public string ClaimType { get; set; }

        public bool IsClaimValid { get; set; }

        public string ClaimStatus { get; set; }

        public CPIntimationStageModel S1 { get; set; }

        public CPDocumentationStageModel S2 { get; set; }

        public CPRegistrationStageModel S3 { get; set; }

        public CPPolicyVerificationStageModel S4 { get; set; }

        public CPMedicalScrutinyStageModel S5 { get; set; }

        public CPQueriedStageModel S6 { get; set; }

        public CPApprovalStageModel S7 { get; set; }

        public CPSettlementStageModel S8 { get; set; }

        public CPRejectionStageModel S9 { get; set; }

        public CPClosureStageModel S10 { get; set; }
    }
}
