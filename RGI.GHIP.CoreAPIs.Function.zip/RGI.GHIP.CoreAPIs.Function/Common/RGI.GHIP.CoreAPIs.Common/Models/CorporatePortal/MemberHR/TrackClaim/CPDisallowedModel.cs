﻿namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal.MemberHR.TrackClaim
{
    public class CPDisallowedModel
    {
        public string BillDescription { get; set; }

        public string SubBillTypeDescription { get; set; }

        public string ClaimedAmount { get; set; }

        public string DisallowedAmount { get; set; }

        public string MoreInformation { get; set; }
    }
}
