﻿namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal.MemberHR.TrackClaim
{
    public class CPFamilyClaimCountModel
    {
        public string PolicyNo { get; set; }

        public string EmployeeId { get; set; }

        public string InsuredName { get; set; }

        public string Relationship { get; set; }

        public string UHID { get; set; }

        public int Age { get; set; }

        public int ClaimCount { get; set; }

        public bool IsSelfCovered { get; set; }
    }
}
