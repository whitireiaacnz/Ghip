﻿namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal.MemberHR.TrackClaim
{
    public class CPClaimDetailsModel
    {
        public string DateAdmission { get; set; }

        public string DateOfDischarge { get; set; }

        public string ClaimNo { get; set; }

        public string ClaimType { get; set; }

        public string CopaymentDeduction { get; set; }

        public string ClaimAmt { get; set; }

        public string SanctionAmount { get; set; }

        public string DisallowedAmount { get; set; }

        public string CompulsoryDeduction { get; set; }

        public string NetSanctionAmount { get; set; }

        public string ServiceTax { get; set; }

        public string PayableAmount { get; set; }

        public string TDSAmount { get; set; }

        public string FinalPayableAmount { get; set; }

        public string QueryResons { get; set; }

        public string ClaimStatus { get; set; }
    }
}
