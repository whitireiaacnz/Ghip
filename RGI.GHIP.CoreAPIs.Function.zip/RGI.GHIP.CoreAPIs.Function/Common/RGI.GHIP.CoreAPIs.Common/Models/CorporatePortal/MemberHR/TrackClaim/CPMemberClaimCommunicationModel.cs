﻿namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal.MemberHR.TrackClaim
{
    public class CPMemberClaimCommunicationModel
    {
        public string RecipientName { get; set; }

        public string Events { get; set; }

        public string SMSSent { get; set; }

        public string EmailSent { get; set; }
    }
}
