﻿namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal.MemberHR.TrackClaim
{
    public class CPClaimsPaymentDetailsModel
    {
        public string ModeofPayment { get; set; }

        public string Payeename { get; set; }

        public string BankName { get; set; }

        public string AccountNumber { get; set; }

        public string TransactionDate { get; set; }

        public string TransactionNumber { get; set; }

        public string PaidAmounts { get; set; }
    }
}
