namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal
{
    public class CPPolicyEcardModel
    {
        public string PolicyNo { get; set; }

        public string[] UHID { get; set; }
    }
}
