namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal
{
    public class CPClaimDocumentListModel
    {
        public string FileName { get; set; }

        public string FileBytes { get; set; }

        public int DocTypeId { get; set; }
    }
}