﻿namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal
{
    public class CPBasePrivilegesModel : ModelBase
    {
        public bool ReportAllowed { get; set; }

        public bool CashlessReport { get; set; }

        public bool ReimbersementReport { get; set; }

        public bool Endoresment { get; set; }

        public bool Dashboard { get; set; }

        public bool StaticDashboard { get; set; }

        public bool DyanamicDashboard { get; set; }
    }
}
