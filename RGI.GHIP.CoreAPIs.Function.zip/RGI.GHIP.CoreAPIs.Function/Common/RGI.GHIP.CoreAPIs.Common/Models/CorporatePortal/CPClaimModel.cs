namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal
{
    public class CPClaimModel
    {
        public string ClaimantName { get; set; }

        public string ClaimNo { get; set; }

        public string UHID { get; set; }

        public string InsuredName { get; set; }

        public string MobileNumber { get; set; }

        public string EmailID { get; set; }

        public string PatientName { get; set; }

        public string CreatedDate { get; set; }

        public int Age { get; set; }

        public bool IsDeclarationAccepted { get; set; }
    }
}