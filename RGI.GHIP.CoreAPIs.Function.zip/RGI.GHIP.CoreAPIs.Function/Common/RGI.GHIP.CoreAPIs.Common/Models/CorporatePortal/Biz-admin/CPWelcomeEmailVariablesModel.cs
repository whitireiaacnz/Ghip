﻿namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal
{
    public class CPWelcomeEmailVariablesModel
    {
        public string Password { get; set; }

        public string UserName { get; set; }

        public string LoginUrl { get; set; }

        public string Name { get; set; }

        public string PolicyNo { get; set; }

        public string PolicyName { get; set; }
    }
}
