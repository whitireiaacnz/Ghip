namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal
{
    public class CPDetachEmailVariablesModel
    {
        public string PolicyNo { get; set; }

        public string Corporate { get; set; }

        public string InsuredName { get; set; }

        public string DetachedBy { get; set; }
    }
}