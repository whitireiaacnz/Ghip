﻿using System;

namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal.Biz_admin
{
    public class CPUserMISReportModel
    {
        public string PolicyNo { get; set; }

        public string InsuredName { get; set; }

        public string Email { get; set; }

        public string UHID { get; set; }

        public string MobileNo { get; set; }

        public string EmployeeId { get; set; }

        public string UserName { get; set; }

        public string PasswordType { get; set; }

        public bool IsLoginDetailsSent { get; set; }

        public DateTime LoginEmailSentAt { get; set; }

        public DateTime LoginSMSSentAt { get; set; }

        public DateTime LastLoggedInAt { get; set; }

        public DateTime DateOfUserCreation { get; set; }
    }
}
