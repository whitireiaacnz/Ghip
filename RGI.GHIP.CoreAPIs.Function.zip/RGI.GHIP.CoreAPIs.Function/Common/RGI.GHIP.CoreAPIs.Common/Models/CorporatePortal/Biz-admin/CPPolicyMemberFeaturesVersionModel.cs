using System;

namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal
{
    public class CPPolicyMemberFeaturesVersionModel : ModelBase
    {
        public Guid Id { get; set; }

        public Guid CPPolicyMemberFeatureId { get; set; }

        public Guid CPPolicyId { get; set; }

        public bool ViewPolicyCoverage { get; set; }

        public bool AdditionOfDependents { get; set; }

        public bool TrackClaims { get; set; }

        public bool ViewECard { get; set; }

        public bool NetworkHospitalTracker { get; set; }

        public bool DownloadForms { get; set; }

        public bool IntimateClaims { get; set; }

        public bool ContactUs { get; set; }

        public bool FAQ { get; set; }

        public bool Wellness { get; set; }

        public bool RHealthAssist { get; set; }

        public bool RHealthCircle { get; set; }

        public bool RHealthBeat { get; set; }

        public bool HealthOPedia { get; set; }

        public bool HRA { get; set; }

        public bool ValueDeals { get; set; }

        public CorporateModel Corporate { get; set; }

        public CPPolicyModel Policy { get; set; }
    }
}