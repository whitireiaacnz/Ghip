﻿using System;
using RGI.GHIP.CoreAPIs.Common.Models.Master;

namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal
{
    public class CPBrokerPolicyMappingModel : CPBasePrivilegesModel
    {
        public Guid Id { get; set; }

        public Guid CPPolicyId { get; set; }

        public Guid BrokerId { get; set; }

        public CPPolicyModel CPPolicy { get; set; }

        public BrokerMasterModel BrokerMaster { get; set; }
    }
}
