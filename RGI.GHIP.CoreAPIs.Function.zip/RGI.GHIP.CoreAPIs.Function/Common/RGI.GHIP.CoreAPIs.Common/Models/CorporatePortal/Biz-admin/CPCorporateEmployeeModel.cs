﻿using System;

namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal
{
    public class CPCorporateEmployeeModel : ModelBase
    {
        public Guid Id { get; set; }

        public int CorporateId { get; set; }

        public string EmployeeId { get; set; }

        public bool IsMember { get; set; }

        public bool IsHR { get; set; }

        public bool IsLoginDetailsCreated { get; set; }

        public DateTime LoginDetailsCreatedAt { get; set; }

        public bool IsLoginDetailsSent { get; set; }

        public DateTime LoginEmailSentAt { get; set; }

        public int EmailSentTrial { get; set; }

        public string EmailSentError { get; set; }

        public int SMSSentTrial { get; set; }

        public string SMSSentError { get; set; }

        public string WelcomeEmailTemplate { get; set; }

        public DateTime LoginSMSSentAt { get; set; }

        public int? UserId { get; set; }

        public CorporateModel Corporate { get; set; }
    }
}
