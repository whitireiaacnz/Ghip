﻿using System;

namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal
{
    public class CPMemberModel : ModelBase
    {
        public Guid Id { get; set; }

        public int RGIId { get; set; }

        public Guid CPPolicyId { get; set; }

        public string PolicyNo { get; set; }

        public string EmployeeId { get; set; }

        public string UHID { get; set; }

        public string InsuredName { get; set; }

        public string Relationship { get; set; }

        public string DOB { get; set; }

        public string Gender { get; set; }

        public string Address1 { get; set; }

        public string Address2 { get; set; }

        public string State { get; set; }

        public string City { get; set; }

        public string Taluka { get; set; }

        public string District { get; set; }

        public string Pincode { get; set; }

        public string Email { get; set; }

        public string MobileNo { get; set; }

        public string WebReferenceNo { get; set; }

        public string Comm_code { get; set; }

        public DateTime DOJ { get; set; }

        public string EnrollmentType { get; set; }

        public bool IsActive { get; set; }

        public DateTime InsertedAt { get; set; }

        public CPPolicyModel CPPolicy { get; set; }
    }
}
