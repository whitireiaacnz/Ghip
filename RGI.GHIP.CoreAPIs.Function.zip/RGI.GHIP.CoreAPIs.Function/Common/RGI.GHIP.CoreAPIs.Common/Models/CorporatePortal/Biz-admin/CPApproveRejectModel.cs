﻿using System;

namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal.Biz_admin
{
    public class CPApproveRejectModel
    {
        public bool IsApproved { get; set; }

        public string By { get; set; }

        public DateTime At { get; set; }

        public string Remark { get; set; }

        public bool IsRejected { get; set; }
    }
}
