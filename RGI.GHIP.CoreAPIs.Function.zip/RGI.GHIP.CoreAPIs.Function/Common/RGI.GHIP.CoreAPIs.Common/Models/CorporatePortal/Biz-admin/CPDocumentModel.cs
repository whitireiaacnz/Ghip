﻿using System;

namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal
{
    public class CPDocumentModel : ModelBase
    {
        public Guid Id { get; set; }

        public Guid PolicyId { get; set; }

        public string DocumentType { get; set; }

        public string DocumentName { get; set; }

        public string DocumentTypeName { get; set; }

        public string DocumentUrl { get; set; }

        public DateTime CreatedAt { get; set; }
    }
}
