﻿using System;

namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal
{
    public class CPPolicyModel : ModelBase
    {
        public Guid Id { get; set; }

        public int RGIId { get; set; }

        public int? CorporateId { get; set; } = null;

        public bool IsActive { get; set; }

        public bool IsSyncOn { get; set; }

        public bool IsSendWelcomeEmail { get; set; }

        public bool IsSendWelcomeSMS { get; set; }

        public string PolicyNumber { get; set; }

        public string InsuredName { get; set; }

        public DateTime RiskStartDate { get; set; }

        public DateTime RiskEndDate { get; set; }

        public DateTime IssueDate { get; set; }

        public byte? FamilySize { get; set; }

        public bool? IsDependentCovered { get; set; }

        public string PolicyType { get; set; }

        public string GracePeriodType { get; set; }

        public int GracePeriodValue { get; set; }

        public string? UserNameType { get; set; }

        public string? PasswordType { get; set; }

        public string WelcomeEmailTemplate { get; set; }

        public string WelcomeEmailSubject { get; set; }

        public DateTime InsertedAt { get; set; }

        public CPPolicyMemberFeaturesModel? CPPolicyMemberFeatures { get; set; }

        public CorporateModel? Corporate { get; set; }

        public DateTime AttachedAt { get; set; }

        public DateTime LastDetachedAt { get; set; }

        public int DetachCount { get; set; }

        public string DetachedBy { get; set; }

        public string WelcomeEmailFile { get; set; }

        public string? WelcomeEmailFileName { get; set; }
    }
}
