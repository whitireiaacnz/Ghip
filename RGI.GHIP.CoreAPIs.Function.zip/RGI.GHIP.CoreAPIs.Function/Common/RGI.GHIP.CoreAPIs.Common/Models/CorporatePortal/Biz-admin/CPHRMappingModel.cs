﻿using System;
using System.Collections.Generic;

namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal
{
    public class CPHRMappingModel : CPBasePrivilegesModel
    {
        public Guid Id { get; set; }

        public string Name { get; set; }

        public string Email { get; set; }

        public string MobileNo { get; set; }

        public string HREmpId { get; set; }

        public int CorporateId { get; set; }

        public List<string> CommCodes { get; set; }

        public List<CPHRCommCodeMappingModel> PolicyCommunicationCodes { get; set; }

        public CorporateModel Corporate { get; set; }
    }
}
