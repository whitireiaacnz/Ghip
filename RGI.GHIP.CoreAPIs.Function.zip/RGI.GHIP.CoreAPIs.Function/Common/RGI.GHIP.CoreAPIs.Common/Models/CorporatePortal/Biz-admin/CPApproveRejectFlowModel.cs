﻿namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal.Biz_admin
{
    public class CPApproveRejectFlowModel
    {
        public CPApproveRejectModel Broker { get; set; } = new CPApproveRejectModel();

        public CPApproveRejectModel SM { get; set; } = new CPApproveRejectModel();

        public CPApproveRejectModel HR { get; set; } = new CPApproveRejectModel();
    }
}
