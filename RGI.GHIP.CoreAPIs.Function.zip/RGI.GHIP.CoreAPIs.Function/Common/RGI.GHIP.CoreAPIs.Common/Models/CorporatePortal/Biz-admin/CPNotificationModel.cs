﻿using System;

namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal
{
    public class CPNotificationModel : ModelBase
    {
        public Guid Id { get; set; }

        public string Subject { get; set; }

        public string Content { get; set; }

        public string File { get; set; }

        public bool IsAllCorporate { get; set; }

        public int? SpecificCorporate { get; set; }

        public string CorporateCode { get; set; }

        public bool IsForAllPolicy { get; set; }

        public Guid? SpecificPolicy { get; set; }

        public bool IsMultiplePolicy { get; set; }

        public string MultiplePolicy { get; set; }

        public bool IsForHR { get; set; }

        public bool IsForMember { get; set; }

        public string NotificationBy { get; set; }

        public bool IsApproved { get; set; }

        public string ApprovedBy { get; set; }

        public DateTime ApprovedAt { get; set; }

        public bool IsRejected { get; set; }

        public string RejectedBy { get; set; }

        public DateTime RejectedAt { get; set; }

        public string PolicyNo { get; set; }

        public string Remark { get; set; }

        public DateTime EffectiveDateFrom { get; set; }

        public DateTime EffectiveDateTo { get; set; }
    }
}
