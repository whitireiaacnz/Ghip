﻿using System;
using RGI.GHIP.CoreAPIs.Common.Models.Master;

namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal
{
    public class CPSMpolicyMappingModel : CPBasePrivilegesModel
    {
        public Guid Id { get; set; }

        public Guid CPPolicyId { get; set; }

        public Guid SMId { get; set; }

        public CPPolicyModel CPPolicy { get; set; }

        public SMMasterModel SMMaster { get; set; }
    }
}
