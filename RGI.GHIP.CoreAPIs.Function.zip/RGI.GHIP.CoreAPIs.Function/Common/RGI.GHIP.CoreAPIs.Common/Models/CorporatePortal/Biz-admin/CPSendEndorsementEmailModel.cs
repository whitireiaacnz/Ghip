namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal
{
    public class CPSendEndorsementEmailModel
    {
        public string PolicyNo { get; set; }

        public string EmployeeId { get; set; }

        public string InsuredName { get; set; }

        public string SumInsured { get; set; }
    }
}