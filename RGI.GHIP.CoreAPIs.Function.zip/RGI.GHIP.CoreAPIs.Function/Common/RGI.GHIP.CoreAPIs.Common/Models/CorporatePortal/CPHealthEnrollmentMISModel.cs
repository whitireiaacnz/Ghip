﻿namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal
{
    public class CPHealthEnrollmentMISModel
    {
        public string POLICYNO { get; set; }

        public string UHID { get; set; }

        public string MEMBERID_EMPID { get; set; }

        public string DATEOFJOIN { get; set; }

        public string INSUREDNAME { get; set; }

        public string DATEOFBIRTH { get; set; }

        public string AGE { get; set; }

        public string RELATIONSHIP { get; set; }

        public string SEX { get; set; }

        public string DOC { get; set; }

        public string DOE { get; set; }

        public string POLICYSTARTDATE { get; set; }

        public string POLICYENDDATE { get; set; }

        public string ADDRESS { get; set; }

        public string CITY { get; set; }

        public string DISTRICT { get; set; }

        public string PINCODE { get; set; }

        public string STATE { get; set; }

        public string SUMINSURED { get; set; }

        public string PROPOSERNAME { get; set; }

        public string ENDORSEMENTNO { get; set; }

        public string ENDORSEMENTTYPE { get; set; }

        public string DOS { get; set; }

        public string LOCATION { get; set; }

        public string TOPUPSI { get; set; }
    }
}
