namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal
{
    public class GetCpPolicyEcardModel
    {
        public string PolicyNo { get; set; }
    }
}
