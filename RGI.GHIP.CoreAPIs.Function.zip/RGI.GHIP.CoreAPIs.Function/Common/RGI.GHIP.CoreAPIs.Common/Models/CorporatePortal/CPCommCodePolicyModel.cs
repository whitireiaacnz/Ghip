﻿using System.Collections.Generic;

namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal
{
    public class CPCommCodePolicyModel
    {
        public List<string> PolicyNos { get; set; }
    }
}
