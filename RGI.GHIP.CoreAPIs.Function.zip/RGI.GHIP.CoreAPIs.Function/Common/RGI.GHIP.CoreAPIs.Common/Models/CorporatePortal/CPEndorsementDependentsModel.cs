﻿using System;

namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal
{
    public class CPEndorsementDependentsModel
    {
        public Guid CPPolicyId { get; set; }

        public string PolicyNumber { get; set; }

        public string EmployeeId { get; set; }

        public string UHID { get; set; }

        public string InsuredName { get; set; }

        public string Relationship { get; set; }

        public int SumInsured { get; set; }

        public int TopupSI { get; set; }

        public string DateOfBirth { get; set; }

        public string Gender { get; set; }

        public string Designation { get; set; }

        public string Location { get; set; }

        public string Email { get; set; }

        public string MobileNo { get; set; }

        public string Grade { get; set; }

        public string Elite { get; set; }

        public string EndorsementType { get; set; }
    }
}
