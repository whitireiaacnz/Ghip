using System.Collections.Generic;

namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal
{
    public class CPClaimDocumentModel
    {
        public string ClaimNo { get; set; }

        public List<CPClaimDocumentListModel> DocumentList { get; set; }
    }
}