﻿using System;
using System.Collections.Generic;

namespace RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal.Broker
{
    public class CPCorporatePoliciesModel
    {
        public int Id { get; set; }

        public List<Guid> Policies { get; set; }
    }
}
