﻿namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class ResetPasswordModel
    {
        public string UserName { get; set; }

        public string NewPassword { get; set; }

        public string Id { get; set; }
    }
}
