﻿using System;
using System.ComponentModel.DataAnnotations;

namespace RGI.GHIP.CoreAPIs.Common.Models.Master
{
    public class SMMasterModel : ModelBase
    {
        public Guid Id { get; set; }

        public int RGIId { get; set; }

        public string Code { get; set; }

        public string Name { get; set; }

        public string Email { get; set; }

        public string MobileNo { get; set; }

        public DateTime LoginEmailSentAt { get; set; }

        public DateTime LoginSMSSentAt { get; set; }

        public bool IsActive { get; set; }

        public DateTime InsertedAt { get; set; }

        [MaxLength(128)]
        public string? InsertedBy { get; set; }
    }
}
