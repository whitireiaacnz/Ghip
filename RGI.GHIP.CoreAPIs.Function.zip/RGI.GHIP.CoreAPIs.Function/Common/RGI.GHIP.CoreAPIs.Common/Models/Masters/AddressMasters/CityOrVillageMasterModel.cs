﻿using System.Collections.Generic;

namespace RGI.GHIP.CoreAPIs.Common.Models.Master
{
    public class CityOrVillageMasterModel : ModelBase
    {
        public int Id { get; set; }

        public int DistrictId { get; set; }

        public string CityOrVillageCode { get; set; }

        public string CityOrVillageName { get; set; }

        public string CityType { get; set; }

        public string Tahsil { get; set; }

        public string Pincode { get; set; }

        public string Field1 { get; set; }

        public string Field2 { get; set; }

        public bool CityCityOrVillageArc { get; set; }

        public int? BranchIdFk { get; set; }

        public List<AreaMasterModel> Area { get; set; }

        public DistrictMasterModel District { get; set; }
    }
}
