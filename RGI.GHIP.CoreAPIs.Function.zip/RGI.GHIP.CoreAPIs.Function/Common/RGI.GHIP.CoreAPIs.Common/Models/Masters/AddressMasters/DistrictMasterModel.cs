﻿using System.Collections.Generic;

namespace RGI.GHIP.CoreAPIs.Common.Models.Master
{
    public class DistrictMasterModel : ModelBase
    {
        public int Id { get; set; }

        public int StateId { get; set; }

        public string DistrictCode { get; set; }

        public string DistrictName { get; set; }

        public string EqZone { get; set; }

        public string Field1 { get; set; }

        public string Field2 { get; set; }

        public bool CityDistrictArc { get; set; }

        public List<CityOrVillageMasterModel> Cities { get; set; }

        public StateMasterModel State { get; set; }
    }
}
