﻿using System.Collections.Generic;

namespace RGI.GHIP.CoreAPIs.Common.Models.Master
{
    public class StateMasterModel : ModelBase
    {
        public int Id { get; set; }

        public int StateCountryIdFk { get; set; }

        public string StateCode { get; set; }

        public string StateName { get; set; }

        public string Field1 { get; set; }

        public string Field2 { get; set; }

        public bool StateArc { get; set; }

        public string GstCode { get; set; }

        public bool? IsUnionTerritory { get; set; }

        public string OmbudsmanAddress { get; set; }

        public string GrievanceClause { get; set; }

        public List<DistrictMasterModel> Districts { get; set; }
    }
}
