﻿namespace RGI.GHIP.CoreAPIs.Common.Models.Master
{
    public class AreaMasterModel : ModelBase
    {
        public long Id { get; set; }

        public int CityId { get; set; }

        public string AreaName { get; set; }

        public string PinCode { get; set; }

        public string Field1 { get; set; }

        public string Field2 { get; set; }

        public bool AreaArc { get; set; }

        public int DistrictId { get; set; }

        public string Latitude { get; set; }

        public string Longitude { get; set; }

        public string LatLongAddress { get; set; }

        public bool? IsError { get; set; }

        public CityOrVillageMasterModel City { get; set; }
    }
}
