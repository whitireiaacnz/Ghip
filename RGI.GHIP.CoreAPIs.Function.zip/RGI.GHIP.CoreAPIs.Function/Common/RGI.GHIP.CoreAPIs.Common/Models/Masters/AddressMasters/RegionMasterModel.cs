﻿namespace RGI.GHIP.CoreAPIs.Common.Models.Master
{
    public class RegionMasterModel : ModelBase
    {
        public int Id { get; set; }

        public int? SystemRegionId { get; set; }

        public int RegionZoneIdFk { get; set; }

        public string ZoneCode { get; set; }

        public string RegionCode { get; set; }

        public string RegionName { get; set; }

        public string Field1 { get; set; }

        public string Field2 { get; set; }

        public bool RegionArc { get; set; }
    }
}
