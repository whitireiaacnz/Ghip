﻿using System;

namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class CPHRSearchModel
    {
        public Guid Id { get; set; }

        public string PolicyNo { get; set; }

        public bool IsActive { get; set; }

        public string EmployeeId { get; set; }

        public string InsuredName { get; set; }

        public string Email { get; set; }

        public string MobileNo { get; set; }
    }
}
