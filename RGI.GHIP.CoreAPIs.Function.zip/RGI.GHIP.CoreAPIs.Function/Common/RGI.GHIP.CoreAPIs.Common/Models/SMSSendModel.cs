﻿namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class SMSSendModel
    {
        public string DepartmentId { get; set; } = "19";

        public string MobileNumber { get; set; }

        public string TextMessage { get; set; }

        public string AppProcess { get; set; } = "Ghip corporate portal";

        public string SmsEvent { get; set; } = "Password reset";

        public string RefName { get; set; } = "UserId";

        public string RefValue { get; set; } = "70178228@RCAP";

        public string SourceRequestId { get; set; } = "abc123101";
    }
}
