using RGI.GHIP.CoreAPIs.Common.Models;

namespace RGI.GHIP.CoreAPIs.WebApi.DTO.PreEnrollment
{
    public class PEExtraBenefitsAndParentInsuranceModel
    {
        public PEExtraBenefitsModel ExtraBenefits { get; set; } = new PEExtraBenefitsModel();

        public PEParentInsuranceModel ParentInsurance { get; set; } = new PEParentInsuranceModel();
    }
}
