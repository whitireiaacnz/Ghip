namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class PETaxModel
    {
        public string GST { get; set; }
    }
}