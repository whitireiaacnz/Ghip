﻿namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class PERelationshipMasterModel : ModelBase
    {
        public int MappingId { get; set; }

        public string Label { get; set; }

        public string Type { get; set; }

        public int MinAgeLimit { get; set; }

        public int MaxAgeLimit { get; set; }

        public bool IsConfigurable { get; set; }

        public int Count { get; set; }

        public string Gender { get; set; }

        public bool IsEnabled { get; set; }

        public bool IsDeletedMapping { get; set; }

        public int RelationshipId { get; set; }

        public int PolicyId { get; set; }
    }
}