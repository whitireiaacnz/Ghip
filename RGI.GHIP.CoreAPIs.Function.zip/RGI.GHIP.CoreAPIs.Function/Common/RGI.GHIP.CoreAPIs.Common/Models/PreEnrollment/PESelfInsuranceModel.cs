using System.Collections.Generic;

namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class PESelfInsuranceModel : ModelBase
    {
        public PEExtraBenefitsModel PEExtraBenefits { get; set; }

        public List<PESelfModel> PESelfModels { get; set; } = new List<PESelfModel>();
    }
}
