﻿namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class PEPolicyCorporateSummaryModel
    {
        public int PolicyId { get; set; }

        public string PolicyName { get; set; }

        public string PolicyPlan { get; set; }

        public int PolicyYear { get; set; }

        public int CorporateId { get; set; }

        public string CorporateName { get; set; }

        public string CorporateCode { get; set; }
    }
}
