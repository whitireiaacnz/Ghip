using System.Collections.Generic;

namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class PEParentInsuranceHistoryModel : ModelBase
    {
        public PEExtraBenefitsHistoryModel PEExtraBenefits { get; set; }

        public List<PEParentInsuranceHistoryPremiumModel> PsiPremiums { get; set; } = new List<PEParentInsuranceHistoryPremiumModel>();
    }
}