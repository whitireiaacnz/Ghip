using System.Collections.Generic;

namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class PEParentInsuranceModel : ModelBase
    {
        public PEExtraBenefitsModel PEExtraBenefits { get; set; }

        public List<PEPSIModel> PEPsi { get; set; } = new List<PEPSIModel>();
    }
}
