﻿namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class PEDependentCountByRelationship
    {
        public int RelationshipId { get; set; }

        public int Count { get; set; }
    }
}
