using System.Collections.Generic;

namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class PEMigrateTopUpModel
    {
        public int Id { get; set; }

        public int PEPolicyId { get; set; }

        public int? ExtraBenefitsId { get; set; }

        public List<PEAdditionSumOptionValuesModel> Values { get; set; }

        public bool IsTopupAllowed { get; set; }

        public string TopupType { get; set; }

        public PESelfAllowedSumInsuredModel AllowedSumInsured { get; set; }

        public int SinglePremium { get; set; }

        public int SelfPremium { get; set; }

        public int DoublePremium { get; set; }

        public string Relationship { get; set; }

        public int Discount { get; set; }

        public int GST { get; set; }

        public int Total { get; set; }
    }
}