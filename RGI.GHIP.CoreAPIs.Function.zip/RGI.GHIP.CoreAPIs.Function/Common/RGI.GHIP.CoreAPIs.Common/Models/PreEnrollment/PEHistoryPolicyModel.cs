using System;
using System.Collections.Generic;

namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class PEHistoryPolicyModel : ModelBase
    {
        public int Id { get; set; }

        public int PEPolicyId { get; set; }

        public int CorporateId { get; set; }

        public int Year { get; set; }

        public string Name { get; set; }

        public string Plan { get; set; }

        public int TotalMembers { get; set; }

        public int MaxNumOfMembersPerFamily { get; set; }

        public PESelfAllowedSumInsuredModel AllowedSumInsured { get; set; }

        public string AllowedSumInsuredType { get; set; }

        public int MaxNumOfChildrenAllowed { get; set; }

        public string PasswordPolicy { get; set; }

        public bool AllowEmployeeEditHisProfile { get; set; }

        public bool AllowEmployeeViewHisProfile { get; set; }

        public bool AllowHRResetProfile { get; set; }

        public bool AllowDeletingMember { get; set; }

        public bool ParentInLawCondition { get; set; }

        public bool AreTwinsAllowed { get; set; }

        public bool AreParentOptInAllowed { get; set; }

        public bool SendReminderEmail { get; set; }

        public DateTime ReminderEmailDate { get; set; }

        public int ReminderEmailHrs { get; set; }

        public int ReminderEmailMin { get; set; }

        public string ReminderEmailTemplate { get; set; }

        public string ReminderEmailSubject { get; set; }

        public bool SendWelcomeEmail { get; set; }

        public DateTime WelcomeEmailDate { get; set; }

        public int WelcomeEmailHrs { get; set; }

        public int WelcomeEmailMin { get; set; }

        public string WelcomeEmailTemplate { get; set; }

        public string WelcomeEmailSubject { get; set; }

        public bool SendConfirmationEmail { get; set; }

        public string ConfirmationEmailTemplate { get; set; }

        public string RegistrationConfirmationEmailSubject { get; set; }

        public string RegistrationConfirmationEmailCcs { get; set; }

        public string RegistrationConfirmationEmailBccs { get; set; }

        public string WelcomeEmailFile { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }

        public List<PERelationshipMasterModel> Relationships { get; set; } = new List<PERelationshipMasterModel>();

        public List<PEFieldMasterModel> MemberFields { get; set; } = new List<PEFieldMasterModel>();

        public List<PEPeriodModel> Periods { get; set; } = new List<PEPeriodModel>();
    }
}