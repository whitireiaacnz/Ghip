﻿using System.Collections.Generic;

namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class PEFieldConfigModel
    {
        public string Label { get; set; }

        public string Name { get; set; }

        public string InputType { get; set; }

        public string Options { get; set; }

        public string Type { get; set; }

        public string Value { get; set; }

        public string Instructions { get; set; }

        public List<ValidatorModel> Validations { get; set; } = new List<ValidatorModel>();

        public bool IsMandatory { get; set; }

        public bool IsVisible { get; set; }

        public bool IsEditable { get; set; }

        public string Section { get; set; }
    }
}
