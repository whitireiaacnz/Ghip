using System.Collections.Generic;

namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class PEMigratePSIModel
    {
        public int Id { get; set; }

        public int PEPolicyId { get; set; }

        public int? ExtraBenefitsId { get; set; }

        public List<PEAdditionSumOptionValuesModel> Values { get; set; }

        public bool IsPSIAllowed { get; set; }

        public string PsiType { get; set; }

        public PESelfAllowedSumInsuredModel AllowedSumInsured { get; set; }

        public int SinglePremium { get; set; }

        public int DoublePremium { get; set; }

        public string Relationship { get; set; }

        public int Discount { get; set; }

        public int GST { get; set; }

        public int Total { get; set; }
    }
}