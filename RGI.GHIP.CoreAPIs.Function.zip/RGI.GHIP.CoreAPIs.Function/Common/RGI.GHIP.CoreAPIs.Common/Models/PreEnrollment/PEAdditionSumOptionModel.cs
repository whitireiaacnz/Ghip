﻿using System.Collections.Generic;

namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class PEAdditionSumOptionModel
    {
        public bool IsAllowed { get; set; }

        public string Type { get; set; }

        public string Plan { get; set; }

        public List<PEAdditionSumOptionValuesModel> Values { get; set; }

        public string ErrorMsg { get; set; }

        public string Instructions { get; set; }

        public int ExtraBenefitsId { get; set; }

        public bool IsPremiumVisible { get; set; }

        public bool IsPremiumApplicable { get; set; }

        public string PremiumType { get; set; }

        public bool IsRefundApplicable { get; set; }
    }
}