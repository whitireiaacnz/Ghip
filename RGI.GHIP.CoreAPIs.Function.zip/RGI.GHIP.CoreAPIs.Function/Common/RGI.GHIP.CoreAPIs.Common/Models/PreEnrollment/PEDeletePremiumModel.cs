using System.Collections.Generic;

namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class PEDeletePremiumModel
    {
        public List<int> Id { get; set; }

        public string PremiumType { get; set; }
    }
}