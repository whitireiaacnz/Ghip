﻿using System;
using System.ComponentModel.DataAnnotations;

namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class PEPeriodModel : ModelBase
    {
        public int Id { get; set; }

        public int PreEnrollmentPolicyId { get; set; }

        [DataType(DataType.Date)]
        public DateTime StartDate { get; set; }

        [DataType(DataType.Date)]
        public DateTime EndDate { get; set; }

        public bool Status { get; set; }
    }
}
