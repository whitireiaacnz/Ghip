﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class PEPolicyModel : ModelBase
    {
        public int Id { get; set; }

        public int CorporateId { get; set; }

        public string Name { get; set; }

        public string Plan { get; set; }

        public int Year { get; set; }

        public int TotalMembers { get; set; }

        public int MaxNumOfChildrenAllowed { get; set; }

        public int MaxNumOfMembersPerFamily { get; set; }

        public PESelfAllowedSumInsuredModel AllowedSumInsured { get; set; }

        public string AllowedSumInsuredType { get; set; }

        public string PasswordPolicy { get; set; }

        public bool AllowEmployeeEditProfile { get; set; }

        public bool AllowEmployeeViewProfile { get; set; }

        public bool AllowHRResetEmployeeDetails { get; set; }

        public bool AllowDeletingMember { get; set; }

        public bool ParentInLawCondition { get; set; }

        public bool AreTwinsAllowed { get; set; }

        public PEAdditionSumOptionModel SelfSumInsured { get; set; } = new PEAdditionSumOptionModel();

        public PEAdditionSumOptionModel ParentSumInsured { get; set; } = new PEAdditionSumOptionModel();

        public PEAdditionSumOptionModel ParentInLawSumInsured { get; set; } = new PEAdditionSumOptionModel();

        public PEAdditionSumOptionModel EnhancedSumInsured { get; set; } = new PEAdditionSumOptionModel();

        public PEAdditionSumOptionModel EnhancedSumInsuredParent { get; set; } = new PEAdditionSumOptionModel();

        public PEAdditionSumOptionModel EnhancedSumInsuredParentInLaw { get; set; } = new PEAdditionSumOptionModel();

        public PEAdditionSumOptionModel TopupOption { get; set; } = new PEAdditionSumOptionModel();

        public PEAdditionSumOptionModel TopupOptionParent { get; set; } = new PEAdditionSumOptionModel();

        public PEAdditionSumOptionModel TopupOptionParentInLaw { get; set; } = new PEAdditionSumOptionModel();

        public string TopupInstructions { get; set; }

        public string ESIInstructions { get; set; }

        public bool SendReminderEmail { get; set; }

        public string ReminderEmailDateTime { get; set; }

        public string ReminderEmailTemplate { get; set; }

        public string ReminderEmailSubject { get; set; }

        public string ReminderEmailFile { get; set; }

        public bool SendWelcomeEmail { get; set; }

        public string WelcomeEmailTemplate { get; set; }

        public string WelcomeEmailSubject { get; set; }

        public string WelcomeEmailFile { get; set; }

        [DataType(DataType.Date)]
        public DateTime WelcomeEmailDate { get; set; }

        public int WelcomeEmailHrs { get; set; }

        public int WelcomeEmailMins { get; set; }

        public string? WelcomeEmailFileName { get; set; }

        public string? ConfirmationEmailFileName { get; set; }

        public string? ReminderEmailFileName { get; set; }

        public bool CreateUsers { get; set; }

        public bool SendRegistrationConfirmationEmail { get; set; }

        public string RegistrationConfirmationEmailSubject { get; set; }

        public string RegistrationConfirmationEmailCcs { get; set; }

        public string RegistrationConfirmationEmailBccs { get; set; }

        public string RegistrationConfirmationEmailTemplate { get; set; }

        public string ConfirmationEmailFile { get; set; }

        public bool IsGSTExempted { get; set; }

        public string GSTFileUpload { get; set; }

        public int GSTPercentage { get; set; }

        [DataType(DataType.Date)]
        public DateTime StartDate { get; set; }

        [DataType(DataType.Date)]
        public DateTime EndDate { get; set; }

        public List<PERelationshipMasterModel> Relationships { get; set; } = new List<PERelationshipMasterModel>();

        public List<PEFieldMasterModel> MemberFields { get; set; } = new List<PEFieldMasterModel>();

        public List<PEPeriodModel> Periods { get; set; } = new List<PEPeriodModel>();

        public PETaxModel TaxData { get; set; }

        public string Tax { get; set; }
    }
}
