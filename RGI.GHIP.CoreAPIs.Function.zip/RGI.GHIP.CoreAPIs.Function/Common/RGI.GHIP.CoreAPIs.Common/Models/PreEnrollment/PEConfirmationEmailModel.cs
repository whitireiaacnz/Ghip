namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class PEConfirmationEmailModel
    {
        public bool SendRegistrationConfirmationEmail { get; set; }

        public string RegistrationConfirmationEmailSubject { get; set; }

        public string RegistrationConfirmationEmailCcs { get; set; }

        public string RegistrationConfirmationEmailBccs { get; set; }

        public string RegistrationConfirmationEmailTemplate { get; set; }

        public string ConfirmationEmailFile { get; set; }

        public string? ConfirmationEmailFileName { get; set; }
    }
}