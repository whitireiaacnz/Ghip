using System.Collections.Generic;

namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class PEReminderEmailModel
    {
        public bool SendReminderEmail { get; set; }

        public List<PEReminderDateTimeModel> PEReminderDateTime { get; set; } = new List<PEReminderDateTimeModel>();

        public string ReminderEmailTemplate { get; set; }

        public string ReminderEmailSubject { get; set; }

        public string ReminderEmailFile { get; set; }

        public string? ReminderEmailFileName { get; set; }
    }
}