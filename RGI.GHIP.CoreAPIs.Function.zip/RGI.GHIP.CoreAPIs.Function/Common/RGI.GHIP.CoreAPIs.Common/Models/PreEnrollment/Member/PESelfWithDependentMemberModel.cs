﻿using System.Collections.Generic;

namespace RGI.GHIP.CoreAPIs.Common.Models.Member
{
    public class PESelfWithDependentMemberModel
    {
        public PEMemberModel Self { get; set; } = new PEMemberModel();

        public List<PEMemberModel> Dependents { get; set; } = new List<PEMemberModel>();
    }
}
