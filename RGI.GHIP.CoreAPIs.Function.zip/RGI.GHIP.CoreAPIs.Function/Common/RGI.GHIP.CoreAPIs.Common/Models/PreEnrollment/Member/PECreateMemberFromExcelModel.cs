﻿namespace RGI.GHIP.CoreAPIs.Common.Models.Member
{
    public class PECreateMemberFromExcelModel
    {
        public string EmployeeId { get; set; }

        public int PreEnrollmentPolicyId { get; set; }

        public int RelationshipId { get; set; }

        public string FieldsJson { get; set; }

        public bool IsDeleted { get; set; }

        public bool IsHR { get; set; }

        public int PSI { get; set; }

        public int ESI { get; set; }

        public int Topup { get; set; }
    }
}
