﻿using System;

namespace RGI.GHIP.CoreAPIs.Common.Models.Member
{
    public class PEMemberFieldsModel
    {
        public string EmployeeId { get; set; }

        public string InsuredName { get; set; }

        public string Grade { get; set; }

        public int SumInsured { get; set; }

        public DateTime DateOfBirth { get; set; }

        public string Relationship { get; set; }

        public string Gender { get; set; }

        public string MobileNo { get; set; }

        public string EmailId { get; set; }

        public DateTime DateOfJoining { get; set; }
    }
}
