﻿using System;
using System.Collections.Generic;

namespace RGI.GHIP.CoreAPIs.Common.Models.Member
{
    public class PEMemberModel : ModelBase
    {
        public int Id { get; set; }

        public string EmployeeId { get; set; }

        public int PreEnrollmentPolicyId { get; set; }

        public int RelationshipId { get; set; }

        public string FieldsJson { get; set; }

        public List<PEFieldConfigModel> Fields { get; set; }

        public PEMemberFieldsModel FieldsJsonData { get; set; }

        public int PSI { get; set; }

        public int ESI { get; set; }

        public int Topup { get; set; }

        public bool AllowDeletion { get; set; }

        // reminder email fields
        public string ReminderEmailErrorReason { get; set; }

        public string ReminderEmailTemplate { get; set; }

        public int ReminderEmailSentTrials { get; set; }

        public DateTime ReminderEmailSentAt { get; set; }

        public bool IsReminderEmailSent { get; set; }

        // reminder email fields
        public string WelcomeEmailErrorReason { get; set; }

        public int WelcomeEmailSentTrials { get; set; }

        public bool IsWelcomeEmailSent { get; set; }

        public DateTime FinalSubmissionCompletedAt { get; set; }

        public DateTime WelcomeEmailSentAt { get; set; }

        public bool IsFinalSubmissionLocked { get; set; }

        public string WelcomeEmailTemplate { get; set; }

        public string ConfirmationEmailTemplate { get; set; }

        public string ConfirmationEmailErrorReason { get; set; }

        public int ConfirmationEmailSentTrials { get; set; }

        public DateTime ConfirmationEmailSentAt { get; set; }

        public DateTime DateOfJoining { get; set; }

        public bool IsConfirmationEmailSent { get; set; }

        public bool IsSelfProfileEdited { get; set; }

        public bool IsHR { get; set; }

        public List<PEPremiumConfigModel> SiPremiumModel { get; set; } = new List<PEPremiumConfigModel>();

        public List<PEPremiumConfigModel> PsiPremiumModel { get; set; } = new List<PEPremiumConfigModel>();

        public List<PEPremiumConfigModel> EsiPremiumModel { get; set; } = new List<PEPremiumConfigModel>();

        public List<PEPremiumConfigModel> TopupPremiumModel { get; set; } = new List<PEPremiumConfigModel>();

        public bool IsPSIVisible { get; set; }

        public bool IsESIVisible { get; set; }

        public bool IsTopupVisible { get; set; }

        public int PSIPremium { get; set; }

        public int ESIPremium { get; set; }

        public int TopupPremium { get; set; }

        public PERelationshipMasterModel RelationshipMaster { get; set; }

        public PEPolicyModel PreEnrollmentPolicy { get; set; }
    }
}
