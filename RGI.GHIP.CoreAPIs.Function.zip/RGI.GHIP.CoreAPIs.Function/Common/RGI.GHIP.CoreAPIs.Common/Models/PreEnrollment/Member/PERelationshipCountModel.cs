using System;

namespace RGI.GHIP.CoreAPIs.Common.Models.Member
{
    public class PERelationshipCountModel
    {
        public int RelationshipId { get; set; }

        public int Count { get; set; }

        public string Relationship { get; set; }

        public DateTime DateOfBirth { get; set; }
    }
}