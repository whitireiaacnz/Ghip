﻿using System.Collections.Generic;
using RGI.GHIP.CoreAPIs.Common.Models.Member;

namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class PEMemberFieldsSummaryModel : PEMemberModel
    {
        public PEMemberFieldsModel FieldsData { get; set; } = new PEMemberFieldsModel();

        public List<PEMemberFieldsSummaryModel> Dependent { get; set; } = new List<PEMemberFieldsSummaryModel>();
    }
}
