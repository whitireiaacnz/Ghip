namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class PEReminderDateTimeModel
    {
        public string ReminderEmailDate { get; set; }

        public int ReminderEmailHrs { get; set; }

        public int ReminderEmailMin { get; set; }
    }
}