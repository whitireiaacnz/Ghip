namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class PEGradeSIModel
    {
        public string Grade { get; set; }

        public int SumInsured { get; set; }
    }
}
