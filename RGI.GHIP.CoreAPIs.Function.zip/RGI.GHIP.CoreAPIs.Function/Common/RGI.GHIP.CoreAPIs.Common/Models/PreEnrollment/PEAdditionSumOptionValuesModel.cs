﻿namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class PEAdditionSumOptionValuesModel
    {
        public int Value { get; set; }

        public int Multiple { get; set; }

        public string Grade { get; set; }
    }
}
