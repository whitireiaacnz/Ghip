namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class PEPremiumConfigModel
    {
        public double Loading { get; set; }

        public int PremiumAmount { get; set; }

        public int GST { get; set; }

        public int SumInsured { get; set; }

        public int TotalPremium { get; set; }
    }
}