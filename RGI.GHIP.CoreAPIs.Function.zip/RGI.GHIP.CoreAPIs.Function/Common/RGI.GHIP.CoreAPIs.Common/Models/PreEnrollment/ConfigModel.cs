namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class ConfigModel : ModelBase
    {
        public int Id { get; set; }

        public string FieldName { get; set; }

        public string Type { get; set; }

        public string Value { get; set; }

        public bool IsEditable { get; set; }

        public bool IsActive { get; set; }
    }
}