﻿namespace RGI.GHIP.CoreAPIs.Common.Models.Email
{
    public class EmailFieldMasterModel
    {
        public int MappingId { get; set; }

        public int PolicyId { get; set; }

        public int FieldId { get; set; }

        public string Label { get; set; }

        public bool IsEnabled { get; set; }

        public bool IsVisibleForSelf { get; set; }

        public bool IsVisibleForDependent { get; set; }

        public bool IsMandatoryForSelf { get; set; }

        public bool IsMandatoryForDependent { get; set; }

        public bool IsConfigurable { get; set; }

        public bool IsDeletedMapping { get; set; }

        public bool IsDeleted { get; set; }
    }
}
