﻿namespace RGI.GHIP.CoreAPIs.Common.Models.Email
{
    public class EmailRelationshipMasterModel
    {
        public string Label { get; set; }

        public string Type { get; set; }

        public int MinAgeLimit { get; set; }

        public int MaxAgeLimit { get; set; }

        public int Count { get; set; }
    }
}
