﻿using System;

namespace RGI.GHIP.CoreAPIs.Common.Models.Email
{
    public class EmailMemberModel
    {
        public int Id { get; set; }

        public string EmployeeId { get; set; }

        public string InsuredName { get; set; }

        public string Grade { get; set; }

        public int SumInsured { get; set; }

        public DateTime DateOfBirth { get; set; }

        public int Age { get; set; }

        public int PSI { get; set; }

        public int ESI { get; set; }

        public int Topup { get; set; }

        public string Relationship { get; set; }

        public int RelationshipId { get; set; }

        public string Gender { get; set; }

        public string MobileNumber { get; set; }

        public string EmailAddress { get; set; }

        public string UserName { get; set; }

        public string Password { get; set; }

        public string FieldsJson { get; set; }
    }
}
