﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace RGI.GHIP.CoreAPIs.Common.Models.Email
{
    public class EmailPolicyModel
    {
        public int Id { get; set; }

        public string PolicyName { get; set; }

        public string PolicyPlan { get; set; }

        public int PolicyYear { get; set; }

        public int TotalMembers { get; set; }

        public int MaxNumOfChildrenAllowed { get; set; }

        public int MaxNumOfMembersPerFamily { get; set; }

        public string PolicySumsInsured { get; set; }

        public string PasswordPolicy { get; set; }

        public string WelcomeEmailTemplate { get; set; }

        public string WelcomeEmailSubject { get; set; }

        public DateTime PolicyStartDate { get; set; }

        public DateTime PolicyEndDate { get; set; }

        [DataType(DataType.Date)]
        public DateTime PreEnrollmentPeriodStartDate { get; set; }

        [DataType(DataType.Date)]
        public DateTime PreEnrollmentPeriodEndDate { get; set; }

        public List<PERelationshipMasterModel> Relationships { get; set; } = new List<PERelationshipMasterModel>();

        public List<EmailFieldMasterModel> MemberFields { get; set; } = new List<EmailFieldMasterModel>();

        public List<EmailMemberModel> SelfMember { get; set; } = new List<EmailMemberModel>();
    }
}
