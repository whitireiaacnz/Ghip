﻿using Newtonsoft.Json;

namespace RGI.GHIP.CoreAPIs.Common.Models.PreEnrollment.Email.SendApi
{
    public class EmailAttachmentModel
    {
        [JsonProperty("fileContent")]
        public string FileContent { get; set; }

        [JsonProperty("fileName")]
        public string FileName { get; set; }
    }
}
