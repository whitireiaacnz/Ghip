﻿using System.Collections.Generic;
using Newtonsoft.Json;
using RGI.GHIP.CoreAPIs.Common.Models.Email.SendApi;
using RGI.GHIP.CoreAPIs.Common.Models.PreEnrollment.Email.SendApi;

namespace RGI.GHIP.CoreAPIs.Common.Models.Email
{
    public class EmailModel
    {
        [JsonProperty("subject")]
        public string Subject { get; set; }

        [JsonProperty("content")]
        public string Content { get; set; }

        [JsonProperty("attachments")]
        public List<EmailAttachmentModel> Attachments { get; set; } = new List<EmailAttachmentModel>();

        [JsonProperty("from")]
        public EmailFromModel From { get; set; } = new EmailFromModel();

        [JsonProperty("personalizations")]
        public List<EmailPersonalizationsModel> Personalizations { get; set; } = new List<EmailPersonalizationsModel>();

        [JsonProperty("settings")]
        public EmailSettingsModel Settings { get; set; } = new EmailSettingsModel();
    }
}
