﻿using Newtonsoft.Json;

namespace RGI.GHIP.CoreAPIs.Common.Models.Email.SendApi
{
    public class EmailFromModel
    {
        [JsonProperty("fromEmail")]
        public string FromEmail { get; set; } = "no-reply-corp@reliancegeneral.co.in";

        [JsonProperty("fromName")]
        public string FromName { get; set; } = "GHIP";
    }
}
