﻿namespace RGI.GHIP.CoreAPIs.Common.Models.Email
{
    public class EmailAddressModel
    {
        public string Name { get; set; }

        public string Address { get; set; }
    }
}
