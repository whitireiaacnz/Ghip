﻿using System.Collections.Generic;

namespace RGI.GHIP.CoreAPIs.Common.Models.Email
{
    public class EmailCorporateModel
    {
        public string CorporateName { get; set; }

        public string CorporateCode { get; set; }

        public string CorporateLogoUrl { get; set; }

        public List<EmailPolicyModel> Policies { get; set; }
    }
}
