﻿using System.Collections.Generic;

namespace RGI.GHIP.CoreAPIs.Common.Models.Email
{
    public class EmailSelfWithDependentsModel
    {
        public EmailMemberModel Self { get; set; } = new EmailMemberModel();

        public List<EmailMemberModel> Dependent { get; set; } = new List<EmailMemberModel>();
    }
}
