namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class PEExtraBenefitsModel : ModelBase
    {
        public int Id { get; set; }

        public string Plan { get; set; }

        public int PEPolicyId { get; set; }

        public string SumInsuredType { get; set; }

        public string Instructions { get; set; }

        public string Relationship { get; set; }

        public string BenefitType { get; set; }

        public bool IsAllowed { get; set; }

        public bool IsPremiumVisible { get; set; }

        public bool IsPremiumApplicable { get; set; }

        public string PremiumType { get; set; }

        public bool IsRefundApplicable { get; set; }
    }
}
