namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class PEEnhanceSumInsurancePremiumModel : ModelBase
    {
        public int Id { get; set; }

        public int EnhanceInsuranceId { get; set; }

        public int PEExtraBenefitsId { get; set; }

        public int PEPolicyId { get; set; }

        public int NumberOfMembers { get; set; }

        public int MinAge { get; set; }

        public int MaxAge { get; set; }

        public int SumInsured { get; set; }

        public string Relationship { get; set; }

        public double Loading { get; set; }

        public int PremiumAmount { get; set; }

        public string? Grade { get; set; }
    }
}