﻿namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class PEFieldMasterModel : ModelBase
    {
        public int MappingId { get; set; }

        public int PolicyId { get; set; }

        public int FieldId { get; set; }

        public string Label { get; set; }

        public string InputType { get; set; }

        public string Type { get; set; }

        public string DataType { get; set; }

        public string DropDownValues { get; set; }

        public string Section { get; set; }

        public string Validation { get; set; }

        public bool IsEnabled { get; set; }

        public bool IsEditableForSelf { get; set; }

        public bool IsEditableForDependent { get; set; }

        public bool IsVisibleForSelf { get; set; }

        public bool IsVisibleForDependent { get; set; }

        public bool IsMandatoryForSelf { get; set; }

        public bool IsMandatoryForDependent { get; set; }

        public bool IsConfigurable { get; set; }

        public bool IsDeletedMapping { get; set; }
    }
}