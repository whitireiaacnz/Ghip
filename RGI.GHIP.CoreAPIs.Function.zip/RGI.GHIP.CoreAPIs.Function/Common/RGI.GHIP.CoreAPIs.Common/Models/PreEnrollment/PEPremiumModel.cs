namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class PEPremiumModel
    {
        public bool IsValid { get; set; }

        public int Premium { get; set; }

        public int Total { get; set; }
    }
}
