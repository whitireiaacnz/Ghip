using System.Collections.Generic;

namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class PEEnhanceSumInsuranceModel : ModelBase
    {
        public PEExtraBenefitsModel PEExtraBenefits { get; set; }

        public List<PEESIModel> PeEsi { get; set; } = new List<PEESIModel>();
    }
}