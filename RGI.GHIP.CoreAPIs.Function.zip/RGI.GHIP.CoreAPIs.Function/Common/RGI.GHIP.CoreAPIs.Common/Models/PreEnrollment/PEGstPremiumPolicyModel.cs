namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class PEGstPremiumPolicyModel
    {
        public bool IsGSTExempted { get; set; }

        public string GSTFileUpload { get; set; }

        public int GSTPercentage { get; set; }
    }
}