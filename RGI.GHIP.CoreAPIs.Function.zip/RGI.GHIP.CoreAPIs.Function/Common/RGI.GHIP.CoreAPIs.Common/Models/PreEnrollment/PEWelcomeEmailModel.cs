using System;
using System.ComponentModel.DataAnnotations;

namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class PEWelcomeEmailModel
    {
        public bool SendWelcomeEmail { get; set; }

        public string WelcomeEmailTemplate { get; set; }

        public string WelcomeEmailSubject { get; set; }

        [DataType(DataType.Date)]
        public DateTime WelcomeEmailDate { get; set; }

        public int WelcomeEmailHrs { get; set; }

        public int WelcomeEmailMins { get; set; }

        public string WelcomeEmailFile { get; set; }

        public string? WelcomeEmailFileName { get; set; }

        public bool CreateUsers { get; set; }
    }
}