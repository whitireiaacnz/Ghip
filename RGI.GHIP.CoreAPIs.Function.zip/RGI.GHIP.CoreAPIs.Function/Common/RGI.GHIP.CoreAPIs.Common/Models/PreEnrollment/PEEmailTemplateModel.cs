﻿namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class PEEmailTemplateModel : ModelBase
    {
        public int Id { get; set; }

        public string WelcomeEmailTemplate { get; set; }

        public string ConfirmationEmailTemplate { get; set; }

        public string ReminderEmailTemplate { get; set; }
    }
}
