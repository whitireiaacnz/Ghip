using System.Collections.Generic;

namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class PESelfAllowedSumInsuredModel
    {
        public List<PEGradeSIModel> SumInsuredList { get; set; }

        public string SelfSumInsuredType { get; set; }
    }
}