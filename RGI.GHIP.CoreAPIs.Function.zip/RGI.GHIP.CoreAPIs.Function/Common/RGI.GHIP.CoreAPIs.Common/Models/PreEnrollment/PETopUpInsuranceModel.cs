using System.Collections.Generic;

namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class PETopUpInsuranceModel : ModelBase
    {
        public PEExtraBenefitsModel PEExtraBenefits { get; set; }

        public List<PETopUpInsuranceListModel> PeTopUp { get; set; } = new List<PETopUpInsuranceListModel>();
    }
}