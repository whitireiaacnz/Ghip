namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class PETopUpInsurancePremiumHistoryModel : ModelBase
    {
        public int Id { get; set; }

        public int PETopupInsuranceID { get; set; }

        public int PEPolicyId { get; set; }

        public int? ExtraBenefitsId { get; set; }

        public int SumInsured { get; set; }

        public int Multiples { get; set; }

        public string Grade { get; set; }

        public int SinglePremium { get; set; }

        public int DoublePremium { get; set; }

        public int SelfPremium { get; set; }

        public string Relationship { get; set; }

        public int Discount { get; set; }

        public int GST { get; set; }

        public int Total { get; set; }
    }
}