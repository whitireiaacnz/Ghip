namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class PEExtraBenefitsPremiumModel
    {
        public bool IsPremiumVisible { get; set; }

        public bool IsPremiumApplicable { get; set; }

        public string PremiumType { get; set; }

        public bool IsRefundApplicable { get; set; }
    }
}