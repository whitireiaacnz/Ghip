using System;
using System.ComponentModel.DataAnnotations;

namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class PEWelcomeEmailDateTimeModel
    {
        [DataType(DataType.Date)]
        public DateTime WelcomeEmailDate { get; set; }

        public int WelcomeEmailHrs { get; set; }

        public int WelcomeEmailMins { get; set; }

        public string CorporateName { get; set; }

        public string PolicyName { get; set; }
    }
}