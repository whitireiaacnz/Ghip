namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class PEReminderEmailVariablesModel
    {
        public string NumOfDaysLeft { get; set; }
    }
}