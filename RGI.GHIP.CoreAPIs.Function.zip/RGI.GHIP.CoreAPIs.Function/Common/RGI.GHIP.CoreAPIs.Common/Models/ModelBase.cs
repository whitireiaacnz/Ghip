﻿using System;

namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class ModelBase
    {
        public DateTime CreatedAt { get; set; }

        public string CreatedBy { get; set; }

        public DateTime ModifiedAt { get; set; }

        public string ModifiedBy { get; set; }

        public bool IsDeleted { get; set; }
    }
}
