﻿namespace RGI.GHIP.CoreAPIs.Common.Models
{
    public class CorporateModel : ModelBase
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string Code { get; set; }

        public string EmailId { get; set; }

        public string LogoImage { get; set; }

        public string Address { get; set; }

        public string AddressLine2 { get; set; }

        public string Website { get; set; }

        public int CityId { get; set; }

        public int DistrictId { get; set; }

        public long AreaId { get; set; }

        public int StateId { get; set; }

        public string City { get; set; }

        public string District { get; set; }

        public string Area { get; set; }

        public string State { get; set; }

        public string PinCode { get; set; }

        public string ContactName { get; set; }

        public string MobileNumber { get; set; }

        public string LandlineNumber { get; set; }

        public string FilePath { get; set; }

        public bool IsFileChanged { get; set; }
    }
}
