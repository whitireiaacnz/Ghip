﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RGI.GHIP.CoreAPIs.Common.Enums;
using RGI.GHIP.CoreAPIs.Common.Interfaces;
using RGI.GHIP.CoreAPIs.Common.Utility;
using Serilog;
using Serilog.Core;
using Serilog.Core.Enrichers;
using Serilog.Formatting.Display;

namespace RGI.GHIP.CoreAPIs.Common.Logging
{
    public class SeriLogger : ISeriLogger
    {
        private static readonly object _syncObject = new object();
        private readonly IStackFrameHelper _stackFrameHelper;
        private readonly JsonSerializerSettings _jsonSerializerSettings;
        private readonly LoggingLevelSwitch _logLevelSwitch = new LoggingLevelSwitch();
        private readonly ILogger _slackLogger;

        private bool _isLoggerDisposed = true;

        public SeriLogger()
        {
            InitializeSlackLog();
        }

        public SeriLogger(
        IStackFrameHelper stackFrameHelper)
        {
            _stackFrameHelper = stackFrameHelper;
            _logLevelSwitch.MinimumLevel = Serilog.Events.LogEventLevel.Verbose;
            _jsonSerializerSettings = new JsonSerializerSettings()
            {
                ContractResolver = new PascalCasePropertyNamesContractResolver(),
                NullValueHandling = NullValueHandling.Include,
                DefaultValueHandling = DefaultValueHandling.Include,
            };
        }

        public void InitializeSlackLog()
        {
            /* _slackLogger = new LoggerConfiguration()
                             .WriteTo.Slack(new SlackSinkOptions()
                             {
                                 WebHookUrl = "https://hooks.slack.com/services/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",
                                 CustomChannel = "#reliance_policy_extraction_issues",
                                 ShowExceptionAttachments = true,
                             }).CreateLogger();*/
        }

        public Task ClearLogsAsync()
        {
            throw new NotImplementedException();
        }

        public void CloseLogger()
        {
            lock (_syncObject)
            {
                _isLoggerDisposed = true;
            }

            Log.CloseAndFlush();
        }

        public void End(TimeSpan? elapsed = null, object data = null, string[] tags = null, [CallerMemberName] string callerName = null, string callerFullTypeName = null)
        {
            int classNameStartIndex = _stackFrameHelper.GetCallerFullTypeName().LastIndexOf('.') + 1;
            int classNameLength = _stackFrameHelper.GetCallerFullTypeName().LastIndexOf('+') - classNameStartIndex;
            string callingClassName = classNameLength > 0 ? _stackFrameHelper.GetCallerFullTypeName().Substring(classNameStartIndex, classNameLength) : string.Empty;
            var msg = string.IsNullOrEmpty(callingClassName) ? $"Ending method {callerName}" : $"Ending method {callingClassName}.{callerName}";

            var logger = GetLoggerWithRequiredProperties(
                msg,
                LogLevel.Verbose,
                PrepareData(data),
                tags,
                callerFullTypeName ?? _stackFrameHelper.GetCallerFullTypeName(),
                callerName,
                elapsed != null ? (long)elapsed.Value.TotalMilliseconds : (long?)null);

            Initialize();
            LogWithLevel(LogLevel.Verbose, logger, msg);
        }

        public void Error(string message, object data = null, string[] tags = null, [CallerMemberName] string callerName = null, string callerFullTypeName = null)
        {
            var logger = GetLoggerWithRequiredProperties(
                message,
                LogLevel.Error,
                PrepareData(data),
                tags,
                callerFullTypeName ?? _stackFrameHelper.GetCallerFullTypeName(),
                callerName);

            Initialize();
            LogWithLevel(LogLevel.Error, logger, message);
        }

        public void Exception(Exception exception, object data = null, string[] tags = null, [CallerMemberName] string callerName = null, string callerFullTypeName = null, string message = null)
        {
            var combinedData = MergeMetaDataWithExceptionData(exception.Data, data);

            var logger = GetLoggerWithRequiredProperties(
                exception.Message,
                LogLevel.Error,
                PrepareData(combinedData),
                tags,
                callerFullTypeName ?? _stackFrameHelper.GetCallerFullTypeName(),
                callerName);

            LogWithLevel(LogLevel.Error, logger, exception.Message);
        }

        public void Info(string message, object data = null, string[] tags = null, [CallerMemberName] string callerName = null, string callerFullTypeName = null)
        {
            var logger = GetLoggerWithRequiredProperties(
                message,
                LogLevel.Info,
                PrepareData(data),
                tags,
                callerFullTypeName ?? _stackFrameHelper.GetCallerFullTypeName(),
                callerName);

            Initialize();
            LogWithLevel(LogLevel.Info, logger, message);
        }

        public void Start(object data = null, string[] tags = null, [CallerMemberName] string callerName = null, string callerFullTypeName = null)
        {
            int classNameStartIndex = _stackFrameHelper.GetCallerFullTypeName().LastIndexOf('.') + 1;
            int classNameLength = _stackFrameHelper.GetCallerFullTypeName().LastIndexOf('+') - classNameStartIndex;
            string callingClassName = classNameLength > 0 ? _stackFrameHelper.GetCallerFullTypeName().Substring(classNameStartIndex, classNameLength) : string.Empty;
            string msg = string.IsNullOrEmpty(callingClassName) ? $"Starting method {callerName}" : $"Starting method {callingClassName}.{callerName}";

            var logger = GetLoggerWithRequiredProperties(
                msg,
                LogLevel.Verbose,
                PrepareData(data),
                tags,
                callerFullTypeName ?? _stackFrameHelper.GetCallerFullTypeName(),
                callerName);

            Initialize();
            LogWithLevel(LogLevel.Verbose, logger, msg);
        }

        public void Verbose(string message, object data = null, string[] tags = null, [CallerMemberName] string callerName = null, string callerFullTypeName = null)
        {
            var logger = GetLoggerWithRequiredProperties(
                message,
                LogLevel.Verbose,
                PrepareData(data),
                tags,
                callerFullTypeName ?? _stackFrameHelper.GetCallerFullTypeName(),
                callerName);

            Initialize();
            LogWithLevel(LogLevel.Verbose, logger, message);
        }

        public void Warning(string message, object data = null, string[] tags = null, [CallerMemberName] string callerName = null, string callerFullTypeName = null)
        {
            var logger = GetLoggerWithRequiredProperties(
                message: message,
                LogLevel.Warning,
                PrepareData(data),
                tags,
                callerFullTypeName ?? _stackFrameHelper.GetCallerFullTypeName(),
                callerName);

            Initialize();
            LogWithLevel(LogLevel.Warning, logger, message);
        }

        public void SlackErrorLogger(Exception exception)
        {
            _slackLogger.Error(exception, exception.Message);
        }

        public void SlackInformationLogger(string information)
        {
            _slackLogger.Information(information);
        }

        private ILogger GetLoggerWithRequiredProperties(
            string message,
            LogLevel level,
            object data,
            string[] tags,
            string callerFullTypeName,
            string callerMemerName,
            long? timeInMilliseconds = null,
            Exception exception = null)
        {
            var serializedData = data == null ? null : JsonConvert.SerializeObject(data, _jsonSerializerSettings);

            DateTime dateTimeUtc = DateTime.Now;
            var loggerWithProperties = Log.ForContext(new[]
            {
                new PropertyEnricher("TaskId", TaskScheduler.Current.Id),
                new PropertyEnricher("ThreadId", Thread.CurrentThread.ManagedThreadId),
                new PropertyEnricher("Message", message),
                new PropertyEnricher("Level", level.ToString()),
                new PropertyEnricher("Tags", tags != null ? string.Join(",", tags.Select(x => x.Trim())) : null),
                new PropertyEnricher("Data", serializedData),
                new PropertyEnricher("CallerMemberName", callerMemerName),
                new PropertyEnricher("CallerFullTypeName", callerFullTypeName),
                new PropertyEnricher("TimeInMilliseconds", timeInMilliseconds),
                new PropertyEnricher("Timestamp", dateTimeUtc.ToString()),
                new PropertyEnricher("CreatedAtTicks", dateTimeUtc.Ticks),
                new PropertyEnricher("DateTimeUtcPretty", dateTimeUtc.ToString("O")),
                new PropertyEnricher("Exception", exception == null ? null : JsonConvert.SerializeObject(exception)),
            });

            return loggerWithProperties;
        }

        private JObject PrepareData(object data)
        {
            try
            {
                if (data == null)
                {
                    return new JObject();
                }

                JObject o;
                if (data is string)
                {
                    o = new JObject { { "message", data.ToString() } };
                }
                else
                {
                    var serializer = new JsonSerializer();
                    o = JObject.FromObject(data, serializer);
                }

                return o;
            }
            catch (Exception)
            {
                return null;
            }
        }

        private void LogWithLevel(LogLevel level, ILogger logger, string message)
        {
            Initialize();

            switch (level)
            {
                case LogLevel.Error:
                    logger.Error(message);
                    break;
                case LogLevel.Warning:
                    logger.Warning(message);
                    break;
                case LogLevel.Info:
                    logger.Information(message);
                    break;
                case LogLevel.Verbose:
                    logger.Verbose(message);
                    break;
                default:
                    logger.Verbose(message);
                    break;
            }
        }

        private void Initialize()
        {
            lock (_syncObject)
            {
                if (!_isLoggerDisposed)
                {
                    return;
                }

                _isLoggerDisposed = false;
            }

            var messageFormatter = new MessageTemplateTextFormatter("{Properties}{NewLine}", CultureInfo.InvariantCulture);
            Log.Logger = new LoggerConfiguration()
            .MinimumLevel.ControlledBy(_logLevelSwitch)
#if !DEBUG
            // .WriteTo.
            // AzureLogAnalytics(_appConfig.AzureLogAnalyticsWorkspaceId, _appConfig.AzureLogAnalyticsAuthenticationId, "AlexaSkillLogs", batchSize: 10)
#endif
            .WriteTo.Async((obj) => obj.Console(new SeriLogCustomTextFormatter())).CreateLogger();
        }

        private object MergeMetaDataWithLogMetaData(object logMetaData, object metaData)
        {
            if (logMetaData == null && metaData == null)
            {
                return null;
            }

            if (logMetaData != null && metaData == null)
            {
                return logMetaData;
            }

            if (logMetaData == null && metaData != null)
            {
                return metaData;
            }

            return DynamicExtension.Merge(logMetaData.ToDynamic(), metaData);
        }

        private object MergeMetaDataWithExceptionData(IDictionary data, object metaData)
        {
            if (data == null && metaData == null)
            {
                return null;
            }

            IDictionary<string, object> dictionary = null;
            if (data != null)
            {
                dictionary = new Dictionary<string, object>();
                foreach (var key in data.Keys)
                {
                    dictionary.Add(key.ToString(), data[key]);
                }
            }

            if (data != null && metaData == null)
            {
                return dictionary.ToDynamic();
            }

            if (data == null && metaData != null)
            {
                return metaData;
            }

            return DynamicExtension.Merge(dictionary.ToDynamic(), metaData);
        }
    }
}
