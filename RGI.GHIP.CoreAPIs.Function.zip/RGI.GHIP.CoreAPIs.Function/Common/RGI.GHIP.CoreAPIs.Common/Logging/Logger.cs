﻿using System;
using System.Runtime.CompilerServices;
using Microsoft.ApplicationInsights.Extensibility;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using Serilog;
using Serilog.Core.Enrichers;
using Serilog.Events;
using ILogger = RGI.GHIP.CoreAPIs.Common.Interfaces.Logging.ILogger;

namespace RGI.GHIP.CoreAPIs.Common.Logging
{
    public class Logger : ILogger
    {
        static Logger()
        {
            var config = TelemetryConfiguration.CreateDefault();
            if (config != null)
            {
                Log.Logger = new LoggerConfiguration()
                    .Enrich.FromLogContext()
                    .MinimumLevel.Information()
#if !DEBUG
                    .WriteTo.ApplicationInsights(config, TelemetryConverter.Traces)
#else
                    .WriteTo.Trace(new SeriLogCustomTextFormatter())
#endif
                    .CreateLogger();
            }
        }

        public void Error(
            string e,
            object data = null,
            string[] tags = null,
            [CallerMemberName] string memberName = "",
            [CallerFilePath] string sourceFilePath = "",
            [CallerLineNumber] int sourceLineNumber = 0)
        {
            LogWithProperties(e, LogEventLevel.Error, data, memberName, sourceFilePath, sourceLineNumber);
        }

        public void Init()
        {
        }

        public void Info(
            string message,
            [CallerMemberName] string memberName = "",
            [CallerFilePath] string sourceFilePath = "",
            object data = null,
            string[] tags = null,
            [CallerLineNumber] int sourceLineNumber = 0)
        {
            message = message + $" {DateTime.Now.Second.ToString()} sec ";
            LogWithProperties(message, LogEventLevel.Information, data, memberName, sourceFilePath, sourceLineNumber);
        }

        public void APIInfo(
                    HttpContext httpContext,
                    [CallerMemberName] string memberName = "",
                    [CallerFilePath] string sourceFilePath = "",
                    object data = null,
                    string[] tags = null,
                    [CallerLineNumber] int sourceLineNumber = 0)
        {
            string message = httpContext.Request.Method + httpContext.Request.Path.Value + httpContext.Request.Body.ToString();
            LogWithProperties(message, LogEventLevel.Information, data, memberName, sourceFilePath, sourceLineNumber);
        }

        public void Error(
            Exception e,
            object data = null,
            string[] tags = null,
            [CallerMemberName] string memberName = "",
            [CallerFilePath] string sourceFilePath = "",
            [CallerLineNumber] int sourceLineNumber = 0)
        {
            LogWithProperties(e.Message, LogEventLevel.Error, data, memberName, sourceFilePath, sourceLineNumber, e);
        }

        public void LogApiData(
            string apiData,
            object data = null,
            [CallerMemberName] string memberName = "",
            [CallerFilePath] string sourceFilePath = "",
            [CallerLineNumber] int sourceLineNumber = 0,
            string[] tags = null)
        {
            LogWithProperties(apiData, LogEventLevel.Information, data, memberName, sourceFilePath, sourceLineNumber);
        }

        private void LogWithProperties(string message, LogEventLevel level, object data, string callerFullTypeName, string callerMemberName, int sourceLineNumber, Exception exception = null)
        {
            var serializedData = data == null ? null : JsonConvert.SerializeObject(data);
            DateTime dateTimeUtc = DateTime.Now;
            var loggerWithProperties = Log.ForContext(new[]
            {
                new PropertyEnricher("Message", message),
                new PropertyEnricher("Level", level.ToString()),
                new PropertyEnricher("Data", serializedData),
                new PropertyEnricher("CallerMemberName", callerMemberName),
                new PropertyEnricher("CallerFullTypeName", callerFullTypeName),
                new PropertyEnricher("SourceLineNumber", sourceLineNumber),
                new PropertyEnricher("TimeInMilliseconds", DateTime.Now.ToLongTimeString()),
                new PropertyEnricher("Timestamp", dateTimeUtc.ToString()),
                new PropertyEnricher("DateTimeUtcPretty", dateTimeUtc.ToString("O")),
                new PropertyEnricher("Exception", exception == null ? null : JsonConvert.SerializeObject(exception)),
            });

            switch (level)
            {
                case LogEventLevel.Debug:
                    loggerWithProperties.Debug(message);
                    break;
                case LogEventLevel.Error:
                    loggerWithProperties.Error(exception, message);
                    break;
                case LogEventLevel.Fatal:
                    loggerWithProperties.Fatal(message);
                    break;
                case LogEventLevel.Information:
                    loggerWithProperties.Information(message, "Message", message);
                    break;
                case LogEventLevel.Verbose:
                    loggerWithProperties.Verbose(message);
                    break;
                case LogEventLevel.Warning:
                    loggerWithProperties.Warning(message);
                    break;
                default:
                    loggerWithProperties.Verbose(message);
                    break;
            }
        }
    }
}
