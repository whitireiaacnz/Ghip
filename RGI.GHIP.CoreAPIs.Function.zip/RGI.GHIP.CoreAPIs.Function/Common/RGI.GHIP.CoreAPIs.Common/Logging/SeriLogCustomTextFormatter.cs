﻿using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;
using Serilog.Events;
using Serilog.Formatting;

namespace RGI.GHIP.CoreAPIs.Common.Logging
{
    public class SeriLogCustomTextFormatter : ITextFormatter
    {
        public static string GetSerializedString(LogEvent logEvent)
        {
            Dictionary<string, object> dictionary = new Dictionary<string, object>();
            foreach (var item in logEvent.Properties)
            {
                object valueAsString = item.Value == null || item.Value.ToString() == "null" ?
                                           null :
                                           (item.Value as ScalarValue).Value;
                dictionary.Add(item.Key, valueAsString);
            }

            return JsonConvert.SerializeObject(dictionary);
        }

        public void Format(LogEvent logEvent, TextWriter output)
        {
            string serializedData = GetSerializedString(logEvent);
            output.WriteLineAsync(serializedData);
        }
    }
}
