﻿using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RGI.GHIP.CoreAPIs.Common.Models;

namespace RGI.GHIP.CoreAPIs.Common.Extensions
{
    public static class StringExtensions
    {
        public static List<int> StringToIntList(this string str)
        {
            // fails when string has no value
            try
            {
                return new List<int>(Array.ConvertAll(str.Split(), int.Parse));
            }
            catch (Exception)
            {
                return new List<int>();
            }
        }

        public static PESelfAllowedSumInsuredModel StringToGradeList(this string str, string allowedSumInsuredType)
        {
            // fails when string has no value
            try
            {
                if (allowedSumInsuredType.Contains("Grade"))
                {
                    List<string> grades = str.Split(',').ToList();
                    List<PEGradeSIModel> gradeSIModels = new List<PEGradeSIModel>();

                    if (grades.Count > 0)
                    {
                        for (int i = 0; i < grades.Count; i++)
                        {
                            string gradeWithSI = grades[i];
                            string[] separateGradeFromSI = gradeWithSI.Split("-");
                            PEGradeSIModel gradeModel = new PEGradeSIModel()
                            {
                                Grade = separateGradeFromSI[0].Trim(),
                                SumInsured = int.Parse(separateGradeFromSI[1]),
                            };

                            gradeSIModels.Add(gradeModel);
                        }
                    }

                    PESelfAllowedSumInsuredModel selfAllowedSumInsuredModel = new PESelfAllowedSumInsuredModel()
                    {
                        SumInsuredList = gradeSIModels,
                        SelfSumInsuredType = allowedSumInsuredType,
                    };
                    return selfAllowedSumInsuredModel;
                }
                else
                {
                    List<int> sumInsured = new List<int>(Array.ConvertAll(str.Split(), int.Parse));
                    List<PEGradeSIModel> gradeSIModels = new List<PEGradeSIModel>();
                    if (sumInsured.Count > 0)
                    {
                        for (int i = 0; i < sumInsured.Count; i++)
                        {
                            PEGradeSIModel gradeModel = new PEGradeSIModel()
                            {
                                Grade = null,
                                SumInsured = sumInsured[i],
                            };
                            gradeSIModels.Add(gradeModel);
                        }
                    }

                    PESelfAllowedSumInsuredModel selfAllowedSumInsuredModel = new PESelfAllowedSumInsuredModel()
                    {
                        SumInsuredList = gradeSIModels,
                        SelfSumInsuredType = allowedSumInsuredType,
                    };
                    return selfAllowedSumInsuredModel;
                }

                // return new List<PEGradeSIModel>(Array.ConvertAll(str.Split(), int.Parse));
            }
            catch (Exception)
            {
                return new PESelfAllowedSumInsuredModel();
            }
        }

        public static List<string> StringToList(this string str, string sep = " ")
        {
            // fails when string has no value
            try
            {
                return new List<string>(str.Split(sep));
            }
            catch (Exception)
            {
                return new List<string>();
            }
        }

        public static int StringToInt(this string str)
        {
            // fails when string has no value
            try
            {
                if (str != " " || !string.IsNullOrWhiteSpace(str) || !string.IsNullOrEmpty(str))
                {
                    return Convert.ToInt32(str.Trim());
                }

                return 0;
            }
            catch (Exception)
            {
                return 0;
            }
        }

        public static string FirstLetterUpper(this string str)
        {
            return str[0].ToString().ToUpper() + str.Remove(0, 1);
        }

        public static string StringToLowerAndRemovesAllExtraSpace(this string str)
        {
            // fails when string has no value
            try
            {
                return str.Replace(" ", string.Empty).ToLower().Trim();
            }
            catch (Exception)
            {
                return str;
            }
        }

        public static string GetWhiteSpaceIfStringIsNullOrEmpty(this string str)
        {
            return string.IsNullOrEmpty(str) ? " " : str;
        }

        public static bool CompareStrings(this string str1, string str2)
        {
            return str1.StringToLowerAndRemovesAllExtraSpace() == str2.StringToLowerAndRemovesAllExtraSpace();
        }

        public static bool IsPresentInList(this string str1, List<string> strList)
        {
            return strList.Find(s => s.CompareStrings(str1)) == null ? false : true;
        }

        public static bool IsExactMatchPresentInList(this string str1, List<string> strList)
        {
            return strList.Find(s => s == str1) == null ? false : true;
        }

        public static string GetObjectPropertyValue(this string strObject, string property)
        {
            try
            {
                return JObject.Parse(strObject).GetObjectPropertyStringValue(property);
            }
            catch (JsonReaderException)
            {
                return null;
            }
        }

        public static string GetDate(this string str)
        {
            try
            {
                return DateTime.Parse(str).Getddmmmyyyy();
            }
            catch (Exception e) when (e is ArgumentNullException || e is FormatException)
            {
                return null;
            }
        }
    }
}
