﻿using System;
using System.IO;
using Microsoft.AspNetCore.Http;

namespace RGI.GHIP.CoreAPIs.Common.Extensions
{
    public static class ValidFileExtension
    {
        public static bool IsValidFile(IFormFile file, bool onlyExcel = false, bool onlyImage = false)
        {
            string contenttype = string.Empty;

            Stream checkStream = file.OpenReadStream();
            BinaryReader chkBinary = new BinaryReader(checkStream);
            byte[] chkbytes = chkBinary.ReadBytes(0x10);
            string data_as_hex = BitConverter.ToString(chkbytes);
            string magicCheck = data_as_hex.Substring(0, 11);
            if (onlyExcel)
            {
                switch (magicCheck)
                {
                    case "50-46-49-4E":
                        contenttype = "text/xls";
                        break;
                    case "50-4B-03-04":
                        contenttype = "text/xlsx";
                        break;
                }
            }
            else if (onlyImage)
            {
                switch (magicCheck)
                {
                    case "FF-D8-FF-E1":
                        contenttype = "image/jpg";
                        break;
                    case "FF-D8-FF-E0":
                        contenttype = "image/jpeg";
                        break;
                    case "89-50-4E-47":
                        contenttype = "image/png";
                        break;
                }
            }
            else
            {
                switch (magicCheck)
                {
                    case "FF-D8-FF-E1":
                        contenttype = "image/jpg";
                        break;
                    case "FF-D8-FF-E0":
                        contenttype = "image/jpeg";
                        break;
                    case "25-50-44-46":
                        contenttype = "text/pdf";
                        break;
                    case "50-46-49-4E":
                        contenttype = "text/xls";
                        break;
                    case "50-4B-03-04":
                        contenttype = "text/xlsx";
                        break;
                    case "89-50-4E-47":
                        contenttype = "image/png";
                        break;
                    case "52-61-72-21":
                        contenttype = "file/rar";
                        break;
                }
            }

            if (contenttype != string.Empty)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
