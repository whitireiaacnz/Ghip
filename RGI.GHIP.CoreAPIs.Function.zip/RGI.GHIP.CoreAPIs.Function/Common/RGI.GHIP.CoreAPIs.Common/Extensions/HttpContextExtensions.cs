﻿using System;
using Microsoft.AspNetCore.Http;

namespace RGI.GHIP.CoreAPIs.Common.Extensions
{
    public static class HttpContextExtensions
    {
        public const string CORPORATEID = "CorporateId";

        public const string EMPLOYEEID = "EmployeeId";

        public const string ROLE = "Role";

        public const string ISMEMBER = "IsMember";

        public const string EMPLOYEEMAPPINDID = "EmployeeMappindId";

        public const string USERNAME = "UserName";

        public const string USERID = "UserId";

        public static string GetEmployeeId(this HttpContext httpContext)
        {
            return httpContext.User.FindFirst(EMPLOYEEID).Value;
        }

        public static string GetUserName(this HttpContext httpContext)
        {
            return httpContext.User.FindFirst(USERNAME).Value;
        }

        public static Guid GetUserId(this HttpContext httpContext)
        {
            return Guid.Parse(httpContext.User.FindFirst(USERID).Value);
        }

        public static int GetCorporateId(this HttpContext httpContext)
        {
            return int.Parse(httpContext.User.FindFirst(CORPORATEID).Value);
        }

        public static string GetRole(this HttpContext httpContext)
        {
            return httpContext.User.FindFirst(ROLE).Value;
        }

        public static bool IsMember(this HttpContext httpContext)
        {
            return httpContext.User.FindFirst(ISMEMBER).Value.CompareStrings("True");
        }

        public static Guid GetEmployeeMappindId(this HttpContext httpContext)
        {
            return Guid.Parse(httpContext.User.FindFirst(EMPLOYEEMAPPINDID).Value);
        }
    }
}
