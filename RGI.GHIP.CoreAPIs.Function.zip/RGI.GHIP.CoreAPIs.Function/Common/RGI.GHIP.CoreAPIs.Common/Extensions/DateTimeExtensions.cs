﻿using System;
using RGI.GHIP.CoreAPIs.Common.Helpers;

namespace RGI.GHIP.CoreAPIs.Common.Extensions
{
    public static class DateTimeExtensions
    {
        public static Age GetAgeFromDOB(this DateTime dateOfBirth)
        {
            var age = new Age(dateOfBirth, DateTime.Now.Date);
            if (age.Days > 0 || age.Months > 0)
            {
                return age;
            }
            else
            {
                return age;
            }
        }

        public static string Getddmmmyyyy(this DateTime dateOfBirth)
        {
            return dateOfBirth.ToString("dd MMM yyyy");
        }

        public static DateTime GetDateFromOA(this double dateOA)
        {
            var date = DateTime.FromOADate(dateOA);

            return date;
        }

        public static bool IsValidAgeLimit(this DateTime dob, int maxAge, int minAge, out string error)
        {
            Age age = new Age(DateTime.Now.Date);
            error = string.Empty;
            try
            {
                age = dob.GetAgeFromDOB();
            }
            catch (Exception)
            {
                error = $"Birthday date must be earlier than current date";
            }

            bool min = minAge <= age.Years;

            // max relationship
            bool max = true;
            if (maxAge < age.Years)
            {
                max = false;
            }
            else if (maxAge == age.Years)
            {
                max = age.Months == 0 && age.Days == 0;
            }

            if (!(max && min))
            {
                return false;
            }

            return true;
        }
    }
}
