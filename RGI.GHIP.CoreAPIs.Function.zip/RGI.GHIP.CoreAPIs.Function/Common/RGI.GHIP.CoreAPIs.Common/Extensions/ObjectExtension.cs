﻿using Newtonsoft.Json.Linq;

namespace RGI.GHIP.CoreAPIs.Common.Extensions
{
    public static class ObjectExtension
    {
        // use this to prevent null value exception
        public static JToken GetObjectPropertyValue(this JObject obj, string propertyName)
        {
            return string.IsNullOrEmpty(propertyName) ? string.Empty : obj[propertyName];
        }

        public static string GetObjectPropertyStringValue(this JObject obj, string propertyName)
        {
            if (obj[propertyName] == null)
            {
                return null;
            }

            return string.IsNullOrEmpty(propertyName) ? string.Empty : obj[propertyName].ToString();
        }

        public static string GetValueFromObject(this object obj, string propertyName)
        {
            string str = obj.GetType().GetProperty(propertyName).GetValue(obj, null).ToString();

            return str;
        }
    }
}
