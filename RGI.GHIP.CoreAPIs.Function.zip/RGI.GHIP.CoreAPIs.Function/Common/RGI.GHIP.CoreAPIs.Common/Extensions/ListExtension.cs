﻿using System;
using System.Collections.Generic;
using RGI.GHIP.CoreAPIs.Common.Models;

namespace RGI.GHIP.CoreAPIs.Common.Extensions
{
    public static class ListExtension
    {
        public static string ToStringWithCommaSeperatedValue<T>(
                                this List<T> list,
                                string propertyName = null)
        {
            string str = string.Empty;

            try
            {
                int i = 1;
                list.ForEach(x =>
                {
                    if (propertyName != null)
                    {
                        str += x.GetType().GetProperty(propertyName).GetValue(x).ToString();
                    }
                    else
                    {
                        str = str + x.ToString();
                    }

                    if (list.Count != i)
                    {
                        str += ", ";
                    }

                    i++;
                });

                return str;
            }
            catch (Exception)
            {
                return string.Empty;
            }
        }

        public static string ToStringWithCommaSeperatedValue<T>(
                               this List<T> list)
        {
            string str = string.Empty;

            try
            {
                int i = 1;
                list.ForEach(x =>
                {
                    str = str + x.ToString();

                    if (list.Count != i)
                    {
                        str += ", ";
                    }

                    i++;
                });

                return str;
            }
            catch (Exception)
            {
                return string.Empty;
            }
        }

        public static string ToStringWithSICommaSeperatedValue(
                               this List<PEGradeSIModel> list)
        {
            string str = string.Empty;

            try
            {
                int i = 1;
                list.ForEach(x =>
                {
                    str = str + x.SumInsured.ToString();

                    if (list.Count != i)
                    {
                        str += ", ";
                    }

                    i++;
                });

                return str;
            }
            catch (Exception)
            {
                return string.Empty;
            }
        }
    }
}
