﻿using System.Collections.Generic;
using AutoMapper;
using Newtonsoft.Json.Linq;
using RGI.GHIP.CoreAPIs.Common.Interfaces.IMapper;

namespace RGI.GHIP.CoreAPIs.Common.Mapper
{
    public class MapperExtension : IMapperExtension
    {
        private readonly IMapper _mapper;

        public MapperExtension(IMapper mapper)
        {
            _mapper = mapper;
        }

        public TDestination MapObjectTo<TDestination>(object source)
        {
            TDestination t = _mapper.Map<TDestination>(source);

            return t;
        }

        public List<TDestination> MapListTo<TDestination, TSource>(List<TSource> sourceList)
        {
            List<TDestination> destinationList = new List<TDestination>();

            if (sourceList == null)
            {
                return destinationList;
            }

            sourceList.ForEach(x =>
            {
                TDestination source = MapObjectTo<TDestination>(x);
                destinationList.Add(source);
            });

            return destinationList;
        }

        public TDestination MapToExisting<TDestination, TSource>(TDestination destination, TSource source)
        {
            return _mapper.Map(source, destination);
        }

        // TMemberModel property name should be similar to field master labels
        public TMemberModel MapJsonToModel<TMemberModel>(string fieldsJson)
        {
            var json = JObject.Parse(fieldsJson);
            JObject obj = new JObject();
            for (var x = json.First; x != null; x = x.Next)
            {
                obj.Add(x.Path.Replace("['", string.Empty).Replace("']", string.Empty).Replace(" ", string.Empty), x.Value<JProperty>().Value);
            }

            return obj.ToObject<TMemberModel>();
        }
    }
}
