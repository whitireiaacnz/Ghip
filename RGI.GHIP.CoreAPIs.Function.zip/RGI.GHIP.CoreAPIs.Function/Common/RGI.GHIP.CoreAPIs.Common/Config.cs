﻿using RGI.GHIP.CoreAPIs.Common.Models.Config;

namespace RGI.GHIP.CoreAPIs.Common
{
    public static class Config
    {
        public static ResourcesConfigModel Resources { get; set; } = new ResourcesConfigModel();

        public static SSOConfigModel SSO { get; set; } = new SSOConfigModel();

        public static RGIAPIConfigModel RGIAPI { get; set; } = new RGIAPIConfigModel();

        public static AuthorizationConfigModel Auth { get; set; } = new AuthorizationConfigModel();

        public static string GhipDB { get; set; }

        public static string WelcomeEmailSubject { get; set; }

        public static string CPWelcomeEmailSubject { get; set; }

        public static string ConfirmationEmailSubject { get; set; }

        public static string EmailSendApi { get; set; }

        public static string EmailSendApiKey { get; set; }

        public static string SMSSendApi { get; set; }

        public static string SMSSendApiKey { get; set; }

        public static string ProvisionApi { get; set; }

        public static string ProvisionResetApi { get; set; }

        public static string Authority { get; set; }

        public static string Audience { get; set; }

        public static string WebClient { get; set; }

        public static string MemberLoginUrl { get; set; }

        public static string Name { get; set; }

        public static string WelcomeEmailBcc { get; set; }

        public static string CredentialsApi { get; set; }

        public static string CorporatePortalBaseUrl { get; set; }

        public static string CorporatePortalClaimBaseUrl { get; set; }

        public static string GstFile { get; set; }

        public static string EmailAttachment { get; set; }

        public static string JobUploadFile { get; set; }

        public static string MemberUpload { get; set; }
    }
}
