﻿using System.Collections.Generic;
using FluentValidation.Results;
using Microsoft.AspNetCore.Mvc;
using RGI.GHIP.CoreAPIs.Common.Interfaces.Helpers;
using RGI.GHIP.CoreAPIs.Common.Validators;

namespace RGI.GHIP.CoreAPIs.Common.Helpers
{
    public class ErrorResponseHelper : IErrorResponseHelper
    {
        private readonly IConversionHelper _conversionHelper;

        public ErrorResponseHelper(IConversionHelper conversionHelper)
        {
            _conversionHelper = conversionHelper;
        }

        public List<ErrorResponseModel> GetErrorResponseModel(List<ValidationResult> validationResults)
        {
            List<ErrorResponseModel> errorResponses = new List<ErrorResponseModel>();
            foreach (var validationResult in validationResults)
            {
                ErrorResponseModel errorResponse = new ErrorResponseModel();

                foreach (var error in validationResult.Errors)
                {
                    var errorModel = new ErrorModel
                    {
                        FieldName = error.PropertyName,
                        Message = error.ErrorMessage,
                    };

                    errorResponse.Errors.Add(errorModel);
                }

                if (errorResponse.Errors.Count > 0)
                {
                    errorResponses.Add(errorResponse);
                }
            }

            return errorResponses;
        }

        public List<ErrorResponseModel> GetErrorResponseModel(List<ErrorModel> errors)
        {
            List<ErrorResponseModel> errorResponses = new List<ErrorResponseModel>();
            ErrorResponseModel errorResponse = new ErrorResponseModel
            {
                Errors = errors,
            };
            errorResponses.Add(errorResponse);

            return errorResponses;
        }

        public List<ErrorResponseModel> GetErrorResponseModel(ValidationResult validationResultData)
        {
            List<ErrorResponseModel> errorResponses = new List<ErrorResponseModel>();
            List<ValidationResult> validationResults = new List<ValidationResult>
            {
                validationResultData,
            };

            foreach (var validationResult in validationResults)
            {
                ErrorResponseModel errorResponse = new ErrorResponseModel();

                foreach (var error in validationResult.Errors)
                {
                    var errorModel = new ErrorModel
                    {
                        FieldName = error.PropertyName,
                        Message = error.ErrorMessage,
                    };

                    errorResponse.Errors.Add(errorModel);
                }

                if (errorResponse.Errors.Count > 0)
                {
                    errorResponses.Add(errorResponse);
                }
            }

            return errorResponses;
        }

        public List<ErrorResponseModel> GetErrorResponseModel(string errorMessage, string propertyName)
        {
            List<ErrorResponseModel> errorResponses = new List<ErrorResponseModel>();
            List<ValidationResult> validationResults = new List<ValidationResult>();
            ValidationResult validationResult = new ValidationResult();
            validationResult.Errors.Add(new ValidationFailure(propertyName, errorMessage));
            validationResults.Add(validationResult);

            foreach (var vResult in validationResults)
            {
                ErrorResponseModel errorResponse = new ErrorResponseModel();

                foreach (var error in vResult.Errors)
                {
                    var errorModel = new ErrorModel
                    {
                        FieldName = error.PropertyName,
                        Message = error.ErrorMessage,
                    };

                    errorResponse.Errors.Add(errorModel);
                }

                if (errorResponse.Errors.Count > 0)
                {
                    errorResponses.Add(errorResponse);
                }
            }

            return errorResponses;
        }

        public List<ErrorResponseModel> GetErrorResponseModel(IActionResult actionResult, string propertyName)
        {
            List<ErrorResponseModel> errorResponses = new List<ErrorResponseModel>();
            List<ValidationResult> validationResults = new List<ValidationResult>();
            ValidationResult validationResult = new ValidationResult();
            validationResult.Errors.Add(new ValidationFailure(propertyName, _conversionHelper.GetValueFromObject(actionResult, "Value")));
            validationResults.Add(validationResult);

            foreach (var vResult in validationResults)
            {
                ErrorResponseModel errorResponse = new ErrorResponseModel();

                foreach (var error in vResult.Errors)
                {
                    var errorModel = new ErrorModel
                    {
                        FieldName = error.PropertyName,
                        Message = error.ErrorMessage,
                    };

                    errorResponse.Errors.Add(errorModel);
                }

                if (errorResponse.Errors.Count > 0)
                {
                    errorResponses.Add(errorResponse);
                }
            }

            return errorResponses;
        }
    }
}
