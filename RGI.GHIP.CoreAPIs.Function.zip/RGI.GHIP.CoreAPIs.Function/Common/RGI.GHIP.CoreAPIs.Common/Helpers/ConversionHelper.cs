﻿using RGI.GHIP.CoreAPIs.Common.Interfaces.Helpers;

namespace RGI.GHIP.CoreAPIs.Common.Helpers
{
    public class ConversionHelper : IConversionHelper
    {
        public string GetValueFromObject(object obj, string propertyName)
        {
            string str = obj.GetType().GetProperty(propertyName).GetValue(obj, null).ToString();

            return str;
        }
    }
}
