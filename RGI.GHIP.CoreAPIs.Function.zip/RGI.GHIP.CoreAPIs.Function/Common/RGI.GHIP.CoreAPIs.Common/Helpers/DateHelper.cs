﻿using System;
using RGI.GHIP.CoreAPIs.Common.Interfaces.Helpers;

namespace RGI.GHIP.CoreAPIs.Common.Helpers
{
    public class DateHelper : IDateHelper
    {
        public int GetAgeFromDOB(DateTime dateOfBirth)
        {
            return DateTime.Today.Year - dateOfBirth.Year;
        }

        public DateTime GetDateFromOA(double dateOA)
        {
            var date = DateTime.FromOADate(dateOA);

            return date;
        }

        public DateTime GetCurrentDateUtcNow()
        {
            var date = DateTime.UtcNow.Date;

            return date;
        }
    }
}
