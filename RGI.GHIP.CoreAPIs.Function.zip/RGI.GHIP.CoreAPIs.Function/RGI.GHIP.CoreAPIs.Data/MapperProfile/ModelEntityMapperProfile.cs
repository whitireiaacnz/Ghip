﻿using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RGI.GHIP.CoreAPIs.Common.Extensions;
using RGI.GHIP.CoreAPIs.Common.Models;
using RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal;
using RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal.Biz_admin;
using RGI.GHIP.CoreAPIs.Common.Models.Email;
using RGI.GHIP.CoreAPIs.Common.Models.Master;
using RGI.GHIP.CoreAPIs.Common.Models.Member;
using RGI.GHIP.CoreAPIs.Common.Models.RGI;
using RGI.GHIP.CoreAPIs.Data.Entities;
using RGI.GHIP.CoreAPIs.Data.Entities.CorporatePortal;
using RGI.GHIP.CoreAPIs.Data.Entities.Masters;
using RGI.GHIP.CoreAPIs.Data.Entities.Masters.AddressMasters;
using RGI.GHIP.CoreAPIs.Data.Entities.PreEnrollment;
using RGI.GHIP.CoreAPIs.Data.Entities.RGI;

namespace RGI.GHIP.CoreAPIs.Mapper
{
    public class ModelEntityMapperProfile : Profile
    {
        public ModelEntityMapperProfile()
        {
            Preenrollment();

            CorporatePortal();

            RGI();

            MapCorporates();

            MapPolicies();

            MapFields();

            MapRelationships();

            MapPeriods();

            MapMembers();

            MapRoles();

            MapUser();

            MapEmailTemplate();

            MapEmail();

            MapAddressMaster();

            MapGlobalConfig();

            MapExtraBenefits();

            MapSelfSIValues();

            MapPSIValues();

            MapESIValues();

            MapTopUpValues();

            MapPremiumData();

            MapJobData();
        }

        private void MapJobData()
        {
            CreateMap<JobModel, JobEntity>();
            CreateMap<JobEntity, JobModel>();
        }

        private void MapGlobalConfig()
        {
            CreateMap<ConfigModel, ConfigEntity>()
            .ForMember(destination => destination.Id, map => map.MapFrom(source => source.Id));
            CreateMap<ConfigEntity, ConfigModel>()
            .ForMember(destination => destination.Id, map => map.MapFrom(source => source.Id));
        }

        private void RGI()
        {
            CreateMap<RGICPPolicyModel, RGICPPolicyEntity>();
            CreateMap<RGICPPolicyEntity, RGICPPolicyModel>();

            CreateMap<RGICPMemberEntity, RGICPMemberModel>()
            .ForMember(destination => destination.DOJ, map => map.MapFrom(source => source.DateOfJoining));
            CreateMap<RGICPMemberModel, RGICPMemberEntity>()
            .ForMember(destination => destination.DateOfJoining, map => map.MapFrom(source => source.DOJ));

            CreateMap<RGIBrokerMasterEntity, RGIBrokerMasterModel>();
            CreateMap<RGIBrokerMasterModel, RGIBrokerMasterEntity>();

            CreateMap<RGISMMasterEntity, RGISMMasterModel>();
            CreateMap<RGISMMasterModel, RGISMMasterEntity>();
        }

        private void Preenrollment()
        {
            CreateMap<PEPolicyVersionEntity, PEHistoryPolicyModel>()
            .ForMember(destination => destination.AllowedSumInsured, map => map.MapFrom(source => source.AllowedSumInsured.StringToGradeList(source.AllowedSumInsuredType)));
            CreateMap<PEHistoryPolicyModel, PEPolicyVersionEntity>()
            .ForMember(destination => destination.AllowedSumInsured, map => map.MapFrom(source =>
              (source.AllowedSumInsured.SelfSumInsuredType.StartsWith("Grade") ? string.Join(", ", source.AllowedSumInsured.SumInsuredList.Select(x =>
                 string.Join("-", new[] { x.Grade, x.SumInsured.ToString() }))) : string.Join(" ", source.AllowedSumInsured.SumInsuredList.Select(x =>
              string.Join(string.Empty, new[] { x.SumInsured.ToString() }))))));

            CreateMap<PEExtraBenefitsHistoryEntity, PEExtraBenefitsHistoryModel>();
            CreateMap<PEExtraBenefitsHistoryModel, PEExtraBenefitsHistoryEntity>();

            CreateMap<PEParentInsuranceHistoryEntity, PEParentInsuranceHistoryPremiumModel>();
            CreateMap<PEParentInsuranceHistoryPremiumModel, PEParentInsuranceHistoryEntity>()
            .ForMember(destination => destination.ParentInsuranceId, map => map.MapFrom(source => source.ParentInsuranceId))
            .ForMember(destination => destination.PEPolicyId, map => map.MapFrom(source => source.PEPolicyId))
            .ForMember(destination => destination.ExtraBenefitsId, map => map.MapFrom(source => source.ExtraBenefitsId));

            CreateMap<PEEnhanceSumInsuredHistoryEntity, PEEnhanceSumInsuredPremiumHistoryModel>();
            CreateMap<PEEnhanceSumInsuredPremiumHistoryModel, PEEnhanceSumInsuredHistoryEntity>()
            .ForMember(destination => destination.EnhanceSumInsuranceId, map => map.MapFrom(source => source.EnhanceSumInsuranceId))
            .ForMember(destination => destination.PEPolicyId, map => map.MapFrom(source => source.PEPolicyId))
            .ForMember(destination => destination.ExtraBenefitsId, map => map.MapFrom(source => source.ExtraBenefitsId));

            CreateMap<PETopUpInsuranceHistoryEntity, PETopUpInsurancePremiumHistoryModel>();
            CreateMap<PETopUpInsurancePremiumHistoryModel, PETopUpInsuranceHistoryEntity>()
            .ForMember(destination => destination.PETopupInsuranceID, map => map.MapFrom(source => source.PETopupInsuranceID))
            .ForMember(destination => destination.PEPolicyId, map => map.MapFrom(source => source.PEPolicyId))
            .ForMember(destination => destination.ExtraBenefitsId, map => map.MapFrom(source => source.ExtraBenefitsId));
        }

        private void CorporatePortal()
        {
            CreateMap<CPEndorsementMemberModel, CPEndorsementMemberEntity>()
                .ForMember(destination => destination.ApproveRejectFlow, opt =>
                {
                    opt.PreCondition(src => src.ApproveRejectFlowModel != null);
                    opt.MapFrom(src => JsonConvert.SerializeObject(src.ApproveRejectFlowModel));
                });

            CreateMap<CPEndorsementMemberEntity, CPEndorsementMemberModel>()
                .ForMember(dest => dest.ApproveRejectFlowModel, opt =>
                {
                    opt.PreCondition(src => !(string.IsNullOrEmpty(src.ApproveRejectFlow) || src.ApproveRejectFlow == "null"));
                    opt.MapFrom(src => JObject.Parse(src.ApproveRejectFlow).ToObject<CPApproveRejectFlowModel>());
                });
            CreateMap<CPNotificationEntity, CPNotificationModel>()
              .ForMember(destination => destination.SpecificCorporate, map => map.MapFrom(source => source.SpecificCorporate))
              .ForMember(destination => destination.SpecificPolicy, map => map.MapFrom(source => source.SpecificPolicy))
              ;

            CreateMap<CPNotificationModel, CPNotificationEntity>()
              .ForMember(destination => destination.SpecificPolicy, map => map.MapFrom(source => source.SpecificPolicy))
              .ForMember(destination => destination.SpecificCorporate, map => map.MapFrom(source => source.SpecificCorporate))
              ;

            CreateMap<CPEmployeeNotificationMappingEntity, CPEmployeeNotificationMappingModel>();
            CreateMap<CPEmployeeNotificationMappingModel, CPEmployeeNotificationMappingEntity>();

            CreateMap<CPPolicyEntity, CPPolicyModel>();
            CreateMap<CPPolicyModel, CPPolicyEntity>();

            CreateMap<CPPolicyVersionEntity, CPHistoryPolicyModel>();
            CreateMap<CPHistoryPolicyModel, CPPolicyVersionEntity>();

            CreateMap<CPPolicyVersionMemberFeatureEntity, CPPolicyMemberFeaturesVersionModel>();
            CreateMap<CPPolicyMemberFeaturesVersionModel, CPPolicyVersionMemberFeatureEntity>();

            CreateMap<CPPolicyMemberFeaturesEntity, CPPolicyMemberFeaturesModel>()
              .ForMember(destination => destination.PolicyId, map => map.MapFrom(source => source.CPPolicyId));

            CreateMap<CPPolicyMemberFeaturesModel, CPPolicyMemberFeaturesEntity>()
              .ForMember(destination => destination.CPPolicyId, map => map.MapFrom(source => source.PolicyId));

            CreateMap<CPMembersEntity, CPMemberModel>()
            .ForMember(destination => destination.Gender, map => map.MapFrom(source => source.Sex));
            CreateMap<CPMemberModel, CPMembersEntity>()
              .ForMember(destination => destination.CPPolicyId, map => map.MapFrom(source => source.CPPolicyId))
              .ForMember(destination => destination.Sex, map => map.MapFrom(source => source.Gender));

            CreateMap<CPMembersEntity, CPMemberSummaryModel>();
            CreateMap<CPMemberSummaryModel, CPMembersEntity>()
              .ForMember(destination => destination.CPPolicyId, map => map.MapFrom(source => source.CPPolicyId));

            CreateMap<CPHRMappingEntity, CPHRMappingModel>()
              .ForMember(destination => destination.CommCodes, map => map.MapFrom(source => source.CommCodes.Trim().StringToList(", ")));
            CreateMap<CPHRMappingModel, CPHRMappingEntity>()
              .ForMember(destination => destination.CommCodes, map => map.MapFrom(source => source.CommCodes.ToStringWithCommaSeperatedValue()));

            CreateMap<CPCorporateEmployeeEntity, CPCorporateEmployeeModel>();
            CreateMap<CPCorporateEmployeeModel, CPCorporateEmployeeEntity>();

            CreateMap<CPBrokerPolicyMappingEntity, CPBrokerPolicyMappingModel>()
              .ForMember(destination => destination.CPPolicyId, map => map.MapFrom(source => source.CPPolicyId));

            CreateMap<CPBrokerPolicyMappingModel, CPBrokerPolicyMappingEntity>()
              .ForMember(destination => destination.CPPolicyId, map => map.MapFrom(source => source.CPPolicyId));

            CreateMap<BrokerMasterModel, BrokerMasterEntity>();
            CreateMap<BrokerMasterEntity, BrokerMasterModel>();

            CreateMap<CPSMPolicyMappingEntity, CPSMpolicyMappingModel>()
              .ForMember(destination => destination.CPPolicyId, map => map.MapFrom(source => source.CPPolicyId));
            CreateMap<CPSMpolicyMappingModel, CPSMPolicyMappingEntity>()
              .ForMember(destination => destination.CPPolicyId, map => map.MapFrom(source => source.CPPolicyId));

            CreateMap<SMMasterModel, SMMasterEntity>();
            CreateMap<SMMasterEntity, SMMasterModel>();

            CreateMap<CPDocumentModel, CPDocumentEntity>()
              .ForMember(destination => destination.CPPolicyId, map => map.MapFrom(source => source.PolicyId));

            CreateMap<CPDocumentEntity, CPDocumentModel>()
              .ForMember(destination => destination.PolicyId, map => map.MapFrom(source => source.CPPolicyId));

            CreateMap<CPHRCommCodeMappingEntity, CPHRCommCodeMappingModel>()
            .ForMember(destination => destination.CommunicationCode, map => map.MapFrom(source => source.CommunicationCode));
            CreateMap<CPHRCommCodeMappingModel, CPHRCommCodeMappingEntity>();

            CreateMap<CommunicationEntity, CommunicationModel>();
            CreateMap<CommunicationModel, CommunicationEntity>();
        }

        private void MapAddressMaster()
        {
            CreateMap<StateMasterEntity, StateMasterModel>();
            CreateMap<StateMasterModel, StateMasterEntity>();

            CreateMap<DistrictMasterModel, DistrictMasterEntity>();
            CreateMap<DistrictMasterEntity, DistrictMasterModel>();

            CreateMap<AreaMasterEntity, AreaMasterModel>();
            CreateMap<AreaMasterModel, AreaMasterEntity>();

            CreateMap<CityOrVillageMasterEntity, CityOrVillageMasterModel>();
            CreateMap<CityOrVillageMasterModel, CityOrVillageMasterEntity>();

            CreateMap<RegionMasterEntity, RegionMasterModel>();
            CreateMap<RegionMasterModel, RegionMasterEntity>();
        }

        private void MapEmail()
        {
            CreateMap<PEMemberEntity, EmailMemberModel>()
                .ForMember(destination => destination.Id, map => map.MapFrom(source => source.Id))
                .ForMember(destination => destination.EmployeeId, map => map.MapFrom(source => source.EmpId))
                ;

            CreateMap<PEPolicyEntity, EmailPolicyModel>()
                .ForMember(destination => destination.PolicyName, map => map.MapFrom(source => source.Name))
                .ForMember(destination => destination.PolicyPlan, map => map.MapFrom(source => source.Plan))
                .ForMember(destination => destination.PolicyYear, map => map.MapFrom(source => source.Year))
                .ForMember(destination => destination.PolicySumsInsured, map => map.MapFrom(source => source.AllowedSumInsured))
                .ForMember(destination => destination.PolicyStartDate, map => map.MapFrom(source => source.StartDate))
                .ForMember(destination => destination.PolicyEndDate, map => map.MapFrom(source => source.EndDate));
        }

        private void MapEmailTemplate()
        {
            CreateMap<PEEmailTemplateEntity, PEEmailTemplateModel>()
                .ForMember(destination => destination.Id, map => map.MapFrom(source => source.Id));

            CreateMap<PEEmailTemplateModel, PEEmailTemplateEntity>()
                .ForMember(destination => destination.Id, map => map.MapFrom(source => source.Id));
        }

        private void MapPeriods()
        {
            CreateMap<PEPeriodEntity, PEPeriodModel>()
                .ForMember(destination => destination.Id, map => map.MapFrom(source => source.Id))
                .ForMember(destination => destination.StartDate, map => map.MapFrom(source => source.StartDateTime))
                .ForMember(destination => destination.EndDate, map => map.MapFrom(source => source.EndDateTime));

            CreateMap<PEPeriodModel, PEPeriodEntity>()
                .ForMember(destination => destination.Id, map => map.MapFrom(source => source.Id))
                .ForMember(destination => destination.StartDateTime, map => map.MapFrom(source => source.StartDate))
                .ForMember(destination => destination.EndDateTime, map => map.MapFrom(source => source.EndDate));
        }

        private void MapMembers()
        {
            CreateMap<PEMemberEntity, PEMemberFieldsSummaryModel>()
                .ForMember(destination => destination.EmployeeId, map => map.MapFrom(source => source.EmpId))
                .ForMember(destination => destination.FieldsJson, map => map.MapFrom(source => source.FieldsJson))
                .ForMember(destination => destination.ConfirmationEmailSentAt, map => map.MapFrom(source => source.ConfirmationEmailSentAt))
                .ForMember(destination => destination.ConfirmationEmailErrorReason, map => map.MapFrom(source => source.ConfirmationEmailErrorReason))
                .ForMember(destination => destination.ConfirmationEmailSentTrials, map => map.MapFrom(source => source.ConfirmationEmailSentTrials))
                .ForMember(destination => destination.WelcomeEmailSentAt, map => map.MapFrom(source => source.WelcomeEmailSentAt))
                .ForMember(destination => destination.IsWelcomeEmailSent, map => map.MapFrom(source => source.IsWelcomeEmailSent))
                .ForMember(destination => destination.WelcomeEmailErrorReason, map => map.MapFrom(source => source.WelcomeEmailErrorReason))
                .ForMember(destination => destination.ModifiedAt, map => map.MapFrom(source => source.ModifiedAt))
                .ForMember(destination => destination.RelationshipId, map => map.MapFrom(source => source.RelationshipMasterId))
                .ForMember(destination => destination.Id, map => map.MapFrom(source => source.Id));

            CreateMap<PEMemberEntity, PEMemberModel>()
                .ForMember(destination => destination.FieldsJson, map => map.MapFrom(source => source.FieldsJson))
                .ForMember(destination => destination.ConfirmationEmailSentAt, map => map.MapFrom(source => source.ConfirmationEmailSentAt))
                .ForMember(destination => destination.ConfirmationEmailErrorReason, map => map.MapFrom(source => source.ConfirmationEmailErrorReason))
                .ForMember(destination => destination.ConfirmationEmailSentTrials, map => map.MapFrom(source => source.ConfirmationEmailSentTrials))
                .ForMember(destination => destination.WelcomeEmailSentAt, map => map.MapFrom(source => source.WelcomeEmailSentAt))
                .ForMember(destination => destination.IsWelcomeEmailSent, map => map.MapFrom(source => source.IsWelcomeEmailSent))
                .ForMember(destination => destination.WelcomeEmailErrorReason, map => map.MapFrom(source => source.WelcomeEmailErrorReason))
                .ForMember(destination => destination.ModifiedAt, map => map.MapFrom(source => source.ModifiedAt))
                .ForMember(destination => destination.RelationshipId, map => map.MapFrom(source => source.RelationshipMasterId))
                .ForMember(destination => destination.EmployeeId, map => map.MapFrom(source => source.EmpId))
                .ForMember(destination => destination.Id, map => map.MapFrom(source => source.Id));

            CreateMap<PEMemberFieldsSummaryModel, PEMemberEntity>()
                .ForMember(destination => destination.RelationshipMasterId, map => map.MapFrom(source => source.RelationshipId))
                .ForMember(destination => destination.Id, map => map.MapFrom(source => source.Id))
                .ForMember(destination => destination.EmpId, map => map.MapFrom(source => source.FieldsData.EmployeeId))
                ;

            CreateMap<PEMemberModel, PEMemberEntity>()
                 .ForMember(destination => destination.FieldsJson, map => map.MapFrom(source => source.FieldsJson))
                .ForMember(destination => destination.ConfirmationEmailSentAt, map => map.MapFrom(source => source.ConfirmationEmailSentAt))
                .ForMember(destination => destination.ConfirmationEmailErrorReason, map => map.MapFrom(source => source.ConfirmationEmailErrorReason))
                .ForMember(destination => destination.ConfirmationEmailSentTrials, map => map.MapFrom(source => source.ConfirmationEmailSentTrials))
                .ForMember(destination => destination.WelcomeEmailSentAt, map => map.MapFrom(source => source.WelcomeEmailSentAt))
                .ForMember(destination => destination.IsWelcomeEmailSent, map => map.MapFrom(source => source.IsWelcomeEmailSent))
                .ForMember(destination => destination.WelcomeEmailErrorReason, map => map.MapFrom(source => source.WelcomeEmailErrorReason))
                .ForMember(destination => destination.ModifiedAt, map => map.MapFrom(source => source.ModifiedAt))
                .ForMember(destination => destination.RelationshipMasterId, map => map.MapFrom(source => source.RelationshipId))
                .ForMember(destination => destination.Id, map => map.MapFrom(source => source.Id))
                .ForMember(destination => destination.EmpId, map => map.MapFrom(source => source.EmployeeId))
                ;
        }

        private void MapRoles()
        {
            CreateMap<RoleEntity, RoleModel>()
                .ForMember(destination => destination.Id, map => map.MapFrom(source => source.Id));

            CreateMap<RoleModel, RoleEntity>()
                .ForMember(destination => destination.Id, map => map.MapFrom(source => source.Id));
        }

        private void MapUser()
        {
            CreateMap<UserEntity, UserModel>()
                .ForMember(destination => destination.Id, map => map.MapFrom(source => source.Id));

            CreateMap<UserModel, UserEntity>()
                .ForMember(destination => destination.Id, map => map.MapFrom(source => source.Id));
        }

        private void MapRelationships()
        {
            CreateMap<PERelationshipMasterEntity, PERelationshipMasterModel>()
                 .ForMember(destination => destination.RelationshipId, map => map.MapFrom(source => source.Id))
                 ;

            CreateMap<PEPolicyRelationshipMappingEntity, PERelationshipMasterModel>()
                .ForMember(destination => destination.PolicyId, map => map.MapFrom(source => source.PreEnrollmentPolicyId))
                .ForMember(destination => destination.IsEnabled, map => map.MapFrom(source => !source.IsDeleted))
                .ForMember(destination => destination.IsDeletedMapping, map => map.MapFrom(source => source.IsDeleted))
                .ForMember(destination => destination.MappingId, map => map.MapFrom(source => source.Id))
                .ForMember(destination => destination.Gender, map => map.MapFrom(source => source.RelationshipMaster.Gender))
                .ForMember(destination => destination.Type, map => map.MapFrom(source => source.RelationshipMaster.Type))
                .ForMember(destination => destination.IsConfigurable, map => map.MapFrom(source => source.RelationshipMaster.IsConfigurable))
                .ForMember(destination => destination.Label, map => map.MapFrom(source => source.RelationshipMaster.Label))
                .ForMember(destination => destination.RelationshipId, map => map.MapFrom(source => source.RelationshipMasterId))
                ;

            CreateMap<PERelationshipMasterModel, PEPolicyRelationshipMappingEntity>()
                .ForMember(destination => destination.PreEnrollmentPolicyId, map => map.MapFrom(source => source.PolicyId))
                .ForMember(destination => destination.Id, map => map.MapFrom(source => source.MappingId))
                .ForMember(destination => destination.RelationshipMasterId, map => map.MapFrom(source => source.RelationshipId))
                .ForMember(destination => destination.IsDeleted, map => map.MapFrom(source => source.IsDeletedMapping));

            CreateMap<PERelationshipMasterModel, PERelationshipMasterEntity>()
                .ForMember(destination => destination.Id, map => map.MapFrom(source => source.RelationshipId));
        }

        private void MapFields()
        {
            CreateMap<PEFieldMasterEntity, PEFieldMasterModel>()
                .ForMember(destination => destination.FieldId, map => map.MapFrom(source => source.Id));

            CreateMap<PEFieldMasterModel, PEFieldMasterEntity>()
                .ForMember(destination => destination.Id, map => map.MapFrom(source => source.FieldId));

            CreateMap<PEFieldMasterModel, PEPolicyFieldMappingEntity>()
                .ForMember(destination => destination.PreEnrollmentPolicyId, map => map.MapFrom(source => source.PolicyId))
                .ForMember(destination => destination.IsDeleted, map => map.MapFrom(source => source.IsDeletedMapping))
                .ForMember(destination => destination.Id, map => map.MapFrom(source => source.MappingId))
                .ForMember(destination => destination.FieldMasterId, map => map.MapFrom(source => source.FieldId));

            CreateMap<PEPolicyFieldMappingEntity, PEFieldMasterModel>()
                .ForMember(destination => destination.PolicyId, map => map.MapFrom(source => source.PreEnrollmentPolicyId))
                .ForMember(destination => destination.IsEnabled, map => map.MapFrom(source => !source.IsDeleted))
                .ForMember(destination => destination.IsDeletedMapping, map => map.MapFrom(source => source.IsDeleted))
                .ForMember(destination => destination.IsConfigurable, map => map.MapFrom(source => source.FieldMaster.IsConfigurable))
                .ForMember(destination => destination.Label, map => map.MapFrom(source => source.FieldMaster.Label))
                .ForMember(destination => destination.Section, map => map.MapFrom(source => source.FieldMaster.Section))
                .ForMember(destination => destination.Validation, map => map.MapFrom(source => source.FieldMaster.Validation))
                .ForMember(destination => destination.DropDownValues, map => map.MapFrom(source => source.FieldMaster.DropDownValues))
                .ForMember(destination => destination.Type, map => map.MapFrom(source => source.FieldMaster.Type))
                .ForMember(destination => destination.InputType, map => map.MapFrom(source => source.FieldMaster.InputType))
                .ForMember(destination => destination.FieldId, map => map.MapFrom(source => source.FieldMasterId))
                .ForMember(destination => destination.MappingId, map => map.MapFrom(source => source.Id));
        }

        private void MapExtraBenefits()
        {
            CreateMap<PEExtraBenefitsModel, PEExtraBenefitsEntity>()
            .ForMember(destination => destination.Id, map => map.MapFrom(source => source.Id))
            .ForMember(destination => destination.PEPolicyId, map => map.MapFrom(source => source.PEPolicyId))
            .ForMember(destination => destination.SumInsuredType, map => map.MapFrom(source => source.SumInsuredType))
            .ForMember(destination => destination.Relationship, map => map.MapFrom(source => source.Relationship))
            .ForMember(destination => destination.BenefitType, map => map.MapFrom(source => source.BenefitType))
            .ForMember(destination => destination.IsAllowed, map => map.MapFrom(source => source.IsAllowed));

            CreateMap<PEExtraBenefitsEntity, PEExtraBenefitsModel>()
            .ForMember(destination => destination.Id, map => map.MapFrom(source => source.Id))
            .ForMember(destination => destination.PEPolicyId, map => map.MapFrom(source => source.PEPolicyId))
            .ForMember(destination => destination.SumInsuredType, map => map.MapFrom(source => source.SumInsuredType))
            .ForMember(destination => destination.Relationship, map => map.MapFrom(source => source.Relationship))
            .ForMember(destination => destination.BenefitType, map => map.MapFrom(source => source.BenefitType))
            .ForMember(destination => destination.IsAllowed, map => map.MapFrom(source => source.IsAllowed));
        }

        private void MapPremiumData()
        {
            CreateMap<PEParentInsurancePremiumModel, PEParentInsurancePremiumEntity>();

            CreateMap<PEParentInsurancePremiumEntity, PEParentInsurancePremiumModel>();

            CreateMap<PEEnhanceSumInsurancePremiumModel, PEEnhanceSumInsurancePremiumEntity>();

            CreateMap<PEEnhanceSumInsurancePremiumEntity, PEEnhanceSumInsurancePremiumModel>();

            CreateMap<PETopupPremiumModel, PETopupPremiumEntity>();

            CreateMap<PETopupPremiumEntity, PETopupPremiumModel>();

            CreateMap<PESelfSumInsurancePremiumModel, PESelfSumInsurancePremiumEntity>();

            CreateMap<PESelfSumInsurancePremiumEntity, PESelfSumInsurancePremiumModel>();
        }

        private void MapPSIValues()
        {
            CreateMap<PEPSIModel, PEParentInsuranceEntity>();

            CreateMap<PEParentInsuranceEntity, PEPSIModel>();
        }

        private void MapSelfSIValues()
        {
            CreateMap<PESelfModel, PESelfInsuranceEntity>();

            CreateMap<PESelfInsuranceEntity, PESelfModel>();
        }

        private void MapESIValues()
        {
            CreateMap<PEESIModel, PEEnhanceSumInsuredEntity>();

            CreateMap<PEEnhanceSumInsuredEntity, PEESIModel>();
        }

        private void MapTopUpValues()
        {
            CreateMap<PETopUpInsuranceModel, PETopUpInsuranceEntity>();

            CreateMap<PETopUpInsuranceEntity, PETopUpInsuranceModel>();

            CreateMap<PETopUpInsuranceListModel, PETopUpInsuranceEntity>();

            CreateMap<PETopUpInsuranceEntity, PETopUpInsuranceListModel>();
        }

        private void MapPolicies()
        {
            CreateMap<PEPolicyModel, PEPolicyEntity>()
              .ForMember(destination => destination.AllowedSumInsured, map => map.MapFrom(source =>
              (source.AllowedSumInsured.SelfSumInsuredType.StartsWith("Grade") ? string.Join(", ", source.AllowedSumInsured.SumInsuredList.Select(x =>
                 string.Join("-", new[] { x.Grade, x.SumInsured.ToString() }))) : string.Join(" ", source.AllowedSumInsured.SumInsuredList.Select(x =>
              string.Join(string.Empty, new[] { x.SumInsured.ToString() }))))))
              .ForMember(destination => destination.PasswordPolicy, map => map.MapFrom(source => source.PasswordPolicy))
              .ForMember(destination => destination.Plan, map => map.MapFrom(source => source.Plan))
              .ForMember(destination => destination.AllowDeletingMember, map => map.MapFrom(source => source.AllowDeletingMember))
              .ForMember(destination => destination.AllowEmployeeEditHisProfile, map => map.MapFrom(source => source.AllowEmployeeEditProfile))
              .ForMember(destination => destination.AllowHRResetProfile, map => map.MapFrom(source => source.AllowHRResetEmployeeDetails))
              .ForMember(destination => destination.AllowEmployeeViewHisProfile, map => map.MapFrom(source => source.AllowEmployeeViewProfile))
              .ForMember(destination => destination.PolicyRelationshipMappings, map => map.MapFrom(source => source.Relationships))
              .ForMember(destination => destination.PolicyFieldMappings, map => map.MapFrom(source => source.MemberFields))

              // Can parents/In-laws be opted in
              //   .ForMember(destination => destination.IsPSIAllowed, map => map.MapFrom(source => source.ParentSumInsured.IsAllowed))
              //   .ForMember(destination => destination.PSIType, map => map.MapFrom(source => source.ParentSumInsured.Type))
              //   .ForMember(destination => destination.PSIValues, map => map.MapFrom(source => JsonConvert.SerializeObject(source.ParentSumInsured.Values)))
              //   .ForMember(destination => destination.PSIPlan, map => map.MapFrom(source => source.ParentSumInsured.Plan))
              //   .ForMember(destination => destination.PSIInstructions, map => map.MapFrom(source => source.ParentSumInsured.Instructions))

              // Allow top-up option
              //   .ForMember(destination => destination.IsTopupAllowed, map => map.MapFrom(source => source.TopupOption.IsAllowed))
              //   .ForMember(destination => destination.TopupType, map => map.MapFrom(source => source.TopupOption.Type))
              //   .ForMember(destination => destination.TopupValues, map => map.MapFrom(source => JsonConvert.SerializeObject(source.TopupOption.Values)))
              //   .ForMember(destination => destination.TopUpPlan, map => map.MapFrom(source => source.TopupOption.Plan))
              //   .ForMember(destination => destination.TopupInstructions, map => map.MapFrom(source => source.TopupOption.Instructions))

              // Allow enhanced sum insured
              //   .ForMember(destination => destination.IsESIAllowed, map => map.MapFrom(source => source.EnhancedSumInsured.IsAllowed))
              //   .ForMember(destination => destination.ESIType, map => map.MapFrom(source => source.EnhancedSumInsured.Type))
              //   .ForMember(destination => destination.ESIValues, map => map.MapFrom(source => JsonConvert.SerializeObject(source.EnhancedSumInsured.Values)))
              //   .ForMember(destination => destination.ESIPlan, map => map.MapFrom(source => source.EnhancedSumInsured.Plan))
              //   .ForMember(destination => destination.ESIInstructions, map => map.MapFrom(source => source.EnhancedSumInsured.Instructions))
              .ForMember(destination => destination.WelcomeEmailMin, map => map.MapFrom(source => source.WelcomeEmailMins))
              .ForMember(destination => destination.ConfirmationEmailTemplate, map => map.MapFrom(source => source.RegistrationConfirmationEmailTemplate))
              .ForMember(destination => destination.SendConfirmationEmail, map => map.MapFrom(source => source.SendRegistrationConfirmationEmail))
              .ForMember(destination => destination.Id, map => map.MapFrom(source => source.Id));

            CreateMap<PEPolicyEntity, PEPolicyModel>()
              .ForMember(destination => destination.AllowedSumInsured, map => map.MapFrom(source => source.AllowedSumInsured.StringToGradeList(source.AllowedSumInsuredType)))
              .ForMember(destination => destination.PasswordPolicy, map => map.MapFrom(source => source.PasswordPolicy))
              .ForMember(destination => destination.AllowEmployeeEditProfile, map => map.MapFrom(source => source.AllowEmployeeEditHisProfile))
              .ForMember(destination => destination.AllowEmployeeViewProfile, map => map.MapFrom(source => source.AllowEmployeeViewHisProfile))
              .ForMember(destination => destination.AllowHRResetEmployeeDetails, map => map.MapFrom(source => source.AllowHRResetProfile))
              .ForMember(destination => destination.AllowDeletingMember, map => map.MapFrom(source => source.AllowDeletingMember))
              .ForMember(destination => destination.MemberFields, map => map.MapFrom(source => source.PolicyFieldMappings))
              .ForMember(destination => destination.Relationships, map => map.MapFrom(source => source.PolicyRelationshipMappings))
              .ForMember(destination => destination.Periods, map => map.MapFrom(source => source.PreEnrollmentPeriods))
              .ForMember(destination => destination.ParentSumInsured, map => map
                                          .MapFrom(source => new PEAdditionSumOptionModel
                                          {
                                              IsAllowed = source.IsPSIAllowed,
                                              Type = source.PSIType,
                                              Plan = source.PSIPlan,
                                              Instructions = source.PSIInstructions,
                                              Values = JsonConvert.DeserializeObject<List<PEAdditionSumOptionValuesModel>>(source.PSIValues),
                                          }))

              .ForMember(destination => destination.TopupOption, map => map
                                          .MapFrom(source => new PEAdditionSumOptionModel
                                          {
                                              IsAllowed = source.IsTopupAllowed,
                                              Type = source.TopupType,
                                              Plan = source.TopUpPlan,
                                              Instructions = source.TopupInstructions,
                                              Values = JsonConvert.DeserializeObject<List<PEAdditionSumOptionValuesModel>>(source.TopupValues),
                                          }))

              .ForMember(destination => destination.EnhancedSumInsured, map => map
                                          .MapFrom(source => new PEAdditionSumOptionModel
                                          {
                                              IsAllowed = source.IsESIAllowed,
                                              Type = source.ESIType,
                                              Plan = source.ESIPlan,
                                              Instructions = source.ESIInstructions,
                                              Values = JsonConvert.DeserializeObject<List<PEAdditionSumOptionValuesModel>>(source.ESIValues),
                                          }))

              .ForMember(destination => destination.WelcomeEmailMins, map => map.MapFrom(source => source.WelcomeEmailMin))
              .ForMember(destination => destination.SendRegistrationConfirmationEmail, map => map.MapFrom(source => source.SendConfirmationEmail))
              .ForMember(destination => destination.RegistrationConfirmationEmailTemplate, map => map.MapFrom(source => source.ConfirmationEmailTemplate))
              .ForMember(destination => destination.Id, map => map.MapFrom(source => source.Id));
        }

        private void MapCorporates()
        {
            CreateMap<CorporateModel, CorporateEntity>()
                .ForMember(destination => destination.Id, map => map.MapFrom(source => source.Id))
                .ForMember(destination => destination.AddressLine1, map => map.MapFrom(source => source.Address))
                .ForMember(destination => destination.MobileNo, map => map.MapFrom(source => source.MobileNumber))
                .ForMember(destination => destination.LandlineNo, map => map.MapFrom(source => source.LandlineNumber));

            CreateMap<CorporateEntity, CorporateModel>()
                .ForMember(destination => destination.Id, map => map.MapFrom(source => source.Id))
                .ForMember(destination => destination.Address, map => map.MapFrom(source => source.AddressLine1))
                .ForMember(destination => destination.MobileNumber, map => map.MapFrom(source => source.MobileNo))
                .ForMember(destination => destination.LandlineNumber, map => map.MapFrom(source => source.LandlineNo));
        }
    }
}
