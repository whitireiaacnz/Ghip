﻿using System;
using System.Data;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using RGI.GHIP.CoreAPIs.Common;
using RGI.GHIP.CoreAPIs.Data.Entities;
using RGI.GHIP.CoreAPIs.Data.Entities.CorporatePortal;
using RGI.GHIP.CoreAPIs.Data.Entities.Masters;
using RGI.GHIP.CoreAPIs.Data.Entities.Masters.AddressMasters;
using RGI.GHIP.CoreAPIs.Data.Entities.PreEnrollment;
using RGI.GHIP.CoreAPIs.Data.Entities.RGI;

namespace RGI.GHIP.CoreAPIs.Data
{
    public class GhipDBContext : DbContext
    {
        private readonly IHttpContextAccessor _httpContextAccessor;

        public GhipDBContext(
            DbContextOptions<GhipDBContext> options,
            IHttpContextAccessor httpContextAccessor)
            : base(options)
        {
            _httpContextAccessor = httpContextAccessor;
            SetUserName();
        }

        public GhipDBContext()
        {
        }

        public string UserName { get; set; }

        public DbSet<CommunicationEntity> Communications { get; set; }

        public DbSet<CorporateEntity> Corporates { get; set; }

        public DbSet<UserEntity> Users { get; set; }

        public DbSet<RoleEntity> Roles { get; set; }

        public virtual DbSet<AreaMasterEntity> AreaMaster { get; set; }

        public virtual DbSet<CityOrVillageMasterEntity> CityOrVillageMaster { get; set; }

        public virtual DbSet<DistrictMasterEntity> DistrictMaster { get; set; }

        public virtual DbSet<RegionMasterEntity> RegionMaster { get; set; }

        public virtual DbSet<RGIBrokerMasterEntity> RGIBrokerMaster { get; set; }

        public virtual DbSet<RGISMMasterEntity> RGISMMaster { get; set; }

        public virtual DbSet<RGICPMemberEntity> RGICPMember { get; set; }

        public virtual DbSet<RGICPPolicyEntity> RGICPPolicy { get; set; }

        // Preenrollment
        public DbSet<PEPeriodEntity> PreEnrollmentPeriods { get; set; }

        public DbSet<PEPolicyEntity> PreEnrollmentPolicies { get; set; }

        public DbSet<PEMemberEntity> PreEnrollmentMembers { get; set; }

        public DbSet<PEFieldMasterEntity> FieldMasters { get; set; }

        public DbSet<PEPolicyFieldMappingEntity> PolicyFieldMappings { get; set; }

        public DbSet<PEPolicyRelationshipMappingEntity> PolicyRelationshipMappings { get; set; }

        public DbSet<PERelationshipMasterEntity> RelationshipMasters { get; set; }

        public DbSet<PEEmailTemplateEntity> EmailTemplates { get; set; }

        // Corporate portal
        public virtual DbSet<CPEndorsementMemberEntity> EndorsementMember { get; set; }

        public virtual DbSet<CPNotificationEntity> Notification { get; set; }

        public virtual DbSet<CPEmployeeNotificationMappingEntity> CPEmployeeNotificationMapping { get; set; }

        public virtual DbSet<CPPolicyEntity> CPPolicy { get; set; }

        public virtual DbSet<CPPolicyVersionEntity> CPPolicyVersion { get; set; }

        public virtual DbSet<PEPolicyVersionEntity> PEPolicyVersion { get; set; }

        public virtual DbSet<CPPolicyMemberFeaturesEntity> CPPolicyMemberFeatures { get; set; }

        public virtual DbSet<CPPolicyVersionMemberFeatureEntity> CPPolicyMemberFeaturesVersion { get; set; }

        public virtual DbSet<CPMembersEntity> CPMembers { get; set; }

        public virtual DbSet<CPBrokerPolicyMappingEntity> CPBrokerPolicyMapping { get; set; }

        public virtual DbSet<CPHRMappingEntity> CPHRMapping { get; set; }

        public virtual DbSet<CPCorporateEmployeeEntity> CPCorporateEmployee { get; set; }

        public virtual DbSet<BrokerMasterEntity> BrokerMaster { get; set; }

        public virtual DbSet<SMMasterEntity> SMMaster { get; set; }

        public virtual DbSet<CPSMPolicyMappingEntity> CPSMPolicyMapping { get; set; }

        public virtual DbSet<CPDocumentEntity> Documents { get; set; }

        public virtual DbSet<CPHRCommCodeMappingEntity> HRCommCodeMapping { get; set; }

        public DbSet<UserMigrationEntity> UsersMig { get; set; }

        public DbSet<ConfigEntity> ConfigTbl { get; set; }

        public DbSet<PEParentInsuranceEntity> PEParentInsurance { get; set; }

        public DbSet<PESelfInsuranceEntity> PESelfInsurance { get; set; }

        public DbSet<PEParentInsuranceHistoryEntity> PEParentInsuranceHistory { get; set; }

        public DbSet<PEEnhanceSumInsuredEntity> PEEnhanceSumInsurance { get; set; }

        public DbSet<PEEnhanceSumInsuredHistoryEntity> PEEnhanceSumInsuranceHistory { get; set; }

        public DbSet<PETopUpInsuranceEntity> PETopUpInsurance { get; set; }

        public DbSet<PETopUpInsuranceHistoryEntity> PETopUpInsuranceHistory { get; set; }

        public DbSet<PEExtraBenefitsEntity> PEExtraBenefits { get; set; }

        public DbSet<PESelfSumInsurancePremiumEntity> PESelfSIPremium { get; set; }

        public DbSet<PEParentInsurancePremiumEntity> PEPSIPremium { get; set; }

        public DbSet<PEEnhanceSumInsurancePremiumEntity> PEESIPremium { get; set; }

        public DbSet<PETopupPremiumEntity> PETopUpPremium { get; set; }

        public DbSet<PEExtraBenefitsHistoryEntity> PEExtraBenefitsHistory { get; set; }

        public DbSet<JobEntity> JobStatus { get; set; }

        public override Task<int> SaveChangesAsync(CancellationToken cancellationToken = default(CancellationToken))
        {
            var entries = ChangeTracker
             .Entries()
             .Where(e => e.Entity is EntityBase && (
                     e.State == EntityState.Added
                     || e.State == EntityState.Modified));

            if (UserName == null)
            {
                SetUserName();
            }

            foreach (var entityEntry in entries)
            {
                if (entityEntry.State == EntityState.Modified)
                {
                    ((EntityBase)entityEntry.Entity).ModifiedAt = DateTime.Now;
                    ((EntityBase)entityEntry.Entity).ModifiedBy = UserName;
                    Entry((EntityBase)entityEntry.Entity).Property(x => x.CreatedAt).IsModified = false;
                    Entry((EntityBase)entityEntry.Entity).Property(x => x.CreatedBy).IsModified = false;
                }

                if (entityEntry.State == EntityState.Added)
                {
                    ((EntityBase)entityEntry.Entity).ModifiedAt = DateTime.Now;
                    ((EntityBase)entityEntry.Entity).CreatedAt = DateTime.Now;
                    ((EntityBase)entityEntry.Entity).ModifiedBy = UserName;
                    ((EntityBase)entityEntry.Entity).CreatedBy = UserName;
                }
            }

            foreach (var entity in ChangeTracker.Entries())
            {
                foreach (PropertyEntry property in entity.Properties.ToList().Where(o => !o.Metadata.IsKey()))
                {
                    TrimFieldValue(property);
                }
            }

            return base.SaveChangesAsync(cancellationToken);
        }

        public override int SaveChanges()
        {
            var entries = ChangeTracker
                .Entries()
                .Where(e => e.Entity is EntityBase && (
                        e.State == EntityState.Added
                        || e.State == EntityState.Modified));

            if (UserName == null)
            {
                SetUserName();
            }

            foreach (var entityEntry in entries)
            {
                if (entityEntry.State == EntityState.Modified)
                {
                    ((EntityBase)entityEntry.Entity).ModifiedAt = DateTime.Now;
                    ((EntityBase)entityEntry.Entity).ModifiedBy = UserName;
                    Entry((EntityBase)entityEntry.Entity).Property(x => x.CreatedAt).IsModified = false;
                    Entry((EntityBase)entityEntry.Entity).Property(x => x.CreatedBy).IsModified = false;
                }

                if (entityEntry.State == EntityState.Added)
                {
                    ((EntityBase)entityEntry.Entity).ModifiedAt = DateTime.Now;
                    ((EntityBase)entityEntry.Entity).CreatedAt = DateTime.Now;
                    ((EntityBase)entityEntry.Entity).ModifiedBy = UserName;
                    ((EntityBase)entityEntry.Entity).CreatedBy = UserName;
                }
            }

            foreach (var entity in ChangeTracker.Entries())
            {
                foreach (PropertyEntry property in entity.Properties.ToList().Where(o => !o.Metadata.IsKey()))
                {
                    TrimFieldValue(property);
                }
            }

            return base.SaveChanges();
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.EnableSensitiveDataLogging(true);
            string db = Config.Resources.GhipDB;
            optionsBuilder.UseSqlServer(
                db, b =>
                {
                    b.MigrationsAssembly("RGI.GHIP.CoreAPIs.Data");
                    b.EnableRetryOnFailure(3);
                    b.CommandTimeout(1200);
                });
            base.OnConfiguring(optionsBuilder);
        }

        private void SetUserName()
        {
            try
            {
                UserName = _httpContextAccessor.HttpContext.User.FindFirst("name").Value;
            }
            catch (Exception)
            {
                UserName = "Job";
            }
        }

        private void TrimFieldValue(PropertyEntry property)
        {
            var metaData = property.Metadata;
            var currentValue = property.CurrentValue?.ToString();
            var maxLength = metaData.GetMaxLength();

            if (!maxLength.HasValue || currentValue == null)
            {
                return;
            }
            else
            {
                property.CurrentValue = currentValue.Trim();
            }

            if (currentValue.Length > maxLength.Value)
            {
                property.CurrentValue = currentValue.Substring(0, maxLength.Value);
            }
        }
    }
}
