﻿using Microsoft.Extensions.DependencyInjection;
using RGI.GHIP.CoreAPIs.Data.Helpers.Mapping;
using RGI.GHIP.CoreAPIs.Data.Interfaces;
using RGI.GHIP.CoreAPIs.Data.Interfaces.Mapping;
using RGI.GHIP.CoreAPIs.Data.Interfaces.Repository;
using RGI.GHIP.CoreAPIs.Data.Interfaces.Repository.CorporatePortal;
using RGI.GHIP.CoreAPIs.Data.Interfaces.Repository.Master;
using RGI.GHIP.CoreAPIs.Data.Interfaces.Repository.Masters;
using RGI.GHIP.CoreAPIs.Data.Interfaces.Repository.PreEnrollment;
using RGI.GHIP.CoreAPIs.Data.Interfaces.Repository.RGI;
using RGI.GHIP.CoreAPIs.Data.Repository;
using RGI.GHIP.CoreAPIs.Data.Repository.CorporatePortal;
using RGI.GHIP.CoreAPIs.Data.Repository.Interface;
using RGI.GHIP.CoreAPIs.Data.Repository.Master;
using RGI.GHIP.CoreAPIs.Data.Repository.Master.AddressMasters;
using RGI.GHIP.CoreAPIs.Data.Repository.Masters.AddressMasters;
using RGI.GHIP.CoreAPIs.Data.Repository.PreEnrollment;
using RGI.GHIP.CoreAPIs.Data.Repository.RGI;

namespace RGI.GHIP.CoreAPIs.Data
{
    public static class DataDependencies
    {
        public static void Initialize(IServiceCollection services)
        {
            RegisterRepositories(services);

            RegisterHelpers(services);
        }

        private static void RegisterRepositories(IServiceCollection services)
        {
            services.AddTransient<ICorporateRepository, CorporateRepository>();
            services.AddTransient<ICommunicationRepository, CommunicationRepository>();
            services.AddTransient<IUserRepository, UserRepository>();

            // pre enrollment                                            s
            services.AddTransient<IPEPolicyRepository, PEPolicyRepository>();
            services.AddTransient<IPEPeriodRepository, PEPeriodRepository>();
            services.AddTransient<IPEPolicyRelationshipMappingRepository, PEPolicyRelationshipMappingRepository>();
            services.AddTransient<IPEPolicyFieldMappingRepository, PEPolicyFieldMappingRepository>();
            services.AddTransient<IPERelationshipMasterRepository, RelationshipMasterRepository>();
            services.AddTransient<IPEFieldMasterRepository, FieldMasterRepository>();
            services.AddTransient<IPEMemberRepository, PEMemberRepository>();
            services.AddTransient<IPEEmailTemplateRepository, PEEmailTemplateRepository>();
            services.AddTransient<IStateMasterRepository, StateMasterRepository>();
            services.AddTransient<IDistrictMasterRepository, DistrictMasterRepository>();
            services.AddTransient<ICityOrVillageMasterRepository, CityOrVillageMasterRepository>();
            services.AddTransient<IAreaMasterRepository, AreaMasterRepository>();
            services.AddTransient<IRegionMasterRepository, RegionMasterRepository>();
            services.AddTransient<IPEConfigRepository, PEConfigRepository>();
            services.AddTransient<IPEParentInsuranceRepository, PEParentInsuranceRepository>();
            services.AddTransient<IPEExtraBenefitsRepository, PEExtraBenefitsRepository>();
            services.AddTransient<IPEEnhanceSumInsuranceRepository, PEEnhanceSumInsuranceRepository>();
            services.AddTransient<IPETopUpInsuranceRepository, PETopUpInsuraceRepository>();
            services.AddTransient<IPEPSIESITopupTransferRepository, PEPSIESITopupTransferRepository>();
            services.AddTransient<IPEPolicyHistoryRepository, PEPolicyHistoryRepository>();
            services.AddTransient<IPEExtraBenefitsHistoryRepository, PEExtraBenefitsHistoryRepository>();
            services.AddTransient<IPEParentInsuranceHistoryRepository, PEParentInsuranceHistoryRepository>();
            services.AddTransient<IPEEnhanceSumInsuranceHistoryRepository, PEEnhanceSumInsuranceHistoryRepository>();
            services.AddTransient<IPETopUpInsuranceHistoryRepository, PETopUpInsuranceHistoryRepository>();
            services.AddTransient<IPEPSIPremiumRepository, PEPSIPremiumRepository>();
            services.AddTransient<IPEESIPremiumRepository, PEESIPremiumRepository>();
            services.AddTransient<IPETopupPremiumRepository, PETopupPremiumRepository>();
            services.AddTransient<IJobRepository, JobRepository>();
            services.AddTransient<IPESelfInsuranceRepository, PESelfInsuranceRepository>();
            services.AddTransient<IPESelfSumInsurancePremiumRepository, PESelfSumInsurancePremiumRepository>();

            // corporate portal
            services.AddTransient<ICPPolicyRepository, CPPolicyRepository>();
            services.AddTransient<ICPPolicyMemberFeatureRepository, CPPolicyMemberFeatureRepository>();
            services.AddTransient<ICPMemberRepository, CPMemberRepository>();
            services.AddTransient<ICPHRMappingRepository, CPHRMappingRepository>();
            services.AddTransient<ICPBrokerMappingRepository, CPBrokerMappingRepository>();
            services.AddTransient<IBrokerMasterRepository, BrokerMasterRepository>();
            services.AddTransient<ICPSMMappingRepository, CPSMMappingRepository>();
            services.AddTransient<ISMMasterRepository, SMMasterRepository>();
            services.AddTransient<ICPDocumentRepository, CPDocumentRepository>();
            services.AddTransient<ICPCorporateEmployeeRepository, CPCorporateEmployeeRepository>();
            services.AddTransient<ICPEmployeeNotificationRepository, CPEmployeeNotificationRepository>();
            services.AddTransient<ICPNotificationRepository, CPNotificationRepository>();
            services.AddTransient<ICPEndorsementRepository, CPEndorsementRepository>();
            services.AddTransient<ICPHRCommCodeMappingRepository, CPHRCommCodeMappingRepository>();
            services.AddTransient<ICPHistoryPolicyRepository, CPHistoryPolicyRepository>();
            services.AddTransient<ICPPolicyMemberFeatureVersionRepository, CPPolicyMemberFeatureVersionRepository>();

            // RGI
            services.AddTransient<IRGICPPolicyRepository, RGICPPolicyRepository>();
            services.AddTransient<IRGICPMemberRepository, RGICPMemberRepository>();
            services.AddTransient<IRGIBrokerMasterRepository, RGIBrokerMasterRepository>();
            services.AddTransient<IRGISMMasterRepository, RGISMMasterRepository>();
        }

        private static void RegisterHelpers(IServiceCollection services)
        {
            services.AddTransient<ICorporateMappingHelpers, CorporateMappingHelper>();
            services.AddTransient<IPolicyEntityMappingHelper, PolicyEntityMappingHelper>();
            services.AddTransient<IFieldEntityMappingHelper, FieldEntityMappingHelper>();
            services.AddTransient<IRelationshipEntityMappingHelper, RelationshipEntityMappingHelper>();
            services.AddTransient<IPeriodEntityMappingHelper, PeriodEntityMappingHelper>();
            services.AddTransient<IMemberEntityMappingHelper, MemberEntityMappingHelper>();
            services.AddTransient<IRoleEntityMappingHelper, RoleEntityMappingHelper>();
            services.AddTransient<IUserEntityMappingHelper, UserEntityMappingHelper>();
            services.AddTransient<IParentInsuranceEntityMappingHelper, ParentInsuranceEntityMappingHelper>();
            services.AddTransient<IExtraBenefitsEntityMappingHelper, ExtraBenefitsEntityMappingHelper>();
            services.AddTransient<IEnhanceSumInsuranceEntityMappingHelper, EnhanceSumInsuranceEntityMappingHelper>();
            services.AddTransient<ITopUpInsuranceEntityMappingHelper, TopUpInsuranceEntityMappingHelper>();
            services.AddTransient<IHistoryPolicyMappingHelper, HistoryPolicyMappingHelper>();
            services.AddTransient<ISelfInsuranceEntityMappingHelper, SelfInsuranceEntityMappingHelper>();
        }
    }
}
