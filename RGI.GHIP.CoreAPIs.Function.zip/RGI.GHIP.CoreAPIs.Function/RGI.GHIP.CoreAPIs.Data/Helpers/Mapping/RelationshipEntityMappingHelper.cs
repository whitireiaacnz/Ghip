﻿using System.Collections.Generic;
using AutoMapper;
using RGI.GHIP.CoreAPIs.Common.Mapper;
using RGI.GHIP.CoreAPIs.Common.Models;
using RGI.GHIP.CoreAPIs.Data.Entities.PreEnrollment;
using RGI.GHIP.CoreAPIs.Data.Interfaces.Mapping;

namespace RGI.GHIP.CoreAPIs.Data.Helpers.Mapping
{
    public class RelationshipEntityMappingHelper : MapperExtension, IRelationshipEntityMappingHelper
    {
        public RelationshipEntityMappingHelper(IMapper mapper)
            : base(mapper)
        {
        }

        public PERelationshipMasterModel EntityToModel(PERelationshipMasterEntity relationshipMasterEntity)
        {
            PERelationshipMasterModel relationshipMasterModel = MapObjectTo<PERelationshipMasterModel>(relationshipMasterEntity);

            return relationshipMasterModel;
        }

        public List<PERelationshipMasterModel> EntityToModelList(List<PERelationshipMasterEntity> relationshipMasterEntity)
        {
            List<PERelationshipMasterModel> relationshipMasterModel = MapListTo<PERelationshipMasterModel, PERelationshipMasterEntity>(relationshipMasterEntity);

            return relationshipMasterModel;
        }

        public PERelationshipMasterEntity ModelToEntity(PERelationshipMasterModel relationshipMasterModel)
        {
            PERelationshipMasterEntity relationshipMasterEntity = MapObjectTo<PERelationshipMasterEntity>(relationshipMasterModel);

            return relationshipMasterEntity;
        }

        public List<PERelationshipMasterEntity> ModelToEntityList(List<PERelationshipMasterModel> relationshipMasterModel)
        {
            List<PERelationshipMasterEntity> relationshipMasterEntity = MapListTo<PERelationshipMasterEntity, PERelationshipMasterModel>(relationshipMasterModel);

            return relationshipMasterEntity;
        }

        public PERelationshipMasterModel RelationshipMappingEntityToModel(PEPolicyRelationshipMappingEntity relationshipMasterEntity)
        {
            PERelationshipMasterModel relationshipMasterModel = MapObjectTo<PERelationshipMasterModel>(relationshipMasterEntity);

            return relationshipMasterModel;
        }

        public List<PERelationshipMasterModel> RelationshipMappingEntityToModelList(List<PEPolicyRelationshipMappingEntity> relationshipMasterEntity)
        {
            List<PERelationshipMasterModel> relationshipMasterModel = MapListTo<PERelationshipMasterModel, PEPolicyRelationshipMappingEntity>(relationshipMasterEntity);

            return relationshipMasterModel;
        }

        public PEPolicyRelationshipMappingEntity RelationshipMappingModelToEntity(PERelationshipMasterModel relationshipMasterModel)
        {
            PEPolicyRelationshipMappingEntity relationshipMasterEntity = MapObjectTo<PEPolicyRelationshipMappingEntity>(relationshipMasterModel);

            return relationshipMasterEntity;
        }

        public List<PEPolicyRelationshipMappingEntity> RelationshipMappingModelToEntityList(List<PERelationshipMasterModel> relationshipMasterModel)
        {
            List<PEPolicyRelationshipMappingEntity> relationshipMasterEntity = MapListTo<PEPolicyRelationshipMappingEntity, PERelationshipMasterModel>(relationshipMasterModel);

            return relationshipMasterEntity;
        }
    }
}
