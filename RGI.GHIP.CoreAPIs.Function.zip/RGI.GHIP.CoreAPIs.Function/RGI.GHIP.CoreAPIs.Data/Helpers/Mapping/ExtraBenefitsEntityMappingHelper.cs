using System;
using AutoMapper;
using RGI.GHIP.CoreAPIs.Common.Mapper;
using RGI.GHIP.CoreAPIs.Common.Models;
using RGI.GHIP.CoreAPIs.Data.Entities.PreEnrollment;
using RGI.GHIP.CoreAPIs.Data.Interfaces.Mapping;

namespace RGI.GHIP.CoreAPIs.Data.Helpers.Mapping
{
    public class ExtraBenefitsEntityMappingHelper : MapperExtension, IExtraBenefitsEntityMappingHelper
    {
        public ExtraBenefitsEntityMappingHelper(IMapper mapper)
            : base(mapper)
        {
        }

        public PEExtraBenefitsEntity ModelToEntity(PEExtraBenefitsModel extraBenefitsModel)
        {
            PEExtraBenefitsEntity psiEntities = new PEExtraBenefitsEntity();

            try
            {
                PEExtraBenefitsEntity psiEntity = MapObjectTo<PEExtraBenefitsEntity>(extraBenefitsModel);
                return psiEntity;
            }
            catch (Exception ex)
            {
                return psiEntities;
            }

            // return psiEntity;
        }
    }
}