using AutoMapper;
using RGI.GHIP.CoreAPIs.Common.Mapper;
using RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal;
using RGI.GHIP.CoreAPIs.Data.Entities.CorporatePortal;
using RGI.GHIP.CoreAPIs.Data.Interfaces.Mapping;

namespace RGI.GHIP.CoreAPIs.Data.Helpers.Mapping
{
    public class HistoryPolicyMappingHelper : MapperExtension, IHistoryPolicyMappingHelper
    {
        public HistoryPolicyMappingHelper(IMapper mapper)
                 : base(mapper)
        {
        }

        public CPPolicyVersionEntity ModelToEntity(CPHistoryPolicyModel cpHistoryModel)
        {
            CPPolicyVersionEntity cpHistoryPolicyEntity = MapObjectTo<CPPolicyVersionEntity>(cpHistoryModel);
            return cpHistoryPolicyEntity;
        }
    }
}