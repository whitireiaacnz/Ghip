using System.Collections.Generic;
using AutoMapper;
using RGI.GHIP.CoreAPIs.Common.Mapper;
using RGI.GHIP.CoreAPIs.Common.Models;
using RGI.GHIP.CoreAPIs.Data.Entities.PreEnrollment;
using RGI.GHIP.CoreAPIs.Data.Interfaces.Mapping;

namespace RGI.GHIP.CoreAPIs.Data.Helpers.Mapping
{
    public class ParentInsuranceEntityMappingHelper : MapperExtension, IParentInsuranceEntityMappingHelper
    {
        public ParentInsuranceEntityMappingHelper(IMapper mapper)
             : base(mapper)
        {
        }

        public List<PEParentInsuranceEntity> ModelToEntity(List<PEPSIModel> peParentInsurancePremiumModel)
        {
            List<PEParentInsuranceEntity> psiEntity = MapObjectTo<List<PEParentInsuranceEntity>>(peParentInsurancePremiumModel);
            return psiEntity;
        }

        public PEParentInsuranceModel EntityToModel(PEParentInsuranceEntity pEParentInsuranceEntity)
        {
            PEParentInsuranceModel psiModel = MapObjectTo<PEParentInsuranceModel>(pEParentInsuranceEntity);
            return psiModel;
        }

        public List<PEParentInsuranceHistoryEntity> ModelToEntityHistory(List<PEParentInsuranceHistoryPremiumModel> psiHistoryModels)
        {
            List<PEParentInsuranceHistoryEntity> psiHistoryEntity = MapObjectTo<List<PEParentInsuranceHistoryEntity>>(psiHistoryModels);
            return psiHistoryEntity;
        }

        public List<PEEnhanceSumInsuredHistoryEntity> ModelToEntityHistoryESI(List<PEEnhanceSumInsuredPremiumHistoryModel> esiHistoryModels)
        {
            List<PEEnhanceSumInsuredHistoryEntity> esiHistoryEntity = MapObjectTo<List<PEEnhanceSumInsuredHistoryEntity>>(esiHistoryModels);
            return esiHistoryEntity;
        }

        public List<PETopUpInsuranceHistoryEntity> ModelToEntityHistoryTopup(List<PETopUpInsurancePremiumHistoryModel> topupHistoryModels)
        {
            List<PETopUpInsuranceHistoryEntity> topUpHistoryEntity = MapObjectTo<List<PETopUpInsuranceHistoryEntity>>(topupHistoryModels);
            return topUpHistoryEntity;
        }
    }
}
