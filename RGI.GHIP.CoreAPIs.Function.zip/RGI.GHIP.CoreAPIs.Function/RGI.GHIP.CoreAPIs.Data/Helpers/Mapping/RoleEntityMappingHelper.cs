﻿using RGI.GHIP.CoreAPIs.Common.Interfaces.IMapper;
using RGI.GHIP.CoreAPIs.Common.Models;
using RGI.GHIP.CoreAPIs.Data.Entities;
using RGI.GHIP.CoreAPIs.Data.Interfaces.Mapping;

namespace RGI.GHIP.CoreAPIs.Data.Helpers.Mapping
{
    public class RoleEntityMappingHelper : IRoleEntityMappingHelper
    {
        private readonly IMapperExtension _mapper;

        public RoleEntityMappingHelper(IMapperExtension mapper)
        {
            _mapper = mapper;
        }

        public RoleModel RoleEntitytoModel(RoleEntity roleEntity)
        {
            return _mapper.MapObjectTo<RoleModel>(roleEntity);
        }

        public RoleEntity RoleModeltoEntity(RoleModel roleModel)
        {
            return _mapper.MapObjectTo<RoleEntity>(roleModel);
        }
    }
}
