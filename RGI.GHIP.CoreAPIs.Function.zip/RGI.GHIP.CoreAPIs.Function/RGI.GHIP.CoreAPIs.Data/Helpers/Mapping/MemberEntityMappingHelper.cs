﻿using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using RGI.GHIP.CoreAPIs.Common.Constants.Member;
using RGI.GHIP.CoreAPIs.Common.Mapper;
using RGI.GHIP.CoreAPIs.Common.Models;
using RGI.GHIP.CoreAPIs.Common.Models.Member;
using RGI.GHIP.CoreAPIs.Data.Entities.PreEnrollment;
using RGI.GHIP.CoreAPIs.Data.Interfaces.Mapping;

namespace RGI.GHIP.CoreAPIs.Data.Helpers.Mapping
{
    public class MemberEntityMappingHelper : MapperExtension, IMemberEntityMappingHelper
    {
        public MemberEntityMappingHelper(IMapper mapper)
            : base(mapper)
        {
        }

        public PEMemberFieldsSummaryModel EntityToModel(PEMemberEntity preEnrollmentMemberEntity)
        {
            PEMemberFieldsSummaryModel preEnrollmentMemberModel = MapObjectTo<PEMemberFieldsSummaryModel>(preEnrollmentMemberEntity);

            return preEnrollmentMemberModel;
        }

        public PEMemberFieldsSummaryModel EntityToSummaryModel(PEMemberEntity preEnrollmentMemberEntity)
        {
            if (preEnrollmentMemberEntity != null)
            {
                PEMemberFieldsSummaryModel preEnrollmentMemberModel = MapObjectTo<PEMemberFieldsSummaryModel>(preEnrollmentMemberEntity);
                preEnrollmentMemberModel.FieldsData = MapJsonToModel<PEMemberFieldsModel>(preEnrollmentMemberEntity.FieldsJson);

                return preEnrollmentMemberModel;
            }
            else
            {
                return null;
            }
        }

        public PEMemberModel EntityToMemberModel(PEMemberEntity preEnrollmentMemberEntity)
        {
            PEMemberModel preEnrollmentMemberModel = MapObjectTo<PEMemberModel>(preEnrollmentMemberEntity);

            return preEnrollmentMemberModel;
        }

        public List<PEMemberFieldsSummaryModel> EntityToSummaryModelList(List<PEMemberEntity> preEnrollmentMemberEntities)
        {
            List<PEMemberFieldsSummaryModel> preEnrollmentMemberSummaries = new List<PEMemberFieldsSummaryModel>();
            int i = -1;

            var groups = preEnrollmentMemberEntities.GroupBy(x => x.EmpId);
            foreach (var group in groups)
            {
                PEMemberFieldsSummaryModel summaryModel = new PEMemberFieldsSummaryModel();
                var self = group.Where(x => x.RelationshipMasterId == RelationshipMaster.SELFID).FirstOrDefault();
                summaryModel = EntityToSummaryModel(self);
                if (summaryModel == null)
                {
                    continue;
                }

                var dependents = group.Where(x => x.RelationshipMasterId != RelationshipMaster.SELFID).ToList();
                foreach (var dependent in dependents)
                {
                    summaryModel.Dependent.Add(EntityToSummaryModel(dependent));
                }

                preEnrollmentMemberSummaries.Add(summaryModel);
            }

            return preEnrollmentMemberSummaries;
        }

        public List<PEMemberModel> EntityToMemberModelList(List<PEMemberEntity> preEnrollmentMemberEntities)
        {
            List<PEMemberModel> preEnrollmentMemberSummaries = new List<PEMemberModel>();
            foreach (var preEnrollmentMemberEntity in preEnrollmentMemberEntities)
            {
                preEnrollmentMemberSummaries.Add(EntityToMemberModel(preEnrollmentMemberEntity));
            }

            return preEnrollmentMemberSummaries;
        }

        public List<PEMemberFieldsSummaryModel> EntityToModelList(List<PEMemberEntity> preEnrollmentMemberEntities)
        {
            List<PEMemberFieldsSummaryModel> preEnrollmentMemberModels = MapListTo<PEMemberFieldsSummaryModel, PEMemberEntity>(preEnrollmentMemberEntities);

            return preEnrollmentMemberModels;
        }

        public PEMemberEntity ModelToEntity(PEMemberFieldsSummaryModel preEnrollmentMemberModel)
        {
            PEMemberEntity preEnrollmentMemberEntity = MapObjectTo<PEMemberEntity>(preEnrollmentMemberModel);

            return preEnrollmentMemberEntity;
        }

        public List<PEMemberEntity> ModelToEntityList(List<PEMemberFieldsSummaryModel> preEnrollmentMemberModels)
        {
            List<PEMemberEntity> preEnrollmentMemberEntities = MapListTo<PEMemberEntity, PEMemberFieldsSummaryModel>(preEnrollmentMemberModels);

            return preEnrollmentMemberEntities;
        }
    }
}
