using System.Collections.Generic;
using AutoMapper;
using RGI.GHIP.CoreAPIs.Common.Mapper;
using RGI.GHIP.CoreAPIs.Common.Models;
using RGI.GHIP.CoreAPIs.Data.Entities.PreEnrollment;
using RGI.GHIP.CoreAPIs.Data.Interfaces.Mapping;

namespace RGI.GHIP.CoreAPIs.Data.Helpers.Mapping
{
    public class EnhanceSumInsuranceEntityMappingHelper : MapperExtension, IEnhanceSumInsuranceEntityMappingHelper
    {
        public EnhanceSumInsuranceEntityMappingHelper(IMapper mapper)
            : base(mapper)
        {
        }

        public List<PEEnhanceSumInsuredEntity> ModelToEntity(List<PEESIModel> preEnrollmentEsiModel)
        {
            List<PEEnhanceSumInsuredEntity> esiEntity = MapObjectTo<List<PEEnhanceSumInsuredEntity>>(preEnrollmentEsiModel);
            return esiEntity;
        }
    }
}