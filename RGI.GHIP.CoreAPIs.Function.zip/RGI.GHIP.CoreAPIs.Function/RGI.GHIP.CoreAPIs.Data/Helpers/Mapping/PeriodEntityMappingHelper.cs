﻿using System;
using System.Collections.Generic;
using AutoMapper;
using RGI.GHIP.CoreAPIs.Common.Mapper;
using RGI.GHIP.CoreAPIs.Common.Models;
using RGI.GHIP.CoreAPIs.Data.Entities.PreEnrollment;
using RGI.GHIP.CoreAPIs.Data.Interfaces.Mapping;

namespace RGI.GHIP.CoreAPIs.Data.Helpers.Mapping
{
    public class PeriodEntityMappingHelper : MapperExtension, IPeriodEntityMappingHelper
    {
        private readonly Func<PEPeriodModel, bool> _status = (preEnrollmentPeriodModel) =>
                preEnrollmentPeriodModel.StartDate.Date <= DateTime.Now.Date
                && preEnrollmentPeriodModel.EndDate.Date >= DateTime.Now.Date;

        public PeriodEntityMappingHelper(IMapper mapper)
            : base(mapper)
        {
        }

        public PEPeriodModel EntityToModel(PEPeriodEntity preEnrollmentPeriodEntity)
        {
            PEPeriodModel preEnrollmentPeriodModel = MapObjectTo<PEPeriodModel>(preEnrollmentPeriodEntity);
            preEnrollmentPeriodModel.Status = _status(preEnrollmentPeriodModel);

            return preEnrollmentPeriodModel;
        }

        public List<PEPeriodModel> EntityToModelList(List<PEPeriodEntity> preEnrollmentPeriodEntities)
        {
            List<PEPeriodModel> preEnrollmentPeriodModels = MapListTo<PEPeriodModel, PEPeriodEntity>(preEnrollmentPeriodEntities);
            preEnrollmentPeriodModels.ForEach(preEnrollmentPeriodModel =>
                preEnrollmentPeriodModel.Status = _status(preEnrollmentPeriodModel));

            return preEnrollmentPeriodModels;
        }

        public PEPeriodEntity ModelToEntity(PEPeriodModel preEnrollmentPeriodModel)
        {
            PEPeriodEntity preEnrollmentPeriodEntity = MapObjectTo<PEPeriodEntity>(preEnrollmentPeriodModel);

            return preEnrollmentPeriodEntity;
        }

        public List<PEPeriodEntity> ModelToEntityList(List<PEPeriodModel> preEnrollmentPeriodModels)
        {
            List<PEPeriodEntity> preEnrollmentPeriodEntities = MapListTo<PEPeriodEntity, PEPeriodModel>(preEnrollmentPeriodModels);

            return preEnrollmentPeriodEntities;
        }
    }
}
