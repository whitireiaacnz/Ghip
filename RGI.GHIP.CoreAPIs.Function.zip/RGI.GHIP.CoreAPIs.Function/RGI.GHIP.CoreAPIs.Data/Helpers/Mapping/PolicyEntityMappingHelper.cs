﻿using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using RGI.GHIP.CoreAPIs.Common.Mapper;
using RGI.GHIP.CoreAPIs.Common.Models;
using RGI.GHIP.CoreAPIs.Data.Entities.PreEnrollment;
using RGI.GHIP.CoreAPIs.Data.Interfaces.Mapping;

namespace RGI.GHIP.CoreAPIs.Data.Helpers.Mapping
{
    public class PolicyEntityMappingHelper : MapperExtension, IPolicyEntityMappingHelper
    {
        public PolicyEntityMappingHelper(IMapper mapper)
            : base(mapper)
        {
        }

        public PEPolicyModel EntityToModel(
            PEPolicyEntity preEnrollmentPolicyEntity)
        {
            if (preEnrollmentPolicyEntity == null)
            {
                return null;
            }

            PEPolicyModel preEnrollmentPolicyModel = MapObjectTo<PEPolicyModel>(preEnrollmentPolicyEntity);
            preEnrollmentPolicyModel.MemberFields = MapListTo<PEFieldMasterModel, PEPolicyFieldMappingEntity>(preEnrollmentPolicyEntity.PolicyFieldMappings.ToList());
            preEnrollmentPolicyModel.Relationships = MapListTo<PERelationshipMasterModel, PEPolicyRelationshipMappingEntity>(preEnrollmentPolicyEntity.PolicyRelationshipMappings.ToList());
            preEnrollmentPolicyModel.MemberFields.RemoveAll(x => x.IsDeleted);
            preEnrollmentPolicyModel.Relationships.RemoveAll(x => x.IsDeleted);

            return preEnrollmentPolicyModel;
        }

        public PEPolicyEntity ModelToEntity(PEPolicyModel preEnrollmentPolicyModel)
        {
            PEPolicyEntity preEnrollmentPolicyEntity = MapObjectTo<PEPolicyEntity>(preEnrollmentPolicyModel);

            return preEnrollmentPolicyEntity;
        }

        public List<PEPolicyEntity> ModelToEntityList(List<PEPolicyModel> preEnrollmentPolicyModels)
        {
            List<PEPolicyEntity> preEnrollmentPolicyEntities = MapListTo<PEPolicyEntity, PEPolicyModel>(preEnrollmentPolicyModels);

            return preEnrollmentPolicyEntities;
        }
    }
}
