﻿using RGI.GHIP.CoreAPIs.Common.Interfaces.IMapper;
using RGI.GHIP.CoreAPIs.Common.Models;
using RGI.GHIP.CoreAPIs.Data.Entities;
using RGI.GHIP.CoreAPIs.Data.Interfaces;

namespace RGI.GHIP.CoreAPIs.Data.Helpers.Mapping
{
    public class UserEntityMappingHelper : IUserEntityMappingHelper
    {
        private readonly IMapperExtension _mapper;

        public UserEntityMappingHelper(IMapperExtension mapper)
        {
            _mapper = mapper;
        }

        public UserModel MapUserEntityToModel(UserEntity userEntity)
        {
            return _mapper.MapObjectTo<UserModel>(userEntity);
        }

        public UserEntity MapUserModelToEntity(UserModel userModel)
        {
            return _mapper.MapObjectTo<UserEntity>(userModel);
        }
    }
}
