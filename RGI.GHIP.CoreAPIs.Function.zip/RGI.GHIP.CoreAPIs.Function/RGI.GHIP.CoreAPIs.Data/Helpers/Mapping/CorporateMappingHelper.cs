﻿using System.Collections.Generic;
using AutoMapper;
using RGI.GHIP.CoreAPIs.Common.Mapper;
using RGI.GHIP.CoreAPIs.Common.Models;
using RGI.GHIP.CoreAPIs.Data.Entities;
using RGI.GHIP.CoreAPIs.Data.Interfaces;

namespace RGI.GHIP.CoreAPIs.Data.Helpers.Mapping
{
    public class CorporateMappingHelper : MapperExtension, ICorporateMappingHelpers
    {
        public CorporateMappingHelper(IMapper mapper)
            : base(mapper)
        {
        }

        public List<CorporateModel> EntityToModelList(List<CorporateEntity> corporateEntities)
        {
            List<CorporateModel> corporateModels = MapListTo<CorporateModel, CorporateEntity>(corporateEntities);

            return corporateModels;
        }

        public CorporateModel EntityToModel(CorporateEntity corporateEntity)
        {
            CorporateModel corporateModel = MapObjectTo<CorporateModel>(corporateEntity);

            return corporateModel;
        }

        public List<CorporateEntity> ModelToEntityList(List<CorporateModel> corporateModels)
        {
            List<CorporateEntity> corporateEntities = MapListTo<CorporateEntity, CorporateModel>(corporateModels);

            return corporateEntities;
        }

        public CorporateEntity ModelToEntity(CorporateModel corporateModel)
        {
            CorporateEntity corporateEntity = MapObjectTo<CorporateEntity>(corporateModel);

            return corporateEntity;
        }
    }
}
