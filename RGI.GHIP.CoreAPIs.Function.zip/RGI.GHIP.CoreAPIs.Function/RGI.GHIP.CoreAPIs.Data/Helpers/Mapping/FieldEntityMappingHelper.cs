﻿using System.Collections.Generic;
using AutoMapper;
using RGI.GHIP.CoreAPIs.Common.Mapper;
using RGI.GHIP.CoreAPIs.Common.Models;
using RGI.GHIP.CoreAPIs.Data.Entities.PreEnrollment;
using RGI.GHIP.CoreAPIs.Data.Interfaces.Mapping;

namespace RGI.GHIP.CoreAPIs.Data.Helpers.Mapping
{
    public class FieldEntityMappingHelper : MapperExtension, IFieldEntityMappingHelper
    {
        public FieldEntityMappingHelper(IMapper mapper)
            : base(mapper)
        {
        }

        public PEFieldMasterEntity ModelToEntity(PEFieldMasterModel fieldMasterModel)
        {
            PEFieldMasterEntity fieldMasterEntity = MapObjectTo<PEFieldMasterEntity>(fieldMasterModel);

            return fieldMasterEntity;
        }

        public List<PEFieldMasterEntity> ModelToEntityList(List<PEFieldMasterModel> fieldMasterModels)
        {
            List<PEFieldMasterEntity> fieldMasterEntities = MapListTo<PEFieldMasterEntity, PEFieldMasterModel>(fieldMasterModels);

            return fieldMasterEntities;
        }

        public List<PEFieldMasterModel> EntityToModelList(List<PEFieldMasterEntity> fieldMasterEntities)
        {
            List<PEFieldMasterModel> fieldMasterModel = MapListTo<PEFieldMasterModel, PEFieldMasterEntity>(fieldMasterEntities);

            return fieldMasterModel;
        }

        public PEFieldMasterModel EntityToModel(PEFieldMasterEntity fieldMasterEntity)
        {
            PEFieldMasterModel fieldMasterModel = MapObjectTo<PEFieldMasterModel>(fieldMasterEntity);

            return fieldMasterModel;
        }

        public PEPolicyFieldMappingEntity FieldMappingModelToEntity(PEFieldMasterModel fieldMasterModel)
        {
            PEPolicyFieldMappingEntity fieldMasterEntity = MapObjectTo<PEPolicyFieldMappingEntity>(fieldMasterModel);

            return fieldMasterEntity;
        }

        public List<PEPolicyFieldMappingEntity> FieldMappingModelToEntityList(List<PEFieldMasterModel> fieldMasterModels)
        {
            List<PEPolicyFieldMappingEntity> fieldMasterEntities = MapListTo<PEPolicyFieldMappingEntity, PEFieldMasterModel>(fieldMasterModels);

            return fieldMasterEntities;
        }

        public PEFieldMasterModel FieldMappingEntityToModel(PEPolicyFieldMappingEntity fieldMasterEntity)
        {
            PEFieldMasterModel fieldMasterModel = MapObjectTo<PEFieldMasterModel>(fieldMasterEntity);

            return fieldMasterModel;
        }
    }
}
