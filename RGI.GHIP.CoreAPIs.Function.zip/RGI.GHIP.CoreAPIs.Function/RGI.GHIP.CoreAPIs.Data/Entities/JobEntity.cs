using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RGI.GHIP.CoreAPIs.Data.Entities
{
    [Table("JobStatus", Schema = "GhipGlobal")]
    public class JobEntity : EntityBase
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        public int? PePolicyId { get; set; }

        public string Status { get; set; }

        public string? Errors { get; set; }

        public string? MemberFileURL { get; set; }

        public string JobCreatedBy { get; set; }
    }
}