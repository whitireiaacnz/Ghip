﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RGI.GHIP.CoreAPIs.Data.Entities.PreEnrollment
{
    [Table("PreEnrollmentMembers", Schema = "GhipPE")]
    public class PEMemberEntity : EntityBase
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /* Forein keys */
        public int PreEnrollmentPolicyId { get; set; }

        public int RelationshipMasterId { get; set; }

        [Required]
        [MaxLength(128)]
        public string EmpId { get; set; }

        /* Extra benifits */
        public int PSI { get; set; }

        public int ESI { get; set; }

        public int Topup { get; set; }

        // reminder email fields
        public string ReminderEmailErrorReason { get; set; }

        public string ReminderEmailTemplate { get; set; }

        public int ReminderEmailSentTrials { get; set; }

        public DateTime ReminderEmailSentAt { get; set; }

        public bool IsReminderEmailSent { get; set; }

        /* Welcome email fields */
        public string WelcomeEmailErrorReason { get; set; }

        public string WelcomeEmailTemplate { get; set; }

        public int WelcomeEmailSentTrials { get; set; }

        public DateTime WelcomeEmailSentAt { get; set; }

        public bool IsWelcomeEmailSent { get; set; }

        /* Confirmation email fields */
        public string ConfirmationEmailErrorReason { get; set; }

        public string ConfirmationEmailTemplate { get; set; }

        public int ConfirmationEmailSentTrials { get; set; }

        public DateTime ConfirmationEmailSentAt { get; set; }

        public bool IsConfirmationEmailSent { get; set; }

        public bool IsSelfProfileEdited { get; set; }

        public bool IsHR { get; set; }

        /* Final submission fields */
        public DateTime FinalSubmissionCompletedAt { get; set; }

        public bool IsFinalSubmissionLocked { get; set; }

        /* Field master json */
        [MaxLength]
        public string OtherFieldsJson { get; set; }

        [MaxLength]
        public string FieldsJson { get; set; }

        public int PSIPremium { get; set; }

        public int ESIPremium { get; set; }

        public int TopupPremium { get; set; }

        /* navigation properties */
        /* navigation property preEnrollmentPolicy with foreign key preEnrollmentPolicyId */
        [ForeignKey("PreEnrollmentPolicyId")]
        public PEPolicyEntity PreEnrollmentPolicy { get; set; }

        [ForeignKey("RelationshipMasterId")]
        public PERelationshipMasterEntity RelationshipMaster { get; set; }
    }
}
