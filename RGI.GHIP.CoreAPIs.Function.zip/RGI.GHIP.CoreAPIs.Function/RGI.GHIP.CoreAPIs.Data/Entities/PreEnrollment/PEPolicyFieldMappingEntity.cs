﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RGI.GHIP.CoreAPIs.Data.Entities.PreEnrollment
{
    [Table("PolicyFieldMappings", Schema = "GhipPE")]
    public class PEPolicyFieldMappingEntity : EntityBase
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        public int PreEnrollmentPolicyId { get; set; }

        public int FieldMasterId { get; set; }

        public bool IsEditableForSelf { get; set; }

        public bool IsEditableForDependent { get; set; }

        public bool IsMandatoryForSelf { get; set; }

        public bool IsVisibleForSelf { get; set; }

        public bool IsMandatoryForDependent { get; set; }

        public bool IsVisibleForDependent { get; set; }

        [ForeignKey("PreEnrollmentPolicyId")]
        public PEPolicyEntity PreEnrollmentPolicy { get; set; }

        [ForeignKey("FieldMasterId")]
        public PEFieldMasterEntity FieldMaster { get; set; }
    }
}
