using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RGI.GHIP.CoreAPIs.Data.Entities.PreEnrollment
{
    [Table("TopupInsurancePremium", Schema = "GhipPE")]
    public class PETopupPremiumEntity : EntityBase
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        public int TopupInsuranceId { get; set; }

        public int SumInsured { get; set; }

        public int PEExtraBenefitsId { get; set; }

        public int PEPolicyId { get; set; }

        public int NumberOfMembers { get; set; }

        public int MinAge { get; set; }

        public int MaxAge { get; set; }

        public string Relationship { get; set; }

        public double Loading { get; set; }

        public int PremiumAmount { get; set; }

        public string? Grade { get; set; }

        [ForeignKey("TopupInsuranceId")]
        public PETopUpInsuranceEntity PreEnrollmentTopup { get; set; }

        [ForeignKey("PEExtraBenefitsId")]
        public PEExtraBenefitsEntity PreEnrollmentExtraBenefits { get; set; }

        [ForeignKey("PEPolicyId")]
        public PEPolicyEntity PreEnrollmentPolicy { get; set; }
    }
}