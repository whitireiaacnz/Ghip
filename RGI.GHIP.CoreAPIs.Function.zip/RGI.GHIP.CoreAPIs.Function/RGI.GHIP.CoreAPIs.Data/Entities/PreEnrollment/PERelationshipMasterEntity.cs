﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RGI.GHIP.CoreAPIs.Data.Entities.PreEnrollment
{
    [Table("RelationshipMasters", Schema = "GhipPE")]
    public class PERelationshipMasterEntity : EntityBase
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required]
        [MaxLength(256)]
        public string Label { get; set; }

        [Required]
        [MaxLength(256)]
        public string Type { get; set; }

        [Required]
        public int MinAgeLimit { get; set; }

        [Required]
        public int MaxAgeLimit { get; set; }

        public bool IsConfigurable { get; set; }

        public string Gender { get; set; }

        [Required]
        public int Count { get; set; }

        public bool IsEnabled { get; set; }

        public ICollection<PEPolicyRelationshipMappingEntity> RelationshipMapping { get; set; }

        public ICollection<PEMemberEntity> PreEnrollmentMembers { get; set; }
    }
}
