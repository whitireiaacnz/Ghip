﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RGI.GHIP.CoreAPIs.Data.Entities.PreEnrollment
{
    [Table("FieldMasters", Schema = "GhipPE")]
    public class PEFieldMasterEntity : EntityBase
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required]
        [MaxLength(256)]
        public string Label { get; set; }

        public bool IsEnabled { get; set; }

        public bool IsEditableForSelf { get; set; }

        public bool IsEditableForDependent { get; set; }

        public bool IsMandatoryForSelf { get; set; }

        public bool IsMandatoryForDependent { get; set; }

        public bool IsVisibleForSelf { get; set; }

        public bool IsVisibleForDependent { get; set; }

        [MaxLength(32)]
        public string DataType { get; set; }

        [MaxLength(32)]
        public string InputType { get; set; }

        [MaxLength(32)]
        public string Type { get; set; }

        [MaxLength(32)]
        public string Section { get; set; }

        [MaxLength]
        public string DropDownValues { get; set; }

        [MaxLength]
        public string Validation { get; set; }

        public bool IsConfigurable { get; set; }

        public ICollection<PEPolicyFieldMappingEntity> PolicyFieldMappings { get; set; }
    }
}
