﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RGI.GHIP.CoreAPIs.Data.Entities.PreEnrollment
{
    [Table("PolicyRelationshipMappings", Schema = "GhipPE")]
    public class PEPolicyRelationshipMappingEntity : EntityBase
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        public int PreEnrollmentPolicyId { get; set; }

        public int RelationshipMasterId { get; set; }

        [Required]
        public int MinAgeLimit { get; set; }

        [Required]
        public int MaxAgeLimit { get; set; }

        [Required]
        public int Count { get; set; }

        [ForeignKey("PreEnrollmentPolicyId")]
        public PEPolicyEntity PreEnrollmentPolicy { get; set; }

        [ForeignKey("RelationshipMasterId")]
        public PERelationshipMasterEntity RelationshipMaster { get; set; }
    }
}
