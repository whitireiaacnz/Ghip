using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using RGI.GHIP.CoreAPIs.Data.Entities;
using RGI.GHIP.CoreAPIs.Data.Entities.PreEnrollment;

[Table("SelfInsurance", Schema = "GhipPE")]
public class PESelfInsuranceEntity : EntityBase
{
    [Key]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; set; }

    public int PEPolicyId { get; set; }

    public int? ExtraBenefitsId { get; set; }

    public int SumInsured { get; set; }

    public int Multiples { get; set; }

    public string Grade { get; set; }

    public string Relationship { get; set; }

    [ForeignKey("PEPolicyId")]
    public PEPolicyEntity PreEnrollmentPolicy { get; set; }

    [ForeignKey("ExtraBenefitsId")]
    public PEExtraBenefitsEntity? ExtraBenefits { get; set; }

    public int Discount { get; set; }
}