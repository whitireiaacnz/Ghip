using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using RGI.GHIP.CoreAPIs.Data.Entities;
using RGI.GHIP.CoreAPIs.Data.Entities.PreEnrollment;

[Table("ExtraBenefitsHistory", Schema = "GhipPE")]
public class PEExtraBenefitsHistoryEntity : EntityBase
{
    [Key]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int Id { get; set; }

    public string Plan { get; set; }

    public int ExtraBenefitsId { get; set; }

    public int PEPolicyId { get; set; }

    public string SumInsuredType { get; set; }

    public string Instructions { get; set; }

    public string Relationship { get; set; }

    public string BenefitType { get; set; }

    public bool IsAllowed { get; set; }

    [ForeignKey("PEPolicyId")]
    public PEPolicyEntity PreEnrollmentPolicy { get; set; }

    [ForeignKey("ExtraBenefitsId")]
    public PEExtraBenefitsEntity ExtraBenefits { get; set; }
}