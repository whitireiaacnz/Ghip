using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RGI.GHIP.CoreAPIs.Data.Entities.PreEnrollment
{
    [Table("EnhanceSumInsuranceHistory", Schema = "GhipPE")]
    public class PEEnhanceSumInsuredHistoryEntity : EntityBase
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        public int EnhanceSumInsuranceId { get; set; }

        public int PEPolicyId { get; set; }

        public int? ExtraBenefitsId { get; set; }

        public int SumInsured { get; set; }

        public int Multiples { get; set; }

        public string Grade { get; set; }

        public int SinglePremium { get; set; }

        public int DoublePremium { get; set; }

        public int SelfPremium { get; set; }

        public string Relationship { get; set; }

        [ForeignKey("PEPolicyId")]
        public PEPolicyEntity PreEnrollmentPolicy { get; set; }

        [ForeignKey("ExtraBenefitsId")]
        public PEExtraBenefitsEntity? ExtraBenefits { get; set; }

        [ForeignKey("EnhanceSumInsuranceId")]
        public PEEnhanceSumInsuredEntity? EnhanceSumInsurance { get; set; }

        public int Discount { get; set; }

        public int GST { get; set; }

        public int Total { get; set; }
    }
}