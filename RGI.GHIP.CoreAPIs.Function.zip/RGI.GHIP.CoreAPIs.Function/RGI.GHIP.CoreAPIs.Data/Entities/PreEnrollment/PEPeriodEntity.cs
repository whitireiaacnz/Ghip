﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RGI.GHIP.CoreAPIs.Data.Entities.PreEnrollment
{
    [Table("PreEnrollmentPeriods", Schema = "GhipPE")]
    public class PEPeriodEntity : EntityBase
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        public int PreEnrollmentPolicyId { get; set; }

        [Required]
        [Column(TypeName = "date")]
        public DateTime StartDateTime { get; set; }

        [Required]
        [Column(TypeName = "date")]
        public DateTime EndDateTime { get; set; }

        [ForeignKey("PreEnrollmentPolicyId")]
        public PEPolicyEntity PreEnrollmentPolicy { get; set; }
    }
}
