﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RGI.GHIP.CoreAPIs.Data.Entities.PreEnrollment
{
    [Table("PreEnrollmentPolicies", Schema = "GhipPE")]
    public class PEPolicyEntity : EntityBase
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        public int CorporateId { get; set; }

        [Required]
        public int Year { get; set; }

        [Required]
        public string Name { get; set; }

        public string Plan { get; set; }

        [Required]
        public int TotalMembers { get; set; }

        [Required]
        public int MaxNumOfMembersPerFamily { get; set; }

        [Required]
        public int MaxNumOfChildrenAllowed { get; set; }

        public string? AllowedSumInsured { get; set; }

        public string? AllowedSumInsuredType { get; set; }

        [Required]
        [MaxLength(32)]
        public string PasswordPolicy { get; set; }

        public bool AllowEmployeeEditHisProfile { get; set; }

        public bool AllowEmployeeViewHisProfile { get; set; }

        public bool AllowHRResetProfile { get; set; }

        public bool AllowDeletingMember { get; set; }

        public bool ParentInLawCondition { get; set; }

        public bool AreTwinsAllowed { get; set; }

        public bool AreParentOptInAllowed { get; set; }

        [MaxLength]
        public string PSIType { get; set; }

        public string PSIValues { get; set; }

        public bool IsPSIAllowed { get; set; }

        public bool IsESIAllowed { get; set; }

        public string PSIPlan { get; set; }

        [MaxLength]
        public string ESIType { get; set; }

        public string ESIValues { get; set; }

        public string ESIPlan { get; set; }

        public string PSIInstructions { get; set; }

        public string TopupInstructions { get; set; }

        public string ESIInstructions { get; set; }

        public bool IsTopupAllowed { get; set; }

        [MaxLength]
        public string TopupType { get; set; }

        public string TopupValues { get; set; }

        public string TopUpPlan { get; set; }

        public bool SendReminderEmail { get; set; }

        public string ReminderEmailDateTime { get; set; }

        [MaxLength]
        public string ReminderEmailTemplate { get; set; }

        [MaxLength(254)]
        public string ReminderEmailSubject { get; set; }

        public bool SendWelcomeEmail { get; set; }

        [Column(TypeName = "date")]
        public DateTime WelcomeEmailDate { get; set; }

        public int WelcomeEmailHrs { get; set; }

        public int WelcomeEmailMin { get; set; }

        [MaxLength]
        public string WelcomeEmailTemplate { get; set; }

        [MaxLength(254)]
        public string WelcomeEmailSubject { get; set; }

        public bool SendConfirmationEmail { get; set; }

        [MaxLength]
        public string ConfirmationEmailTemplate { get; set; }

        [MaxLength(254)]
        public string RegistrationConfirmationEmailSubject { get; set; }

        public string RegistrationConfirmationEmailCcs { get; set; }

        public string RegistrationConfirmationEmailBccs { get; set; }

        public string Tax { get; set; }

        public string WelcomeEmailFile { get; set; }

        public string ConfirmationEmailFile { get; set; }

        public string ReminderEmailFile { get; set; }

        public string? WelcomeEmailFileName { get; set; }

        public string? ConfirmationEmailFileName { get; set; }

        public string? ReminderEmailFileName { get; set; }

        [Required]
        [Column(TypeName = "date")]
        public DateTime StartDate { get; set; }

        [Required]
        [Column(TypeName = "date")]
        public DateTime EndDate { get; set; }

        [ForeignKey("CorporateId")]
        public CorporateEntity Corporate { get; set; } // Corporate is navigation property and foreign key is corporateId

        public bool IsGSTExempted { get; set; }

        public string GSTFileUpload { get; set; }

        public int GSTPercentage { get; set; }

        public bool CreateUsers { get; set; }

        public ICollection<PEPolicyFieldMappingEntity> PolicyFieldMappings { get; set; }

        public ICollection<PEPolicyRelationshipMappingEntity> PolicyRelationshipMappings { get; set; }

        public ICollection<PEMemberEntity> PreEnrollmentMembers { get; set; }

        public ICollection<PEPeriodEntity> PreEnrollmentPeriods { get; set; }

        public ICollection<PEParentInsuranceEntity> PEParentInsurance { get; set; }

        public ICollection<PEExtraBenefitsEntity> PreEnrollmentExtraBenefits { get; set; }
    }
}
