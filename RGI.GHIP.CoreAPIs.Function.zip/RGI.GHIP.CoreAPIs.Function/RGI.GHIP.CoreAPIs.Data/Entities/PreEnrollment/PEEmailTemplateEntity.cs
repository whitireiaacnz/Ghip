﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RGI.GHIP.CoreAPIs.Data.Entities.PreEnrollment
{
    [Table("EmailTemplates", Schema = "GhipPE")]
    public class PEEmailTemplateEntity : EntityBase
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [MaxLength]
        public string WelcomeEmailTemplate { get; set; }

        [MaxLength]
        public string ConfirmationEmailTemplate { get; set; }

        [MaxLength]
        public string ReminderEmailTemplate { get; set; }
    }
}
