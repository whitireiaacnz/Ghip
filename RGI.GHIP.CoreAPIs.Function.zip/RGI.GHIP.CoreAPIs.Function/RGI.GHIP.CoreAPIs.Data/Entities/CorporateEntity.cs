﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using RGI.GHIP.CoreAPIs.Data.Entities.PreEnrollment;

namespace RGI.GHIP.CoreAPIs.Data.Entities
{
    [Table("Corporates", Schema = "GhipGlobal")]
    public class CorporateEntity : EntityBase
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required]
        [MaxLength(256)]
        public string Name { get; set; }

        [Required]
        [MaxLength(10)]
        public string Code { get; set; }

        [EmailAddress]
        public string EmailId { get; set; }

        [MaxLength]
        public string LogoImage { get; set; }

        [MaxLength(256)]
        public string AddressLine1 { get; set; }

        [MaxLength(256)]
        public string AddressLine2 { get; set; }

        [MaxLength(512)]
        public string Website { get; set; }

        [MaxLength(256)]
        public string City { get; set; }

        [MaxLength(256)]
        public string District { get; set; }

        [MaxLength(256)]
        public string Area { get; set; }

        [MaxLength(256)]
        public string State { get; set; }

        [Required]
        [MaxLength(16)]
        public string Pincode { get; set; }

        public int CityId { get; set; }

        public int DistrictId { get; set; }

        public long AreaId { get; set; }

        public int StateId { get; set; }

        [Required]
        [MaxLength(256)]
        public string ContactName { get; set; }

        [MaxLength(16)]
        public string MobileNo { get; set; }

        [MaxLength(16)]
        public string LandlineNo { get; set; }

        // Corporate is principle entity has navigation peroperty PreEnrollmentPolicy
        public ICollection<PEPolicyEntity> PreEnrollmentPolicy { get; set; }

        public string FilePath { get; set; }
    }
}
