﻿namespace RGI.GHIP.CoreAPIs.Data.Entities.CorporatePortal
{
    public class CPBasePrivilegesEntity : EntityBase
    {
        public bool ReportAllowed { get; set; }

        public bool CashlessReport { get; set; }

        public bool ReimbersementReport { get; set; }

        public bool Endoresment { get; set; }

        public bool Dashboard { get; set; }

        public bool StaticDashboard { get; set; }

        public bool DyanamicDashboard { get; set; }
    }
}
