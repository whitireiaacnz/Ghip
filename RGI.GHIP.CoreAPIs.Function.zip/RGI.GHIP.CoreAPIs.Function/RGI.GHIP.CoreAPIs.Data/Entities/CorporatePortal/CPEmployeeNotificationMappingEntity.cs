﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RGI.GHIP.CoreAPIs.Data.Entities.CorporatePortal
{
    [Table("EmployeeNotificationMapping", Schema = "GhipCP")]
    public class CPEmployeeNotificationMappingEntity : EntityBase
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid Id { get; set; }

        [ForeignKey("Employee")]
        public Guid EmployeeMappingId { get; set; }

        [ForeignKey("Notification")]
        public Guid NotificationId { get; set; }

        public bool IsSeen { get; set; }

        public DateTime SeenAt { get; set; }

        public CPNotificationEntity Notification { get; set; }

        public CPCorporateEmployeeEntity Employee { get; set; }
    }
}
