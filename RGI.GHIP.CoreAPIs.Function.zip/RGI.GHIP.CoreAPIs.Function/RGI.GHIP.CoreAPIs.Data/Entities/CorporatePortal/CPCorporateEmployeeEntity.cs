﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RGI.GHIP.CoreAPIs.Data.Entities.CorporatePortal
{
    [Table("CorporateEmployee", Schema = "GhipCP")]
    public class CPCorporateEmployeeEntity : EntityBase
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid Id { get; set; }

        [ForeignKey("Corporate")]
        public int CorporateId { get; set; }

        public int UserId { get; set; }

        [MaxLength(50)]
        public string EmployeeId { get; set; }

        [MaxLength(256)]
        public string InsuredName { get; set; }

        [MaxLength(128)]
        public string Email { get; set; }

        [MaxLength(16)]
        public string MobileNo { get; set; }

        public string WelcomeEmailTemplate { get; set; }

        public bool IsMember { get; set; }

        public bool IsHR { get; set; }

        public bool IsLoginDetailsSent { get; set; }

        public int EmailSentTrial { get; set; }

        public string EmailSentError { get; set; }

        public DateTime LoginEmailSentAt { get; set; }

        public int SMSSentTrial { get; set; }

        public string SMSSentError { get; set; }

        public DateTime LoginSMSSentAt { get; set; }

        public bool IsLoginDetailsCreated { get; set; }

        public DateTime LoginDetailsCreatedAt { get; set; }

        public CorporateEntity Corporate { get; set; }
    }
}
