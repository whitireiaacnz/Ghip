﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RGI.GHIP.CoreAPIs.Data.Entities.CorporatePortal
{
    [Table("Documents", Schema = "GhipCP")]
    public class CPDocumentEntity : EntityBase
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid Id { get; set; }

        [ForeignKey("Policy")]
        public Guid CPPolicyId { get; set; }

        [MaxLength(32)]
        public string DocumentType { get; set; }

        [MaxLength(256)]
        public string DocumentName { get; set; }

        [MaxLength(128)]
        public string DocumentTypeName { get; set; }

        public string DocumentUrl { get; set; }
    }
}
