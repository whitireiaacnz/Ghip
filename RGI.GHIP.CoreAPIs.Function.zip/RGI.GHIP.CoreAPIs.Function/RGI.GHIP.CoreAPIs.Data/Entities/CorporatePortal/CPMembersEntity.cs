﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RGI.GHIP.CoreAPIs.Data.Entities.CorporatePortal
{
    [Table("Members", Schema = "GhipCP")]
    public class CPMembersEntity : EntityBase
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid Id { get; set; }

        [ForeignKey("Policy")]
        public Guid CPPolicyId { get; set; }

        public int RGIId { get; set; }

        [MaxLength(32)]
        public string PolicyNo { get; set; }

        [MaxLength(50)]
        public string EmployeeId { get; set; }

        [MaxLength(32)]
        public string UHID { get; set; }

        [MaxLength(256)]
        public string InsuredName { get; set; }

        [MaxLength(32)]
        public string Relationship { get; set; }

        [MaxLength(32)]
        public string DOB { get; set; }

        [MaxLength(32)]
        [Column("Gender")]
        public string Sex { get; set; }

        public string Address1 { get; set; }

        public string Address2 { get; set; }

        [MaxLength(128)]
        public string State { get; set; }

        [MaxLength(128)]
        public string City { get; set; }

        [MaxLength(128)]
        public string Taluka { get; set; }

        [MaxLength(128)]
        public string District { get; set; }

        [MaxLength(16)]
        public string Pincode { get; set; }

        [MaxLength(128)]
        public string Email { get; set; }

        [MaxLength(16)]
        public string MobileNo { get; set; }

        [MaxLength(32)]
        public string WebReferenceNo { get; set; }

        [MaxLength(32)]
        public string Comm_code { get; set; }

        public DateTime DOJ { get; set; }

        [MaxLength(32)]
        public string EnrollmentType { get; set; }

        public bool IsActive { get; set; }

        public DateTime InsertedAt { get; set; }

        public CPPolicyEntity CPPolicy { get; set; }
    }
}
