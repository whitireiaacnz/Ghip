﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RGI.GHIP.CoreAPIs.Data.Entities.CorporatePortal
{
    [Table("EndorsementMember", Schema = "GhipCP")]
    public class CPEndorsementMemberEntity : EntityBase
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid Id { get; set; }

        [ForeignKey("Policy")]
        public Guid CPPolicyId { get; set; }

        [MaxLength(32)]
        public string PolicyNo { get; set; }

        [MaxLength(32)]
        public string EmployeeId { get; set; }

        [MaxLength(32)]
        public string UHID { get; set; }

        [MaxLength(256)]
        public string InsuredName { get; set; }

        [MaxLength(32)]
        public string Relationship { get; set; }

        public int SumInsured { get; set; }

        public int TopupSI { get; set; }

        [MaxLength(32)]
        public string DOB { get; set; }

        [MaxLength(32)]
        public string Gender { get; set; }

        public string Designation { get; set; }

        [MaxLength(256)]
        public string Location { get; set; }

        [MaxLength(128)]
        public string Email { get; set; }

        [MaxLength(16)]
        public string MobileNo { get; set; }

        [MaxLength(16)]
        public string Grade { get; set; }

        [MaxLength(32)]
        public string Elite { get; set; }

        [MaxLength(32)]
        public string EndorsementType { get; set; }

        [MaxLength(32)]
        public string EndorsementBy { get; set; }

        public bool IsApproved { get; set; }

        public string ApproveRejectFlow { get; set; }

        public bool IsRejected { get; set; }

        public CPPolicyEntity CPPolicy { get; set; }
    }
}
