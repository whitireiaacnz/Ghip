using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RGI.GHIP.CoreAPIs.Data.Entities.CorporatePortal
{
    [Table("PolicyMemberFeaturesVersion", Schema = "GhipCP")]
    public class CPPolicyVersionMemberFeatureEntity : EntityBase
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid Id { get; set; }

        [ForeignKey("CPPolicyFeature")]
        public Guid CPPolicyMemberFeatureId { get; set; }

        [ForeignKey("Policy")]
        public Guid CPPolicyId { get; set; }

        [Column("Endorsement")]
        public bool? AdditionOfDependents { get; set; }

        public bool? TrackClaims { get; set; }

        public bool? ViewECard { get; set; }

        public bool? NetworkHospitalTracker { get; set; }

        public bool? DownloadForms { get; set; }

        public bool? IntimateClaims { get; set; }

        public bool? ContactUs { get; set; }

        public bool? FAQ { get; set; }

        public bool? Wellness { get; set; }

        public bool? RHealthAssist { get; set; }

        public bool? RHealthCircle { get; set; }

        public bool? RHealthBeat { get; set; }

        public bool? HealthOPedia { get; set; }

        public bool? HRA { get; set; }

        public bool? ValueDeals { get; set; }

        public CorporateEntity Corporate { get; set; }

        public CPPolicyEntity Policy { get; set; }

        public CPPolicyMemberFeaturesEntity CPPolicyFeature { get; set; }
    }
}