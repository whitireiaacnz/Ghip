﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using RGI.GHIP.CoreAPIs.Data.Entities.Masters;

namespace RGI.GHIP.CoreAPIs.Data.Entities.CorporatePortal
{
    [Table("BrokerPolicyMapping", Schema = "GhipCP")]
    public class CPBrokerPolicyMappingEntity : CPBasePrivilegesEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid Id { get; set; }

        [ForeignKey("Policy")]
        public Guid CPPolicyId { get; set; }

        [ForeignKey("BrokerMaster")]
        public Guid BrokerId { get; set; }

        public CPPolicyEntity CPPolicy { get; set; }

        public BrokerMasterEntity BrokerMaster { get; set; }
    }
}
