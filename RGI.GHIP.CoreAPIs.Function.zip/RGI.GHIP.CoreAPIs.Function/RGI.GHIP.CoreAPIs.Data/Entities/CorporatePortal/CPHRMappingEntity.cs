﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RGI.GHIP.CoreAPIs.Data.Entities.CorporatePortal
{
    [Table("HRMapping", Schema = "GhipCP")]
    public class CPHRMappingEntity : CPBasePrivilegesEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid Id { get; set; }

        [ForeignKey("Corporate")]
        public int CorporateId { get; set; }

        [MaxLength(50)]
        public string HREmpId { get; set; }

        [MaxLength(256)]
        public string Name { get; set; }

        [MaxLength(128)]
        public string Email { get; set; }

        [MaxLength(16)]
        public string MobileNo { get; set; }

        [MaxLength(256)]
        public string CommCodes { get; set; }

        public CorporateEntity Corporate { get; set; }
    }
}
