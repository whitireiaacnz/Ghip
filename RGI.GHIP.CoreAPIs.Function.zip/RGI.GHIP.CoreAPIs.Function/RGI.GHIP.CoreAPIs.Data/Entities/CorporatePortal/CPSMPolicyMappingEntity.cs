﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using RGI.GHIP.CoreAPIs.Data.Entities.Masters;

namespace RGI.GHIP.CoreAPIs.Data.Entities.CorporatePortal
{
    [Table("SMPolicyMapping", Schema = "GhipCP")]
    public class CPSMPolicyMappingEntity : CPBasePrivilegesEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid Id { get; set; }

        [ForeignKey("Policy")]
        public Guid CPPolicyId { get; set; }

        [ForeignKey("SMMaster")]
        public Guid SMId { get; set; }

        public CPPolicyEntity CPPolicy { get; set; }

        public SMMasterEntity SMMaster { get; set; }
    }
}
