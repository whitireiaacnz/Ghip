﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RGI.GHIP.CoreAPIs.Data.Entities.CorporatePortal
{
    [Table("HRCommCodeMapping", Schema = "GhipCP")]
    public class CPHRCommCodeMappingEntity : EntityBase
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid Id { get; set; }

        [ForeignKey("HR")]
        public Guid HRId { get; set; }

        [ForeignKey("Policy")]
        public Guid PolicyId { get; set; }

        [MaxLength(256)]
        public string CommunicationCode { get; set; }

        public CPHRMappingEntity HR { get; set; }

        public CPPolicyEntity Policy { get; set; }
    }
}
