﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RGI.GHIP.CoreAPIs.Data.Entities.CorporatePortal
{
    [Table("Notification", Schema = "GhipCP")]
    public class CPNotificationEntity : EntityBase
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid Id { get; set; }

        public string Subject { get; set; }

        public string Content { get; set; }

        public string File { get; set; }

        public bool IsAllCorporate { get; set; }

        [ForeignKey("Corporate")]
        public int? SpecificCorporate { get; set; }

        public bool IsForAllPolicy { get; set; }

        [ForeignKey("Policy")]
        public Guid? SpecificPolicy { get; set; }

        public bool IsMultiplePolicy { get; set; }

        public string MultiplePolicy { get; set; }

        public bool IsForHR { get; set; }

        public bool IsForMember { get; set; }

        [MaxLength(32)]
        public string NotificationBy { get; set; }

        public bool IsApproved { get; set; }

        public string ApprovedBy { get; set; }

        public DateTime ApprovedAt { get; set; }

        public bool IsRejected { get; set; }

        public string RejectedBy { get; set; }

        public DateTime RejectedAt { get; set; }

        public string Remark { get; set; }

        public DateTime EffectiveDateFrom { get; set; }

        public DateTime EffectiveDateTo { get; set; }

        public CorporateEntity Corporate { get; set; }

        public CPPolicyEntity Policy { get; set; }

        public ICollection<CPEmployeeNotificationMappingEntity> EmployeeNotifications { get; set; }
    }
}
