﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RGI.GHIP.CoreAPIs.Data.Entities.CorporatePortal
{
    [Table("Policy", Schema = "GhipCP")]
    public class CPPolicyEntity : EntityBase
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid Id { get; set; }

        [ForeignKey("Corporate")]
        public int? CorporateId { get; set; } = null;

        public int RGIId { get; set; }

        [MaxLength(32)]
        public string PolicyNumber { get; set; }

        [MaxLength(32)]
        public string ProductCode { get; set; }

        [MaxLength(32)]
        public string? PolicyType { get; set; }

        public int? FamilySize { get; set; }

        public int? BranchId { get; set; }

        [MaxLength(256)]
        public string? InsuredName { get; set; }

        public DateTime RiskStartDate { get; set; }

        public DateTime RiskEndDate { get; set; }

        public DateTime IssueDate { get; set; }

        [MaxLength(32)]
        public string? GracePeriodType { get; set; }

        public int? GracePeriodValue { get; set; }

        [MaxLength(64)]
        public string? UserNameType { get; set; }

        [MaxLength(64)]
        public string? PasswordType { get; set; }

        public bool? IsDependentCovered { get; set; }

        public bool IsSyncOn { get; set; }

        public bool IsSendWelcomeEmail { get; set; }

        public bool IsSendWelcomeSMS { get; set; }

        public bool IsActive { get; set; }

        public string WelcomeEmailTemplate { get; set; }

        [MaxLength(254)]
        public string WelcomeEmailSubject { get; set; }

        public DateTime InsertedAt { get; set; }

        public CorporateEntity? Corporate { get; set; }

        public CPPolicyMemberFeaturesEntity? CPPolicyMemberFeatures { get; set; }

        public DateTime AttachedAt { get; set; }

        public DateTime LastDetachedAt { get; set; }

        public int DetachCount { get; set; }

        public string DetachedBy { get; set; }

        public string WelcomeEmailFile { get; set; }

        public string? WelcomeEmailFileName { get; set; }
    }
}
