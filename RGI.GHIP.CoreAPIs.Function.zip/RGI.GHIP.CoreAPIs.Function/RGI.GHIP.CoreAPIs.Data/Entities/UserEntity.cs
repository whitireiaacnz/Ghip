﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RGI.GHIP.CoreAPIs.Data.Entities
{
    [Table("Users", Schema = "GhipGlobal")]
    public class UserEntity : EntityBase
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required]
        public string IdentityServiceUserId { get; set; }

        public string? UserId { get; set; }

        [MaxLength(32)]
        public string? UserType { get; set; }

        [Required]
        [MaxLength(100)]
        public string UserName { get; set; }

        public DateTime LastLoggedInAt { get; set; }

        public DateTime LastResetAt { get; set; }

        public int ResetCount { get; set; }

        public bool IsDisabled { get; set; }

        public int RoleId { get; set; }

        [ForeignKey("RoleId")]
        public RoleEntity Role { get; set; }
    }
}
