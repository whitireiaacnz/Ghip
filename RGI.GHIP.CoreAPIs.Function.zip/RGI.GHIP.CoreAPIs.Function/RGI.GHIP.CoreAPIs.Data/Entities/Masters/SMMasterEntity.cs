﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RGI.GHIP.CoreAPIs.Data.Entities.Masters
{
    [Table("SMMaster", Schema = "GhipGlobal")]
    public class SMMasterEntity : EntityBase
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid Id { get; set; }

        public int RGIId { get; set; }

        public string Code { get; set; }

        public string Name { get; set; }

        public string Email { get; set; }

        public string MobileNo { get; set; }

        public DateTime LoginEmailSentAt { get; set; }

        public DateTime LoginSMSSentAt { get; set; }

        public bool IsActive { get; set; }

        public DateTime InsertedAt { get; set; }

        [MaxLength(128)]
        public string? InsertedBy { get; set; }
    }
}
