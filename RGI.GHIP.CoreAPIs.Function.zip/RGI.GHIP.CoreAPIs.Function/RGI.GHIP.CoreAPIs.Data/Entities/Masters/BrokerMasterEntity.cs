﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RGI.GHIP.CoreAPIs.Data.Entities.Masters
{
    [Table("BrokerMaster", Schema = "GhipGlobal")]
    public class BrokerMasterEntity : EntityBase
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid Id { get; set; }

        public int RGIId { get; set; }

        public string Code { get; set; }

        public string Name { get; set; }

        public string Email { get; set; }

        public string MobileNo { get; set; }

        public bool IsLoginDetailsSent { get; set; }

        public string EmailSentTrial { get; set; }

        public string EmailSentError { get; set; }

        public DateTime LoginEmailSentAt { get; set; }

        public string SMSSentTrial { get; set; }

        public string SMSSentError { get; set; }

        public DateTime LoginSMSSentAt { get; set; }

        public bool IsLoginDetailsCreated { get; set; }

        public DateTime LoginDetailsCreatedAt { get; set; }

        public bool IsActive { get; set; }

        public DateTime InsertedAt { get; set; }

        [MaxLength(128)]
        public string? InsertedBy { get; set; }

        public bool IsExternal { get; set; }
    }
}
