﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RGI.GHIP.CoreAPIs.Data.Entities.Masters.AddressMasters
{
    [Table("DistrictMaster", Schema = "GhipGlobal")]
    public class DistrictMasterEntity : EntityBase
    {
        [Key]
        public int Id { get; set; }

        public int StateId { get; set; }

        [MaxLength(50)]
        public string DistrictCode { get; set; }

        [MaxLength(250)]
        public string DistrictName { get; set; }

        [MaxLength(50)]
        public string EqZone { get; set; }

        [MaxLength(50)]
        public string Field1 { get; set; }

        [MaxLength(50)]
        public string Field2 { get; set; }

        public bool CityDistrictArc { get; set; }

        public List<CityOrVillageMasterEntity> Cities { get; set; }

        [ForeignKey("StateId")]
        public StateMasterEntity State { get; set; }
    }
}
