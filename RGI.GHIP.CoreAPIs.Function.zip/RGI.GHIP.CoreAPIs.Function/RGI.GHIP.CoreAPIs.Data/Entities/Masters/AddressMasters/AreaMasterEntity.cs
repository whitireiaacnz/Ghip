﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RGI.GHIP.CoreAPIs.Data.Entities.Masters.AddressMasters
{
    [Table("AreaMaster", Schema = "GhipGlobal")]
    public class AreaMasterEntity : EntityBase
    {
        [Key]
        public long Id { get; set; }

        public int CityId { get; set; }

        [Required]
        [MaxLength(250)]
        public string AreaName { get; set; }

        [Required]
        public string PinCode { get; set; }

        [MaxLength(50)]
        public string Field1 { get; set; }

        [MaxLength(50)]
        public string Field2 { get; set; }

        public bool AreaArc { get; set; }

        public int DistrictId { get; set; }

        [MaxLength(100)]
        public string Latitude { get; set; }

        [MaxLength(100)]
        public string Longitude { get; set; }

        [MaxLength(200)]
        public string LatLongAddress { get; set; }

        public bool? IsError { get; set; }

        [ForeignKey("CityId")]
        public CityOrVillageMasterEntity City { get; set; }
    }
}
