﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RGI.GHIP.CoreAPIs.Data.Entities.Masters.AddressMasters
{
    [Table("StateMaster", Schema = "GhipGlobal")]
    public class StateMasterEntity : EntityBase
    {
        [Key]
        public int Id { get; set; }

        public int StateCountryIdFk { get; set; }

        [MaxLength(50)]
        public string StateCode { get; set; }

        [Required]
        [MaxLength(250)]
        public string StateName { get; set; }

        [MaxLength(50)]
        public string Field1 { get; set; }

        [MaxLength(50)]
        public string Field2 { get; set; }

        public bool StateArc { get; set; }

        [MaxLength(50)]
        public string GstCode { get; set; }

        public bool? IsUnionTerritory { get; set; }

        [MaxLength(4000)]
        public string OmbudsmanAddress { get; set; }

        public string GrievanceClause { get; set; }

        public List<DistrictMasterEntity> Districts { get; set; }
    }
}
