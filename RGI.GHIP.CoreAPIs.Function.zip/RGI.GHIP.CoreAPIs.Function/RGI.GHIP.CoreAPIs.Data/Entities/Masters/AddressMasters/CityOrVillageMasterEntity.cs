﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RGI.GHIP.CoreAPIs.Data.Entities.Masters.AddressMasters
{
    [Table("CityOrVillageMaster", Schema = "GhipGlobal")]
    public class CityOrVillageMasterEntity : EntityBase
    {
        [Key]
        public int Id { get; set; }

        public int DistrictId { get; set; }

        [MaxLength(250)]
        public string CityOrVillageCode { get; set; }

        [MaxLength(250)]
        public string CityOrVillageName { get; set; }

        [MaxLength(250)]
        public string CityType { get; set; }

        [MaxLength(250)]
        public string Tahsil { get; set; }

        [MaxLength(50)]
        public string Pincode { get; set; }

        [MaxLength(50)]
        public string Field1 { get; set; }

        [MaxLength(50)]
        public string Field2 { get; set; }

        public bool CityCityOrVillageArc { get; set; }

        public int? BranchIdFk { get; set; }

        public List<AreaMasterEntity> Area { get; set; }

        [ForeignKey("DistrictId")]
        public DistrictMasterEntity District { get; set; }
    }
}
