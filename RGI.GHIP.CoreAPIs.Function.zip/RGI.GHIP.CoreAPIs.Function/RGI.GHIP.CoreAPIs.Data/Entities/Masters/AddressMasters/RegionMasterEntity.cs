﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RGI.GHIP.CoreAPIs.Data.Entities.Masters.AddressMasters
{
    [Table("RegionMaster", Schema = "GhipGlobal")]
    public class RegionMasterEntity : EntityBase
    {
        [Key]
        public int Id { get; set; }

        public int? SystemRegionId { get; set; }

        public int RegionZoneIdFk { get; set; }

        public string ZoneCode { get; set; }

        public string RegionCode { get; set; }

        public string RegionName { get; set; }

        public string Field1 { get; set; }

        public string Field2 { get; set; }

        public bool RegionArc { get; set; }
    }
}
