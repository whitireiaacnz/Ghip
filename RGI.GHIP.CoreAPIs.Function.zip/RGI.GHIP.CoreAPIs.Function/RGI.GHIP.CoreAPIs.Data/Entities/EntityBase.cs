﻿using System;
using System.ComponentModel.DataAnnotations;

namespace RGI.GHIP.CoreAPIs.Data.Entities
{
    public class EntityBase
    {
        public DateTime CreatedAt { get; set; }

        [MaxLength(128)]
        public string CreatedBy { get; set; }

        public DateTime ModifiedAt { get; set; }

        [MaxLength(128)]
        public string ModifiedBy { get; set; }

        public bool IsDeleted { get; set; }

        public bool IsTestData { get; set; }
    }
}
