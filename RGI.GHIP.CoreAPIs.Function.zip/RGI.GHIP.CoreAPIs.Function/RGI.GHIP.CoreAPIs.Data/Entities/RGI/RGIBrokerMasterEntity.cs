﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RGI.GHIP.CoreAPIs.Data.Entities.RGI
{
    [Table("BrokerMaster", Schema = "RGI")]
    public class RGIBrokerMasterEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int VendorIdPk { get; set; }

        [MaxLength(32)]
        public string VendorSapCode { get; set; }

        [MaxLength(32)]
        public string VendorNewSapCode { get; set; }

        [MaxLength(32)]
        public string AccountGroup { get; set; }

        [MaxLength(32)]
        public string AgentOrBrokerCode { get; set; }

        public string Address { get; set; }

        [MaxLength(128)]
        public string CityOrVillage { get; set; }

        [MaxLength(128)]
        public string District { get; set; }

        [MaxLength(128)]
        public string State { get; set; }

        [MaxLength(128)]
        public string Country { get; set; }

        public string PinCode { get; set; }

        [MaxLength(16)]
        public string TelePhone { get; set; }

        [MaxLength(16)]
        public string MobileNo { get; set; }

        [MaxLength(32)]
        public string EmailId { get; set; }

        [MaxLength(32)]
        public string Fax { get; set; }

        [MaxLength(32)]
        public string VendorType { get; set; }

        [MaxLength(256)]
        public string VendorName { get; set; }

        [MaxLength(32)]
        public string AgentOrBrokerIrdaCode { get; set; }

        public DateTime? LicenseValidTo { get; set; }

        [MaxLength(32)]
        public string BranchCode { get; set; }

        [MaxLength(32)]
        public string ServiceTaxNumber { get; set; }

        [MaxLength(32)]
        public string PaymentTerms { get; set; }

        [MaxLength(32)]
        public string CompanyCode { get; set; }

        [MaxLength(64)]
        public string BankAccNo { get; set; }

        [MaxLength(256)]
        public string BankName { get; set; }

        [MaxLength(256)]
        public string BankBranchName { get; set; }

        [MaxLength(256)]
        public string ReconcilationAcct { get; set; }

        [MaxLength(256)]
        public string TaxCd { get; set; }

        [MaxLength(32)]
        public string PanNo { get; set; }

        public DateTime? CreatedDateSap { get; set; }

        [MaxLength(32)]
        public string ChannelCode { get; set; }

        public string SubChannelName { get; set; }

        [MaxLength(32)]
        public string BusinessTypeCode { get; set; }

        [MaxLength(32)]
        public string AccountTypeCode { get; set; }

        public double? InitialAmount { get; set; }

        public double? UsageAmount { get; set; }

        public int? CreditDays { get; set; }

        public DateTime RGICreatedAt { get; set; }

        [MaxLength(128)]
        public string RGICreatedBy { get; set; }

        public DateTime? RGIUpdatedAt { get; set; }

        [MaxLength(128)]
        public string RGIUpdatedBy { get; set; }

        public DateTime? RGIDeletedAt { get; set; }

        [MaxLength(128)]
        public string RGIDeletedBy { get; set; }

        [MaxLength(256)]
        public string Field1 { get; set; }

        [MaxLength(256)]
        public string Field2 { get; set; }

        public bool IsActive { get; set; }

        public bool VendorArc { get; set; }

        public DateTime InsertedAt { get; set; }

        [MaxLength(128)]
        public string? InsertedBy { get; set; }
    }
}
