﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RGI.GHIP.CoreAPIs.Data.Entities.RGI
{
    [Table("CPPolicy", Schema = "RGI")]
    public class RGICPPolicyEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [MaxLength(32)]
        public string PolicyNo { get; set; }

        public DateTime? PolicyStartDate { get; set; }

        public DateTime? PolicyEndDate { get; set; }

        [MaxLength(32)]
        public string ProductCode { get; set; }

        [MaxLength(32)]
        public string SMCode { get; set; }

        [MaxLength(256)]
        public string SMName { get; set; }

        [MaxLength(32)]
        public string BrokerCode { get; set; }

        [MaxLength(256)]
        public string BrokerName { get; set; }

        [MaxLength(256)]
        public string InsuredName { get; set; }

        public int? BranchIdPk { get; set; }

        public byte? FamilySize { get; set; }

        public DateTime? RGIUpdatedAt { get; set; }

        [MaxLength(64)]
        public string? RGICreatedBy { get; set; }

        [MaxLength(32)]
        public string GraceType { get; set; }

        [MaxLength(32)]
        public string GracePeriod { get; set; }

        [MaxLength(32)]
        public string PolicyType { get; set; }

        public bool? IsDependentCovered { get; set; }

        public bool IsActive { get; set; }

        public DateTime InsertedAt { get; set; }

        public string InsertedBy { get; set; }
    }
}
