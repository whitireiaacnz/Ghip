﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RGI.GHIP.CoreAPIs.Data.Entities.RGI
{
    [Table("SMMaster", Schema = "RGI")]
    public class RGISMMasterEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int EmployeeIdPk { get; set; }

        public int? ReportingEmployeeIdPk { get; set; }

        public int? SystemSMId { get; set; }

        [MaxLength(64)]
        public string SMVertical { get; set; }

        [MaxLength(64)]
        public string SMChannel { get; set; }

        public DateTime DOB { get; set; }

        public DateTime DateOfJoining { get; set; }

        public DateTime? DateOfResigning { get; set; }

        public DateTime? SystemDateOfResigining { get; set; }

        public string EmployeeDesignation { get; set; }

        public string EmployeeDepartment { get; set; }

        public int EmployeeBranchIdFk { get; set; }

        [MaxLength(256)]
        public string EmployeeHrFunction { get; set; }

        [MaxLength(128)]
        public string EmployeeFunction { get; set; }

        [MaxLength(256)]
        public string EmployeeName { get; set; }

        [MaxLength(32)]
        public string EmployeeCode { get; set; }

        [MaxLength(32)]
        public string Fax { get; set; }

        public DateTime RGICreatedAt { get; set; }

        [MaxLength(128)]
        public string RGICreatedBy { get; set; }

        public DateTime? RGIUpdatedAt { get; set; }

        [MaxLength(128)]
        public string RGIUpdatedBy { get; set; }

        public DateTime? RGIDeletedAt { get; set; }

        [MaxLength(128)]
        public string RGIDeletedBy { get; set; }

        public string Field1 { get; set; }

        public string Field2 { get; set; }

        public bool EmployeeArc { get; set; }

        [MaxLength(64)]
        public string Title { get; set; }

        [MaxLength(256)]
        public string FirstName { get; set; }

        [MaxLength(256)]
        public string MiddleName { get; set; }

        [MaxLength(256)]
        public string LastName { get; set; }

        [MaxLength(16)]
        public string Gender { get; set; }

        public bool? ResgnInProgress { get; set; }

        public DateTime? LastWorkingDate { get; set; }

        [MaxLength(32)]
        public string Status { get; set; }

        public int? DirectRepAuth { get; set; }

        public int? FunctionalRepAuth { get; set; }

        public DateTime? DateOfOffer { get; set; }

        [MaxLength(32)]
        public string JobCode { get; set; }

        [MaxLength(32)]
        public string CostCenterCode { get; set; }

        [MaxLength(32)]
        public string OmCode { get; set; }

        [MaxLength(32)]
        public string Grade { get; set; }

        [MaxLength(32)]
        public string ContactNo { get; set; }

        [MaxLength(128)]
        public string Email { get; set; }

        [MaxLength(32)]
        public string PositionCode { get; set; }

        public bool? SpokeType { get; set; }

        [MaxLength(32)]
        public string SpokeBranch { get; set; }

        [MaxLength(32)]
        public string RecruitmentType { get; set; }

        public DateTime? EmployeeTransferDate { get; set; }

        public DateTime? ConfirmationDate { get; set; }

        public bool? ConfirmationStatus { get; set; }

        public bool IsActive { get; set; }

        public DateTime InsertedAt { get; set; }

        [MaxLength(128)]
        public string InsertedBy { get; set; }
    }
}
