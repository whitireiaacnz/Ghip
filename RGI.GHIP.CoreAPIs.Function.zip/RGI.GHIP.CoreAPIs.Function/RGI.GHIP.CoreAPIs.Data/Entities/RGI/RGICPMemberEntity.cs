﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RGI.GHIP.CoreAPIs.Data.Entities.RGI
{
    [Table("CPMember", Schema = "RGI")]
    public class RGICPMemberEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [MaxLength(32)]
        public string PolicyNo { get; set; }

        public int? PolicyId { get; set; }

        [MaxLength(50)]
        public string EmployeeId { get; set; }

        [MaxLength(32)]
        public string UHID { get; set; }

        [MaxLength(256)]
        public string Insuredname { get; set; }

        public DateTime? DOB { get; set; }

        [MaxLength(16)]
        public string Gender { get; set; }

        public string Address1 { get; set; }

        public string Address2 { get; set; }

        [MaxLength(128)]
        public string City { get; set; }

        [MaxLength(128)]
        public string Taluka { get; set; }

        [MaxLength(128)]
        public string District { get; set; }

        public int? Pincode { get; set; }

        [MaxLength(128)]
        public string State { get; set; }

        [MaxLength(16)]
        public string MobileNo { get; set; }

        [MaxLength(128)]
        public string EmailId { get; set; }

        [MaxLength(128)]
        public string Webreferenceno { get; set; }

        public int? CommCode { get; set; }

        public bool? IsActive { get; set; }

        public DateTime? RGICreatedAt { get; set; }

        public DateTime InsertedAt { get; set; }

        [MaxLength(128)]
        public string InsertedBy { get; set; }

        public DateTime? DateOfJoining { get; set; }

        [MaxLength(32)]
        public string Relationship { get; set; }

        [MaxLength(32)]
        public string EnrollType { get; set; }

        public int MemberIdPK { get; set; }
    }
}
