using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RGI.GHIP.CoreAPIs.Data.Entities
{
    [Table("UsersMig", Schema = "Migration")]
    public class UserMigrationEntity : EntityBase
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        public string UserName { get; set; }

        public string UserNameType { get; set; }

        public string PasswordType { get; set; }

        public string Email { get; set; }

        public string DOB { get; set; }

        public string EmployeeId { get; set; }

        public string GhipCorporateId { get; set; }

        public string RGICorporateId { get; set; }

        public string IdentityServerId { get; set; }
    }
}