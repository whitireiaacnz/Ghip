﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RGI.GHIP.CoreAPIs.Data.Entities
{
    [Table("Communication", Schema = "GhipGlobal")]
    public class CommunicationEntity : EntityBase
    {
        [Key]
        public Guid IdPK { get; set; }

        [MaxLength(32)]
        public string Type { get; set; }

        [MaxLength(32)]
        public string To { get; set; }

        [MaxLength(32)]
        public string UserName { get; set; }

        public string? RefId { get; set; }

        public DateTime EmailSentAt { get; set; }

        public string EmailSentError { get; set; }

        public DateTime SMSSentAt { get; set; }

        public string SMSSentError { get; set; }
    }
}
