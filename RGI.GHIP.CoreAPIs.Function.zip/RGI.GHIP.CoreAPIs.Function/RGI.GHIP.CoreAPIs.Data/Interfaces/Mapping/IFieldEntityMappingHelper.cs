﻿using System.Collections.Generic;
using RGI.GHIP.CoreAPIs.Common.Models;
using RGI.GHIP.CoreAPIs.Data.Entities.PreEnrollment;

namespace RGI.GHIP.CoreAPIs.Data.Interfaces.Mapping
{
    public interface IFieldEntityMappingHelper
    {
        public PEFieldMasterEntity ModelToEntity(PEFieldMasterModel fieldMasterModel);

        public PEFieldMasterModel EntityToModel(PEFieldMasterEntity fieldMasterEntity);

        public List<PEFieldMasterEntity> ModelToEntityList(List<PEFieldMasterModel> fieldMasterModels);

        public List<PEFieldMasterModel> EntityToModelList(List<PEFieldMasterEntity> fieldMasterEntities);

        public PEPolicyFieldMappingEntity FieldMappingModelToEntity(PEFieldMasterModel fieldMasterModel);

        public PEFieldMasterModel FieldMappingEntityToModel(PEPolicyFieldMappingEntity policyFieldMappingEntity);

        public List<PEPolicyFieldMappingEntity> FieldMappingModelToEntityList(List<PEFieldMasterModel> fieldMasterModels);
    }
}
