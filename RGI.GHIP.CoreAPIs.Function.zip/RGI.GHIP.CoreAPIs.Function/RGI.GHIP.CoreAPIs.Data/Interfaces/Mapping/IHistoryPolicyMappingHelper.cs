using RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal;
using RGI.GHIP.CoreAPIs.Data.Entities.CorporatePortal;

namespace RGI.GHIP.CoreAPIs.Data.Interfaces.Mapping
{
    public interface IHistoryPolicyMappingHelper
    {
        public CPPolicyVersionEntity ModelToEntity(CPHistoryPolicyModel cpHistoryModel);
    }
}