using RGI.GHIP.CoreAPIs.Common.Models;
using RGI.GHIP.CoreAPIs.Data.Entities.PreEnrollment;

namespace RGI.GHIP.CoreAPIs.Data.Interfaces.Mapping
{
    public interface IExtraBenefitsEntityMappingHelper
    {
        public PEExtraBenefitsEntity ModelToEntity(PEExtraBenefitsModel extraBenefitsModel);
    }
}