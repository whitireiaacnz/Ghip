﻿using System.Collections.Generic;
using RGI.GHIP.CoreAPIs.Common.Models;
using RGI.GHIP.CoreAPIs.Data.Entities;

namespace RGI.GHIP.CoreAPIs.Data.Interfaces
{
    public interface ICorporateMappingHelpers
    {
        public List<CorporateModel> EntityToModelList(List<CorporateEntity> corporateEntities);

        public List<CorporateEntity> ModelToEntityList(List<CorporateModel> corporateModels);

        public CorporateEntity ModelToEntity(CorporateModel corporateModel);

        public CorporateModel EntityToModel(CorporateEntity corporateEntity);
    }
}
