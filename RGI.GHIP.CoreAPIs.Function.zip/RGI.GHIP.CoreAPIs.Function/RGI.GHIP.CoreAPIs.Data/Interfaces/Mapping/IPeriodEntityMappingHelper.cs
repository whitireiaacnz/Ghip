﻿using System.Collections.Generic;
using RGI.GHIP.CoreAPIs.Common.Models;
using RGI.GHIP.CoreAPIs.Data.Entities.PreEnrollment;

namespace RGI.GHIP.CoreAPIs.Data.Interfaces.Mapping
{
    public interface IPeriodEntityMappingHelper
    {
        public PEPeriodEntity ModelToEntity(PEPeriodModel preEnrollmentPeriodModel);

        public PEPeriodModel EntityToModel(PEPeriodEntity preEnrollmentPeriodEntity);

        public List<PEPeriodModel> EntityToModelList(List<PEPeriodEntity> preEnrollmentPeriodEntities);

        public List<PEPeriodEntity> ModelToEntityList(List<PEPeriodModel> preEnrollmentPeriodModels);
    }
}
