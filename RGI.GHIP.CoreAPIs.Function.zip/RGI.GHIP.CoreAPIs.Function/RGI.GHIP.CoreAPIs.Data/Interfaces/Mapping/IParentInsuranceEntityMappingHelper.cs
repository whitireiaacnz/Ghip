using System.Collections.Generic;
using RGI.GHIP.CoreAPIs.Common.Models;
using RGI.GHIP.CoreAPIs.Data.Entities.PreEnrollment;

namespace RGI.GHIP.CoreAPIs.Data.Interfaces.Mapping
{
    public interface IParentInsuranceEntityMappingHelper
    {
        public List<PEParentInsuranceEntity> ModelToEntity(List<PEPSIModel> preEnrollmentPolicyModel);

        public PEParentInsuranceModel EntityToModel(PEParentInsuranceEntity pEParentInsuranceEntity);

        public List<PEParentInsuranceHistoryEntity> ModelToEntityHistory(List<PEParentInsuranceHistoryPremiumModel> psiHistoryModels);

        public List<PEEnhanceSumInsuredHistoryEntity> ModelToEntityHistoryESI(List<PEEnhanceSumInsuredPremiumHistoryModel> esiHistoryModels);

        public List<PETopUpInsuranceHistoryEntity> ModelToEntityHistoryTopup(List<PETopUpInsurancePremiumHistoryModel> topUpHistoryModels);
    }
}
