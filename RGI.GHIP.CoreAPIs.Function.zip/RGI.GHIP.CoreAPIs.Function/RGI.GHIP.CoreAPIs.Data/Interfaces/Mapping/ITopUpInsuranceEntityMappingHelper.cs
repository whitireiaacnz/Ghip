using System.Collections.Generic;
using RGI.GHIP.CoreAPIs.Common.Models;
using RGI.GHIP.CoreAPIs.Data.Entities.PreEnrollment;

namespace RGI.GHIP.CoreAPIs.Data.Interfaces.Mapping
{
    public interface ITopUpInsuranceEntityMappingHelper
    {
        public List<PETopUpInsuranceEntity> ModelToEntity(List<PETopUpInsuranceListModel> preEnrollmentTopUpModel);
    }
}