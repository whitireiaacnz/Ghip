﻿using RGI.GHIP.CoreAPIs.Common.Models;
using RGI.GHIP.CoreAPIs.Data.Entities;

namespace RGI.GHIP.CoreAPIs.Data.Interfaces.Mapping
{
    public interface IRoleEntityMappingHelper
    {
        public RoleModel RoleEntitytoModel(RoleEntity roleEntity);

        public RoleEntity RoleModeltoEntity(RoleModel roleModel);
    }
}
