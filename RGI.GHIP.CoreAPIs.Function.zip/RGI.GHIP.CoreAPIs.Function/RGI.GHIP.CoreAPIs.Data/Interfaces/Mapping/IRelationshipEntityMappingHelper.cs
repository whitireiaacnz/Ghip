﻿using System.Collections.Generic;
using RGI.GHIP.CoreAPIs.Common.Models;
using RGI.GHIP.CoreAPIs.Data.Entities.PreEnrollment;

namespace RGI.GHIP.CoreAPIs.Data.Interfaces.Mapping
{
    public interface IRelationshipEntityMappingHelper
    {
        public PERelationshipMasterModel EntityToModel(PERelationshipMasterEntity relationshipMasterEntity);

        public PERelationshipMasterEntity ModelToEntity(PERelationshipMasterModel relationshipMasterEntity);

        public List<PERelationshipMasterModel> EntityToModelList(List<PERelationshipMasterEntity> relationshipMasterEntities);

        public List<PERelationshipMasterEntity> ModelToEntityList(List<PERelationshipMasterModel> relationshipMasterModels);

        public PERelationshipMasterModel RelationshipMappingEntityToModel(PEPolicyRelationshipMappingEntity policyRelationshipMappingEntity);

        public PEPolicyRelationshipMappingEntity RelationshipMappingModelToEntity(PERelationshipMasterModel relationshipMasterModel);

        public List<PERelationshipMasterModel> RelationshipMappingEntityToModelList(List<PEPolicyRelationshipMappingEntity> policyRelationshipMappingEntities);

        public List<PEPolicyRelationshipMappingEntity> RelationshipMappingModelToEntityList(List<PERelationshipMasterModel> relationshipMasterModels);
    }
}
