﻿using System.Collections.Generic;
using RGI.GHIP.CoreAPIs.Common.Models;
using RGI.GHIP.CoreAPIs.Common.Models.Member;
using RGI.GHIP.CoreAPIs.Data.Entities.PreEnrollment;

namespace RGI.GHIP.CoreAPIs.Data.Interfaces.Mapping
{
    public interface IMemberEntityMappingHelper
    {
        public PEMemberEntity ModelToEntity(PEMemberFieldsSummaryModel preEnrollmentMemberModel);

        public List<PEMemberEntity> ModelToEntityList(List<PEMemberFieldsSummaryModel> preEnrollmentMemberModels);

        public PEMemberFieldsSummaryModel EntityToModel(PEMemberEntity preEnrollmentMemberEntity);

        public List<PEMemberFieldsSummaryModel> EntityToModelList(List<PEMemberEntity> preEnrollmentMemberEntities);

        public PEMemberFieldsSummaryModel EntityToSummaryModel(PEMemberEntity preEnrollmentMemberEntity);

        public List<PEMemberFieldsSummaryModel> EntityToSummaryModelList(List<PEMemberEntity> preEnrollmentMemberEntities);

        public PEMemberModel EntityToMemberModel(PEMemberEntity preEnrollmentMemberEntity);

        public List<PEMemberModel> EntityToMemberModelList(List<PEMemberEntity> preEnrollmentMemberEntities);
    }
}
