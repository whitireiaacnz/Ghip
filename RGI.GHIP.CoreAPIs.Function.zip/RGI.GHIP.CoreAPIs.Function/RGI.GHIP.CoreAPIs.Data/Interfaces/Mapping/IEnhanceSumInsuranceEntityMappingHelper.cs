using System.Collections.Generic;
using RGI.GHIP.CoreAPIs.Common.Models;
using RGI.GHIP.CoreAPIs.Data.Entities.PreEnrollment;

namespace RGI.GHIP.CoreAPIs.Data.Interfaces.Mapping
{
    public interface IEnhanceSumInsuranceEntityMappingHelper
    {
        public List<PEEnhanceSumInsuredEntity> ModelToEntity(List<PEESIModel> preEnrollmentPolicyModel);
    }
}