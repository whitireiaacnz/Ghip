﻿using RGI.GHIP.CoreAPIs.Common.Models;
using RGI.GHIP.CoreAPIs.Data.Entities;

namespace RGI.GHIP.CoreAPIs.Data.Interfaces
{
    public interface IUserEntityMappingHelper
    {
        public UserModel MapUserEntityToModel(UserEntity userEntity);

        public UserEntity MapUserModelToEntity(UserModel userModel);
    }
}
