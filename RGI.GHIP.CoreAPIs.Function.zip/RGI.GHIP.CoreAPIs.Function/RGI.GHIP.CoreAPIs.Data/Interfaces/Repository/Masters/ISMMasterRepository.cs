﻿using RGI.GHIP.CoreAPIs.Common.Models.Master;
using RGI.GHIP.CoreAPIs.Data.Entities.Masters;

namespace RGI.GHIP.CoreAPIs.Data.Interfaces.Repository.Masters
{
    public interface ISMMasterRepository : IRepository<SMMasterEntity, SMMasterModel>
    {
    }
}
