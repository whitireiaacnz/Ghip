﻿using RGI.GHIP.CoreAPIs.Common.Models.Master;
using RGI.GHIP.CoreAPIs.Data.Entities.Masters.AddressMasters;

namespace RGI.GHIP.CoreAPIs.Data.Interfaces.Repository.Master
{
    public interface IRegionMasterRepository : IRepository<RegionMasterEntity, RegionMasterModel>
    {
    }
}
