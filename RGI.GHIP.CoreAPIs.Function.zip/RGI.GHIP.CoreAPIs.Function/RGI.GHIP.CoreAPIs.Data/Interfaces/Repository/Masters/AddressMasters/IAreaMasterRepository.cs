﻿using System.Collections.Generic;
using RGI.GHIP.CoreAPIs.Common.Models.Master;
using RGI.GHIP.CoreAPIs.Data.Entities.Masters.AddressMasters;

namespace RGI.GHIP.CoreAPIs.Data.Interfaces.Repository.Master
{
    public interface IAreaMasterRepository : IRepository<AreaMasterEntity, AreaMasterModel>
    {
        public List<AreaMasterModel> GetAllPincode(string pincode);
    }
}
