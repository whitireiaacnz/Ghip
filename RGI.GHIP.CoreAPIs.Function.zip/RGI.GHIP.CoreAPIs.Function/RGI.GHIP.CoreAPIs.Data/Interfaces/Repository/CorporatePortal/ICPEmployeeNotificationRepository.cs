﻿using RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal;
using RGI.GHIP.CoreAPIs.Data.Entities.CorporatePortal;

namespace RGI.GHIP.CoreAPIs.Data.Interfaces.Repository.CorporatePortal
{
    public interface ICPEmployeeNotificationRepository : IRepository<CPEmployeeNotificationMappingEntity, CPEmployeeNotificationMappingModel>
    {
    }
}
