using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal;
using RGI.GHIP.CoreAPIs.Data.Entities.CorporatePortal;

namespace RGI.GHIP.CoreAPIs.Data.Interfaces.Repository.CorporatePortal
{
    public interface ICPHRCommCodeMappingRepository : IRepository<CPHRCommCodeMappingEntity, CPHRCommCodeMappingModel>
    {
        public IActionResult DeleteBulkRecords(List<Guid> ids);
    }
}
