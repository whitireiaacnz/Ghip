﻿using System;
using System.Collections.Generic;
using RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal;
using RGI.GHIP.CoreAPIs.Data.Entities.CorporatePortal;

namespace RGI.GHIP.CoreAPIs.Data.Interfaces.Repository.CorporatePortal
{
    public interface ICPBrokerMappingRepository : IRepository<CPBrokerPolicyMappingEntity, CPBrokerPolicyMappingModel>
    {
        public List<CPBrokerMappingSummaryModel> GetBrokerSummary(Guid policyId);

        public CPBrokerMappingSummaryModel GetBrokerSummary(Guid policyId, Guid brokerId);

        public List<CPPolicyModel> GetBrokerPolicy(Guid brokerId);

        public List<CPPolicyModel> GetBrokerCorporatesAndPoliciesFeatures(Guid brokerId);

        public List<CPPolicyModel> GetBrokerCorporatesAndPolicies(Guid brokerId);

        public List<CPPolicyModel> GetBrokerPolicies(Guid brokerId, int corporateId);
    }
}
