﻿using RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal;
using RGI.GHIP.CoreAPIs.Data.Entities.CorporatePortal;

namespace RGI.GHIP.CoreAPIs.Data.Interfaces.Repository.CorporatePortal
{
    public interface ICPPolicyRepository : IRepository<CPPolicyEntity, CPPolicyModel>
    {
        public CPPolicyModel AttachCorporateToPolicy(CPPolicyModel cPPolicyModel);

        public CPPolicyModel AddCredentialFormatToPolicy(CPPolicyModel cPPolicyModel);
    }
}
