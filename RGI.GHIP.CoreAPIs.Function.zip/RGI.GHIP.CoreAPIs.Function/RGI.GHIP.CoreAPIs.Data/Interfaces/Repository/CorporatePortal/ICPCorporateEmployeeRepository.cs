﻿using System;
using System.Collections.Generic;
using RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal;
using RGI.GHIP.CoreAPIs.Data.Entities.CorporatePortal;

namespace RGI.GHIP.CoreAPIs.Data.Interfaces.Repository.CorporatePortal
{
    public interface ICPCorporateEmployeeRepository : IRepository<CPCorporateEmployeeEntity, CPCorporateEmployeeModel>
    {
        public List<CPPolicyModel> GetEmployeePolicies(Guid corEmpId);
    }
}
