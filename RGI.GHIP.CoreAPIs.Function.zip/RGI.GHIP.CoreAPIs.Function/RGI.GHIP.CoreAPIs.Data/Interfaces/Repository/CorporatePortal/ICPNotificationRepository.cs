﻿using System;
using System.Collections.Generic;
using RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal;
using RGI.GHIP.CoreAPIs.Data.Entities.CorporatePortal;

namespace RGI.GHIP.CoreAPIs.Data.Interfaces.Repository.CorporatePortal
{
    public interface ICPNotificationRepository : IRepository<CPNotificationEntity, CPNotificationModel>
    {
        public List<CPNotificationModel> GetUnseenMemberNotificationsId(
                                            int corporateId,
                                            Guid policyId,
                                            Guid employeeMappingId);

        public List<CPNotificationModel> GetUnseenMemberCommonNotificationsId(
                                                    int corporateId,
                                                    Guid employeeMappingId);

        public List<CPNotificationModel> GetUnseenMemberNotificationsId(int corporateId, string employeeId, Guid employeeMappingId);

        public List<CPNotificationModel> GetUnseenHRNotificationsId(int corporateId, Guid employeeMappingId);
    }
}
