﻿using System;
using System.Collections.Generic;
using RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal;
using RGI.GHIP.CoreAPIs.Data.Entities.CorporatePortal;

namespace RGI.GHIP.CoreAPIs.Data.Interfaces.Repository.CorporatePortal
{
    public interface ICPSMMappingRepository : IRepository<CPSMPolicyMappingEntity, CPSMpolicyMappingModel>
    {
        public List<CPSMMappingSummaryModel> GetSMSummary(Guid policyId);

        public List<CPPolicyModel> GetSMPolicies(Guid smId, int corporateId);

        public List<CPPolicyModel> GetSMPolicy(Guid smId);

        public List<CPPolicyModel> GetSMPolicies(Guid smId);

        public CPSMMappingSummaryModel GetSMSummary(Guid policyId, Guid smId);

        public List<CPPolicyModel> GetSMCorporatesAndPoliciesFeatures(Guid brokerId);
    }
}
