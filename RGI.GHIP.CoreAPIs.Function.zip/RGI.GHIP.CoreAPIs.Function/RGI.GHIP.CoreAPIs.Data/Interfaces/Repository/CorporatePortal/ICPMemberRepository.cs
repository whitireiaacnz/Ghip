﻿using System;
using System.Collections.Generic;
using RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal;
using RGI.GHIP.CoreAPIs.Common.Models.CorporatePortal.Biz_admin;
using RGI.GHIP.CoreAPIs.Data.Entities.CorporatePortal;

namespace RGI.GHIP.CoreAPIs.Data.Interfaces.Repository.CorporatePortal
{
    public interface ICPMemberRepository : IRepository<CPMembersEntity, CPMemberModel>
    {
        public List<CPMemberSummaryModel> GetMemberSummary(Guid policyId, int skip, int take);

        public List<CPUserMISReportModel> GetMemberUserMISReport(string policyNo);

        public List<CPMemberSummaryModel> SearchMemberSummary(
        Guid policyId,
        string value);

        public int GetMembersToSendCredCount(Guid policyId);

        public List<CPMemberModel> GetMembersToResetCred(Guid policyId, int skip, int take);

        public List<CPMemberModel> GetMembersToSendCred(Guid policyId, int skip, int take);

        public List<CPPolicyModel> GetAllCorporatePolicies(int corporateId);

        public List<CPPolicyModel> GetMemberPolicies(string employeeId, int corporateId);

        public DateTime GetMemberLastInsertedDate(string policyNo);
    }
}
