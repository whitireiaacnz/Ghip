﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using EFCore.BulkExtensions;
using Microsoft.AspNetCore.Mvc;

namespace RGI.GHIP.CoreAPIs.Data.Interfaces.Repository
{
    public interface IRepository<TEntity, TModel> : IDisposable
        where TEntity : class
    {
        public TreturnType GetMax<TreturnType>(Expression<Func<TEntity, TreturnType>> filter);

        public IEnumerable<TModel> GetList(
            Expression<Func<TEntity, bool>> filter = null,
            Func<IQueryable<TEntity>, IOrderedQueryable<TEntity>> orderBy = null,
            string includeProperties = "");

        public IEnumerable<TResultModel> GetList<TResultModel>(
                 Expression<Func<TEntity, bool>> filter = null,
                 string includeProperties = "",
                 Expression<Func<TEntity, TResultModel>> select = null);

        public TResultModel Get<TResultModel>(
             Expression<Func<TEntity, bool>> filter = null,
             string includeProperties = "",
             Expression<Func<TEntity, TResultModel>> select = null);

        public TModel GetWithoutDeletedFilter(
            Expression<Func<TEntity, bool>> filter = null,
            Func<IQueryable<TEntity>, IOrderedQueryable<TEntity>> orderBy = null,
            string includeProperties = "");

        public TModel Get(
              Expression<Func<TEntity, bool>> filter = null,
              Func<IQueryable<TEntity>, IOrderedQueryable<TEntity>> orderBy = null,
              string includeProperties = "");

        public Task<IActionResult> AddRangeAsync(
                  List<TModel> models,
                  BulkConfig bulkConfig = null,
                  GhipDBContext context = null);

        public TModel GetByID(object id);

        public List<TModel> GetList(int skip, int take, Expression<Func<TEntity, bool>> filter = null);

        public int GetCount(Expression<Func<TEntity, bool>> filter = null);

        public bool Exists(Expression<Func<TEntity, bool>> filter = null);

        public List<TModel> GetAll();

        public TModel Create(TModel model);

        public Task<IActionResult> UpdateRangeAsync(
                        List<TModel> models,
                        GhipDBContext context = null);

        public TModel Update(
                        TModel model,
                        int id,
                        params Expression<Func<TEntity, object>>[] updatedProperties);

        public TModel Update(
                        TModel model,
                        Guid id,
                        params Expression<Func<TEntity, object>>[] updatedProperties);

        public TModel Update(TModel model, int id);

        public TModel Update(TModel model);

        public IActionResult Delete(int id);

        public IActionResult Delete(Guid id);

        public Task<IActionResult> BulkUpdateAsync(
            List<TModel> models,
            BulkConfig bulkConfig = null,
            GhipDBContext context = null);

        public Task<IActionResult> BulkInsertOrUpdateAsync(List<TModel> models);

        public Task<IActionResult> BulkInsertAsync(
                                List<TModel> models,
                                BulkConfig bulkConfig = null,
                                GhipDBContext context = null);
    }
}
