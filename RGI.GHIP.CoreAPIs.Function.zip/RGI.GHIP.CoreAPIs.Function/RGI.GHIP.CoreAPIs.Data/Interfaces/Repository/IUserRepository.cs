﻿using Microsoft.AspNetCore.Mvc;
using RGI.GHIP.CoreAPIs.Common.Models;
using RGI.GHIP.CoreAPIs.Data.Entities;
using RGI.GHIP.CoreAPIs.Data.Interfaces.Repository;

namespace RGI.GHIP.CoreAPIs.Data.Repository
{
    public interface IUserRepository : IRepository<UserEntity, UserModel>
    {
        public UserModel GetUserByIdentityServerId(string identityServerId);

        public RoleModel GetUserRole(int roleId);

        public UserModel GetUserById(int id);

        public IActionResult UpdateUserLogin(string userId);

        public RoleModel CreateUserRole(RoleModel roleType);

        public UserModel CreateUser(UserModel user);

        public void DeleteUser(int id);
    }
}