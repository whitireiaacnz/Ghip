﻿using System;
using System.Collections.Generic;
using RGI.GHIP.CoreAPIs.Common.Models.RGI;

namespace RGI.GHIP.CoreAPIs.Data.Interfaces.Repository.RGI
{
    public interface IRGICPMemberRepository
    {
        public List<RGICPMemberModel> GetRGIMember(int skip, int take, DateTime insertedAT);

        public List<RGICPMemberModel> GetRGIMembers(DateTime insertedAt, string policyNo);

        public int GetRGIMemberCount(DateTime insertedAt, string policyNo);

        public int GetRGIMemberCount(DateTime insertedAT);

        public int GetRGIMemberCount(string policyNo);
    }
}
