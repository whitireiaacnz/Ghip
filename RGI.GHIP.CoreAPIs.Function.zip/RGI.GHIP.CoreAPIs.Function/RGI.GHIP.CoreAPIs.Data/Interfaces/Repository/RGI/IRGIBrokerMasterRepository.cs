﻿using System.Collections.Generic;
using RGI.GHIP.CoreAPIs.Common.Models.RGI;

namespace RGI.GHIP.CoreAPIs.Data.Interfaces.Repository.RGI
{
    public interface IRGIBrokerMasterRepository
    {
        public List<RGIBrokerMasterModel> GetRGIBroker();
    }
}
