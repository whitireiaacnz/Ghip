using RGI.GHIP.CoreAPIs.Common.Models.RGI;
using RGI.GHIP.CoreAPIs.Data.Entities;

namespace RGI.GHIP.CoreAPIs.Data.Interfaces.Repository.RGI
{
    public interface IUserMigrationRepository : IRepository<UserMigrationEntity, UserMigrationModel>
    {
    }
}