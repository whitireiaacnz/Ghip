﻿using System.Collections.Generic;
using RGI.GHIP.CoreAPIs.Common.Models;
using RGI.GHIP.CoreAPIs.Data.Entities;
using RGI.GHIP.CoreAPIs.Data.Interfaces.Repository;

namespace RGI.GHIP.CoreAPIs.Data.Repository.Interface
{
    public interface ICorporateRepository : IRepository<CorporateEntity, CorporateModel>
    {
        public List<CorporateModel> GetCorporates();

        public List<CorporateModel> GetCorporates(int skip, int take);

        public CorporateModel GetCorporate(string corporateName);

        public CorporateModel UpdateCorporate(CorporateModel corporateData);

        public CorporateModel CreateCorporate(CorporateModel corporateData);
    }
}
