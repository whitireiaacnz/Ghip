using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using RGI.GHIP.CoreAPIs.Common.Models;
using RGI.GHIP.CoreAPIs.Data.Entities.PreEnrollment;

namespace RGI.GHIP.CoreAPIs.Data.Interfaces.Repository.PreEnrollment
{
    public interface IPETopUpInsuranceHistoryRepository : IRepository<PETopUpInsuranceHistoryEntity, PETopUpInsurancePremiumHistoryModel>
    {
        public IActionResult CreateTopupPremiumsHistoryVersion(List<PETopUpInsurancePremiumHistoryModel> topupHistoryModels);
    }
}