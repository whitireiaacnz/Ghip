using RGI.GHIP.CoreAPIs.Common.Models;
using RGI.GHIP.CoreAPIs.Data.Entities.PreEnrollment;
using RGI.GHIP.CoreAPIs.Data.Interfaces.Repository;

namespace RGI.GHIP.CoreAPIs.Data.Repository.Interface
{
    public interface IPEExtraBenefitsRepository : IRepository<PEExtraBenefitsEntity, PEExtraBenefitsModel>
    {
        public PEExtraBenefitsModel CreateExtraBenefits(PEExtraBenefitsModel extraBenefits);

        public PEExtraBenefitsModel GetExtraBenefits(int policyId, string relationship, string benefitType);

        public void RemoveItem(int id);

        public PEExtraBenefitsModel UpdateExtraBenefits(PEExtraBenefitsModel extraBenefits);
    }
}