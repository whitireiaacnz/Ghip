﻿using System.Collections.Generic;
using RGI.GHIP.CoreAPIs.Common.Models;

namespace RGI.GHIP.CoreAPIs.Data.Repository
{
    public interface IPEPolicyRelationshipMappingRepository
    {
        public PERelationshipMasterModel CreateRelationshipMapping(PERelationshipMasterModel relationshipMasterModel);

        public PERelationshipMasterModel GetRelationshipMapping(int relationshipMappingId);

        public List<PERelationshipMasterModel> GetRelationshipMappings(int policyId);

        public PERelationshipMasterModel GetRelationshipMapping(int policyId, int relationshipId);

        public PERelationshipMasterModel UpdateRelationshipMapping(PERelationshipMasterModel relationshipMasterModel);

        public PERelationshipMasterModel DeleteRelationshipMapping(PERelationshipMasterModel relationshipMasterModel);
    }
}