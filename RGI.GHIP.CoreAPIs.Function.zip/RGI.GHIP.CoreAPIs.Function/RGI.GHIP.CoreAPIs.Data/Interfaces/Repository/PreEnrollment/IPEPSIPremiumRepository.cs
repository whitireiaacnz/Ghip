using System.Collections.Generic;
using RGI.GHIP.CoreAPIs.Data.Entities.PreEnrollment;
using RGI.GHIP.CoreAPIs.Data.Interfaces.Repository;

namespace RGI.GHIP.CoreAPIs.Data.Repository.Interface
{
    public interface IPEPSIPremiumRepository : IRepository<PEParentInsurancePremiumEntity, PEParentInsurancePremiumModel>
    {
        public List<PEParentInsurancePremiumModel> CreatePSIPremiums(List<PEParentInsurancePremiumModel> psiPremiums);

        public List<PEParentInsurancePremiumModel> GetPsiPremiumsById(int extraBenefitsId);
    }
}