using System.Collections.Generic;
using RGI.GHIP.CoreAPIs.Common.Models;

namespace RGI.GHIP.CoreAPIs.Data.Interfaces.Repository
{
    public interface IPEPSIESITopupTransferRepository
    {
        public List<PEMigratePSIModel> ParenTInsuranceData();

        public List<PEMigrateESIModel> EnhanceSumInsuranceData();

        public List<PEMigrateTopUpModel> TopupSumInsuranceData();
    }
}