using System.Collections.Generic;
using RGI.GHIP.CoreAPIs.Common.Models;
using RGI.GHIP.CoreAPIs.Data.Entities.PreEnrollment;
using RGI.GHIP.CoreAPIs.Data.Interfaces.Repository;

namespace RGI.GHIP.CoreAPIs.Data.Repository.Interface
{
    public interface IPESelfInsuranceRepository : IRepository<PESelfInsuranceEntity, PESelfModel>
    {
        public void RemoveItem(int id);

        public List<PESelfModel> CreateSelfInsurancePremium(List<PESelfModel> selfPremiumModels);

        public List<PESelfModel> GetPreEnrollmentSelfInsurance(int benefitId);
    }
}