using System.Collections.Generic;
using RGI.GHIP.CoreAPIs.Common.Models;
using RGI.GHIP.CoreAPIs.Data.Entities.PreEnrollment;
using RGI.GHIP.CoreAPIs.Data.Interfaces.Repository;

namespace RGI.GHIP.CoreAPIs.Data.Repository.Interface
{
    public interface IPEParentInsuranceRepository : IRepository<PEParentInsuranceEntity, PEPSIModel>
    {
        public void RemoveItem(int id);

        public List<PEPSIModel> CreateParentInsurancePremium(List<PEPSIModel> psiPremiumModels);

        public List<PEPSIModel> GetPreEnrollmentParentInsurance(int benefitId);
    }
}