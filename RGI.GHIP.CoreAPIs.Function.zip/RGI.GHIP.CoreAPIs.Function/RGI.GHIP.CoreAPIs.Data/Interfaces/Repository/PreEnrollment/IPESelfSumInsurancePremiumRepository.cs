using System.Collections.Generic;
using RGI.GHIP.CoreAPIs.Data.Entities.PreEnrollment;
using RGI.GHIP.CoreAPIs.Data.Interfaces.Repository;

namespace RGI.GHIP.CoreAPIs.Data.Repository.Interface
{
    public interface IPESelfSumInsurancePremiumRepository : IRepository<PESelfSumInsurancePremiumEntity, PESelfSumInsurancePremiumModel>
    {
        public List<PESelfSumInsurancePremiumModel> CreateSelfSIPremiums(List<PESelfSumInsurancePremiumModel> psiPremiums);

        public List<PESelfSumInsurancePremiumModel> GetSelfSIPremiumsById(int extraBenefitsId);
    }
}