﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using RGI.GHIP.CoreAPIs.Common.Models;
using RGI.GHIP.CoreAPIs.Common.Models.Member;
using RGI.GHIP.CoreAPIs.Data.Entities.PreEnrollment;
using RGI.GHIP.CoreAPIs.Data.Interfaces.Repository;

namespace RGI.GHIP.CoreAPIs.Data.Repository.Interface
{
    public interface IPEPolicyRepository : IRepository<PEPolicyEntity, PEPolicyModel>
    {
        public List<PEPolicyModel> GetPreEnrollmentPolicies(int corporateId);

        public List<PEPolicyModel> GetPreEnrollmentPolicies(string corporateCode);

        public PEPolicyModel GetPreEnrollmentPolicyWithMappings(int policyId);

        public PEPolicyModel GetMemberPolicy(string empId, string corporateCode);

        public PEPolicyModel UpdatePreEnrollmentPolicy(int policyId, PEPolicyModel preEnrollmentPolicyModel);

        public PEPolicyModel CreatePreEnrollmentPolicy(PEPolicyModel preEnrollmentPolicyModel);

        public bool DeletePreEnrollmentPolicy(int policyId);

        public IActionResult DeletePreEnrollmentPolicyMembers(int policyId);

        public List<PEMemberModel> GetMembersByPolicy(int policyId);

        public List<PEMemberModel> GetMembersByCorporate(int corporateId);

        public List<PEPolicyModel> GetPoliciesWithSimilarDateTime(PEWelcomeEmailModel pEPolicyEmailTemplate, int policyId);

        public List<PEWelcomeEmailDateTimeModel> GetWelcomeEmailAllocatedTime();
    }
}