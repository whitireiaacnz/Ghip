﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using RGI.GHIP.CoreAPIs.Common.Models;
using RGI.GHIP.CoreAPIs.Common.Models.Member;
using RGI.GHIP.CoreAPIs.Data.Entities.PreEnrollment;
using RGI.GHIP.CoreAPIs.Data.Interfaces.Repository;

namespace RGI.GHIP.CoreAPIs.Data.Repository
{
    public interface IPEMemberRepository : IRepository<PEMemberEntity, PEMemberModel>
    {
        public PEMemberModel GetMember(string empId, string corporateCode);

        public PEMemberModel GetMember(string empId, int relationshipId, int policyId);

        public List<PEMemberFieldsSummaryModel> GetSummaryModel(
                Expression<Func<PEMemberEntity, bool>> filter = null,
                Func<IQueryable<PEMemberEntity>, IOrderedQueryable<PEMemberEntity>> orderBy = null,
                string includeProperties = "");

        public PEMemberModel GetMemberDependent(int memberId, string empId);

        public PEMemberModel GetSelfObject(string empId, string corporateCode);

        public List<PEMemberModel> GetDependentsWithPolicyAndRelationship(string empId, int policyId);

        public List<PEPolicyModel> GetMemberPolicies(string empId, string corporateCode);

        public List<PEMemberFieldsSummaryModel> GetSelfMembersWithDependent(int policyId);

        public List<PEMemberFieldsSummaryModel> GetSelfMembers(int policyId, int skip = -1, int take = -1);

        public PEMemberModel CreateMember(PEMemberModel preEnrollmentMemberModelData);

        public PEMemberModel UpdateMemberData(PEMemberModel member);

        public Task<List<IActionResult>> UpdateOrCreateMemberMultipleAsync(
                        List<PEMemberModel> selfMemberToUpdate,
                        List<PEMemberModel> selfMemberToInsert,
                        List<PEMemberModel> dependentMemberToUpdate,
                        List<PEMemberModel> dependentMemberToInsert);

        public bool DeleteMembers(int memberId);

        public List<PEMemberModel> GetMembersByPolicy(int policyId);

        public List<PEMemberModel> GetMembersByCorporate(int corporateId);

        public List<PERelationshipCountModel> GetRelationshipwithCount(int policyId, string empId);
    }
}