﻿using RGI.GHIP.CoreAPIs.Common.Models;
using RGI.GHIP.CoreAPIs.Data.Entities.PreEnrollment;

namespace RGI.GHIP.CoreAPIs.Data.Interfaces.Repository
{
    public interface IPEFieldMasterRepository : IRepository<PEFieldMasterEntity, PEFieldMasterModel>
    {
        public PEFieldMasterModel CreateField(PEFieldMasterModel fieldMaster);
    }
}
