using RGI.GHIP.CoreAPIs.Common.Models;
using RGI.GHIP.CoreAPIs.Data.Interfaces.Repository;

namespace RGI.GHIP.CoreAPIs.Data.Repository.Interface
{
    public interface IPEExtraBenefitsHistoryRepository : IRepository<PEExtraBenefitsHistoryEntity, PEExtraBenefitsHistoryModel>
    {
    }
}