using System.Collections.Generic;
using RGI.GHIP.CoreAPIs.Common.Models;
using RGI.GHIP.CoreAPIs.Data.Entities.PreEnrollment;
using RGI.GHIP.CoreAPIs.Data.Interfaces.Repository;

namespace RGI.GHIP.CoreAPIs.Data.Repository.Interface
{
    public interface IPETopUpInsuranceRepository : IRepository<PETopUpInsuranceEntity, PETopUpInsuranceListModel>
    {
        public void RemoveItem(int id);

        public List<PETopUpInsuranceListModel> CreateTopUpInsurancePremium(List<PETopUpInsuranceListModel> topUpModels);

        public List<PETopUpInsuranceListModel> GetPreEnrollmentTopUpInsurance(int benefitId);
    }
}
