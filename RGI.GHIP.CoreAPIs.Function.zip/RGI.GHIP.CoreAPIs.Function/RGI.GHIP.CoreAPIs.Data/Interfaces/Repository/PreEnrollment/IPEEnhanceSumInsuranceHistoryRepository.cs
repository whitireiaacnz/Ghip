using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using RGI.GHIP.CoreAPIs.Common.Models;
using RGI.GHIP.CoreAPIs.Data.Entities.PreEnrollment;

namespace RGI.GHIP.CoreAPIs.Data.Interfaces.Repository.PreEnrollment
{
    public interface IPEEnhanceSumInsuranceHistoryRepository : IRepository<PEEnhanceSumInsuredHistoryEntity, PEEnhanceSumInsuredPremiumHistoryModel>
    {
        public IActionResult CreateESIPremiumsHistoryVersion(List<PEEnhanceSumInsuredPremiumHistoryModel> esiHistoryModels);
    }
}