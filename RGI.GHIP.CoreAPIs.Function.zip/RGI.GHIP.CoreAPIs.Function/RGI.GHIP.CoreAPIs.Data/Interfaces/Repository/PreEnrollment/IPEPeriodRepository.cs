﻿using RGI.GHIP.CoreAPIs.Common.Models;
using RGI.GHIP.CoreAPIs.Data.Entities.PreEnrollment;
using RGI.GHIP.CoreAPIs.Data.Interfaces.Repository;

namespace RGI.GHIP.CoreAPIs.Data.Repository
{
    public interface IPEPeriodRepository : IRepository<PEPeriodEntity, PEPeriodModel>
    {
        public PEPeriodModel CreatePeriod(PEPeriodModel preEnrollmentPeriod);

        public PEPeriodModel GetPeriod(int periodId);

        public PEPeriodModel UpdatePeriod(PEPeriodModel preEnrollmentPeriodModel);

        public bool DeletePeriod(int periodId);
    }
}