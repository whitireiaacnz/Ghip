﻿using System.Collections.Generic;
using RGI.GHIP.CoreAPIs.Common.Models;

namespace RGI.GHIP.CoreAPIs.Data.Interfaces.Repository
{
    public interface IPEPolicyFieldMappingRepository
    {
        public PEFieldMasterModel CreateFieldMapping(PEFieldMasterModel fieldMasterModel);

        public List<PEFieldMasterModel> GetFieldMappingForPolicy(int policyId);

        public PEFieldMasterModel UpdateFieldMapping(PEFieldMasterModel fieldMasterModel);

        public PEFieldMasterModel DeleteFieldMapping(PEFieldMasterModel policyFieldMapping);
    }
}
