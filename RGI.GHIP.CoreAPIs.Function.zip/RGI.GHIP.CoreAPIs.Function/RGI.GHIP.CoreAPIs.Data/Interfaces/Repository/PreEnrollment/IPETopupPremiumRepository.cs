using System.Collections.Generic;
using RGI.GHIP.CoreAPIs.Data.Entities.PreEnrollment;
using RGI.GHIP.CoreAPIs.Data.Interfaces.Repository;

public interface IPETopupPremiumRepository : IRepository<PETopupPremiumEntity, PETopupPremiumModel>
{
    public List<PETopupPremiumModel> CreateTopupPremiums(List<PETopupPremiumModel> topupPremiums);

    public List<PETopupPremiumModel> GetTopupPremiumsById(int extraBenefitsId);
}