﻿using System.Collections.Generic;
using RGI.GHIP.CoreAPIs.Common.Models;
using RGI.GHIP.CoreAPIs.Data.Entities.PreEnrollment;

namespace RGI.GHIP.CoreAPIs.Data.Interfaces.Repository
{
    public interface IPERelationshipMasterRepository : IRepository<PERelationshipMasterEntity, PERelationshipMasterModel>
    {
        public PERelationshipMasterModel CreateRelationship(PERelationshipMasterModel relationshipMaster);

        public List<PERelationshipMasterModel> GetRelationships();

        public PERelationshipMasterModel GetRelationship(int relationshipMasterId);

        public int GetRelationshipMasterId(string relationshipLabel);
    }
}
