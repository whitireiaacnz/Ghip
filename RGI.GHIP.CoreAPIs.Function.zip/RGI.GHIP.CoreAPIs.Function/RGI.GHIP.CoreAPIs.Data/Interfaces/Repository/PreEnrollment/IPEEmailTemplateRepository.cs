﻿using RGI.GHIP.CoreAPIs.Common.Models;

namespace RGI.GHIP.CoreAPIs.Data.Interfaces.Repository
{
    public interface IPEEmailTemplateRepository
    {
        public PEEmailTemplateModel Get();

        public PEEmailTemplateModel Create(PEEmailTemplateModel emailTemplateModel);
    }
}
