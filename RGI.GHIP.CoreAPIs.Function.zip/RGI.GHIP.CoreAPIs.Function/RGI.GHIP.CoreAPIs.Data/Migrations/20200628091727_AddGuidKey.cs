﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace RGI.GHIP.CoreAPIs.Data.Migrations
{
    public partial class AddGuidKey : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipPE",
                table: "RelationshipMasters",
                nullable: false,
                defaultValueSql: "newId()");

            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipPE",
                table: "PreEnrollmentPolicies",
                nullable: false,
                defaultValueSql: "newId()");

            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipPE",
                table: "PreEnrollmentPeriods",
                nullable: false,
                defaultValueSql: "newId()");

            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipPE",
                table: "PreEnrollmentMembers",
                nullable: false,
                defaultValueSql: "newId()");

            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipPE",
                table: "PolicyRelationshipMappings",
                nullable: false,
                defaultValueSql: "newId()");

            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipPE",
                table: "PolicyFieldMappings",
                nullable: false,
                defaultValueSql: "newId()");

            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipPE",
                table: "FieldMasters",
                nullable: false,
                defaultValueSql: "newId()");

            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipPE",
                table: "EmailTemplates",
                nullable: false,
                defaultValueSql: "newId()");

            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipGlobal",
                table: "Users",
                nullable: false,
                defaultValueSql: "newId()");

            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipGlobal",
                table: "StateMaster",
                nullable: false,
                defaultValueSql: "newId()");

            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipGlobal",
                table: "SMMaster",
                nullable: false,
                defaultValueSql: "newId()");

            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipGlobal",
                table: "Roles",
                nullable: false,
                defaultValueSql: "newId()");

            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipGlobal",
                table: "RegionMaster",
                nullable: false,
                defaultValueSql: "newId()");

            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipGlobal",
                table: "DistrictMaster",
                nullable: false,
                defaultValueSql: "newId()");

            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipGlobal",
                table: "Corporates",
                nullable: false,
                defaultValueSql: "newId()");

            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipGlobal",
                table: "CityOrVillageMaster",
                nullable: false,
                defaultValueSql: "newId()");

            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipGlobal",
                table: "BrokerMaster",
                nullable: false,
                defaultValueSql: "newId()");

            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipGlobal",
                table: "AreaMaster",
                nullable: false,
                defaultValueSql: "newId()");

            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipCP",
                table: "SMPolicyMapping",
                nullable: false,
                defaultValueSql: "newId()");

            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipCP",
                table: "PolicyAttached",
                nullable: false,
                defaultValueSql: "newId()");

            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipCP",
                table: "Policy",
                nullable: false,
                defaultValueSql: "newId()");

            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipCP",
                table: "HRMapping",
                nullable: false,
                defaultValueSql: "newId()");

            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipCP",
                table: "Employee",
                nullable: false,
                defaultValueSql: "newId()");

            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipCP",
                table: "BrokerPolicyMapping",
                nullable: false,
                defaultValueSql: "newId()");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipPE",
                table: "RelationshipMasters");

            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipPE",
                table: "PreEnrollmentPolicies");

            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipPE",
                table: "PreEnrollmentPeriods");

            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipPE",
                table: "PreEnrollmentMembers");

            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipPE",
                table: "PolicyRelationshipMappings");

            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipPE",
                table: "PolicyFieldMappings");

            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipPE",
                table: "FieldMasters");

            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipPE",
                table: "EmailTemplates");

            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipGlobal",
                table: "Users");

            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipGlobal",
                table: "StateMaster");

            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipGlobal",
                table: "SMMaster");

            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipGlobal",
                table: "Roles");

            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipGlobal",
                table: "RegionMaster");

            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipGlobal",
                table: "DistrictMaster");

            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipGlobal",
                table: "Corporates");

            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipGlobal",
                table: "CityOrVillageMaster");

            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipGlobal",
                table: "BrokerMaster");

            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipGlobal",
                table: "AreaMaster");

            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipCP",
                table: "SMPolicyMapping");

            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipCP",
                table: "PolicyAttached");

            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipCP",
                table: "HRMapping");

            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipCP",
                table: "Employee");

            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipCP",
                table: "BrokerPolicyMapping");
        }
    }
}
