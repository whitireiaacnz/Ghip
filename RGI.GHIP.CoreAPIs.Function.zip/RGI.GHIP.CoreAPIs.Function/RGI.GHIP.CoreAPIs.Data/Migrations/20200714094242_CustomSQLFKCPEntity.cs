﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RGI.GHIP.CoreAPIs.Data.Migrations
{
    public partial class CustomSQLFKCPEntity : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // update Fk for broker mapping and brokermaster
            migrationBuilder.Sql("update GhipCP.BrokerPolicyMapping set GBrokerId = GhipGlobal.BrokerMaster.GId from GhipCP.BrokerPolicyMapping inner join GhipGlobal.BrokerMaster on GhipCP.BrokerPolicyMapping.BrokerId = GhipGlobal.BrokerMaster.Id");

            // update FK for broker mapping and policy
            migrationBuilder.Sql("update GhipCP.BrokerPolicyMapping set GCPPolicyId = GhipCP.Policy.GId from GhipCP.BrokerPolicyMapping inner join GhipCP.Policy on GhipCP.BrokerPolicyMapping.CPPolicyId = GhipCP.Policy.Id");

            // update FK for sm mapping and policy
            migrationBuilder.Sql("update GhipCP.SMPolicyMapping set GCPPolicyId = GhipCP.Policy.GId from GhipCP.SMPolicyMapping inner join GhipCP.Policy on GhipCP.SMPolicyMapping.CPPolicyId = GhipCP.Policy.Id");

            // update policy member feature FK
            migrationBuilder.Sql("update GhipCP.PolicyMemberFeatures set GCPPolicyId = GhipCP.Policy.GId from GhipCP.PolicyMemberFeatures inner join GhipCP.Policy on GhipCP.PolicyMemberFeatures.PolicyId = GhipCP.Policy.Id");

            // update member policy FK
            migrationBuilder.Sql("update GhipCP.Members set GCPPolicyId = GhipCP.Policy.GId from GhipCP.Members inner join GhipCP.Policy on GhipCP.Members.CPPolicyId = GhipCP.Policy.Id");

            // update documents FK policy
            migrationBuilder.Sql("update GhipCP.Documents set GCPPolicyId = GhipCP.Policy.GId from GhipCP.Documents inner join GhipCP.Policy on GhipCP.Documents.PolicyId = GhipCP.Policy.Id");

            // update member hr FK
            migrationBuilder.Sql("update GhipCP.HRMapping set MemberGId = GhipCP.Members.GId from GhipCP.HRMapping inner join GhipCP.Members on GhipCP.HRMapping.MemberId = GhipCP.Members.Id");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
        }
    }
}
