﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RGI.GHIP.CoreAPIs.Data.Migrations
{
    public partial class KeyDefaultValue : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipPE",
                table: "RelationshipMasters",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldDefaultValue: "9794386d-6ef8-4760-9b07-34e4d66154e8");

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipPE",
                table: "PreEnrollmentPolicies",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldDefaultValue: "d7f1f38d-e24c-4939-b1f5-f303215064ed");

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipPE",
                table: "PreEnrollmentPeriods",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldDefaultValue: "5b804ca5-7da4-4313-9869-fd425d512700");

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipPE",
                table: "PreEnrollmentMembers",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldDefaultValue: "723b93ab-2d1f-4ff1-818e-e1d851eb6d0b");

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipPE",
                table: "PolicyRelationshipMappings",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldDefaultValue: "42acfae1-da45-4183-812b-655646c81f2d");

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipPE",
                table: "PolicyFieldMappings",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldDefaultValue: "a74b9484-95cb-4b78-8888-03b3c0102e77");

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipPE",
                table: "FieldMasters",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldDefaultValue: "e4507ed4-4067-4f5b-b412-50eb5d4d1132");

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipPE",
                table: "EmailTemplates",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldDefaultValue: "2d11207e-ff2c-40e9-99bf-c3050445d066");

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipGlobal",
                table: "Users",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldDefaultValue: "0d7e7505-89b6-4785-92e2-c0d5fa5ba7bb");

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipGlobal",
                table: "StateMaster",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldDefaultValue: "92198122-2165-408e-b90b-36f40e3567ef");

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipGlobal",
                table: "SMMaster",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldDefaultValue: "da6c3848-0ec7-43d1-bee2-a221eee0c409");

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipGlobal",
                table: "Roles",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldDefaultValue: "e426a820-a50e-44ec-be02-9cdb7d4fbac2");

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipGlobal",
                table: "RegionMaster",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldDefaultValue: "3363faf7-1d79-4c4f-b33c-1dd0f12915f9");

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipGlobal",
                table: "DistrictMaster",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldDefaultValue: "42785083-f648-4fa0-a4fa-fb3ee807bd08");

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipGlobal",
                table: "Corporates",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldDefaultValue: "5cb69ad9-c488-4858-af00-22be0ef9af16");

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipGlobal",
                table: "CityOrVillageMaster",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldDefaultValue: "a34e2a37-bea7-4120-ae7c-763a98627a3e");

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipGlobal",
                table: "BrokerMaster",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldDefaultValue: "6e965dde-7580-4d8c-87e4-6f00d2aa512a");

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipGlobal",
                table: "AreaMaster",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldDefaultValue: "bb5de34d-5722-435b-8f32-b25471d3f6f9");

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipCP",
                table: "SMPolicyMapping",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldDefaultValue: "48f936b6-b8bb-4d73-b6e8-191d49de3952");

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipCP",
                table: "PolicyAttached",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldDefaultValue: "850048eb-de18-4a31-bd83-69dc2e0fb385");

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipCP",
                table: "Policy",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldDefaultValue: "d6dfe69b-e130-4f2c-b235-1632b53fe4e3");

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipCP",
                table: "HRMapping",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldDefaultValue: "a03e6e07-fab4-4ecf-98ff-00e9142d2132");

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipCP",
                table: "Employee",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldDefaultValue: "0461dae8-4d5f-4f95-9bf9-22d7fcbe7aed");

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipCP",
                table: "BrokerPolicyMapping",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldDefaultValue: "aa2267d3-2025-4bd0-ba14-1fd9b3710990");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipPE",
                table: "RelationshipMasters",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "newsequentialid()",
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipPE",
                table: "PreEnrollmentPolicies",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "newsequentialid()",
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipPE",
                table: "PreEnrollmentPeriods",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "newsequentialid()",
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipPE",
                table: "PreEnrollmentMembers",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "newsequentialid()",
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipPE",
                table: "PolicyRelationshipMappings",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "newsequentialid()",
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipPE",
                table: "PolicyFieldMappings",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "newsequentialid()",
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipPE",
                table: "FieldMasters",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "newsequentialid()",
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipPE",
                table: "EmailTemplates",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "newsequentialid()",
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipGlobal",
                table: "Users",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "newsequentialid()",
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipGlobal",
                table: "StateMaster",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "newsequentialid()",
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipGlobal",
                table: "SMMaster",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "newsequentialid()",
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipGlobal",
                table: "Roles",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "newsequentialid()",
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipGlobal",
                table: "RegionMaster",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "newsequentialid()",
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipGlobal",
                table: "DistrictMaster",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "newsequentialid()",
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipGlobal",
                table: "Corporates",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "newsequentialid()",
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipGlobal",
                table: "CityOrVillageMaster",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "newsequentialid()",
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipGlobal",
                table: "BrokerMaster",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "newsequentialid()",
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipGlobal",
                table: "AreaMaster",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "newsequentialid()",
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipCP",
                table: "SMPolicyMapping",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "newsequentialid()",
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipCP",
                table: "PolicyAttached",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "newsequentialid()",
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipCP",
                table: "Policy",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "newsequentialid()",
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipCP",
                table: "HRMapping",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "newsequentialid()",
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipCP",
                table: "Employee",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "newsequentialid()",
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipCP",
                table: "BrokerPolicyMapping",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "newsequentialid()",
                oldClrType: typeof(string),
                oldNullable: true);
        }
    }
}
