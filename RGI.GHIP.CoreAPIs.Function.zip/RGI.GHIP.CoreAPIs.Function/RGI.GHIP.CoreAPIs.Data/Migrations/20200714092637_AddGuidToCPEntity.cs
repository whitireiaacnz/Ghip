﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace RGI.GHIP.CoreAPIs.Data.Migrations
{
    public partial class AddGuidToCPEntity : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "RGIId",
                schema: "GhipGlobal",
                table: "SMMaster",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<Guid>(
                name: "GId",
                schema: "GhipGlobal",
                table: "BrokerMaster",
                nullable: false,
                type: "uniqueidentifier",
                defaultValue: "DF_MimeType_Id",
                defaultValueSql: "NEWSEQUENTIALID()");

            migrationBuilder.AddColumn<Guid>(
                name: "GCPPolicyId",
                schema: "GhipCP",
                table: "SMPolicyMapping",
                nullable: false,
                type: "uniqueidentifier",
                defaultValue: "DF_MimeType_Id",
                defaultValueSql: "NEWSEQUENTIALID()");

            migrationBuilder.AddColumn<Guid>(
                name: "GCPPolicyId",
                schema: "GhipCP",
                table: "PolicyMemberFeatures",
                nullable: false,
                type: "uniqueidentifier",
                defaultValue: "DF_MimeType_Id",
                defaultValueSql: "NEWSEQUENTIALID()");

            migrationBuilder.AddColumn<Guid>(
                name: "GId",
                schema: "GhipCP",
                table: "PolicyMemberFeatures",
                nullable: false,
                type: "uniqueidentifier",
                defaultValue: "DF_MimeType_Id",
                defaultValueSql: "NEWSEQUENTIALID()");

            migrationBuilder.AddColumn<Guid>(
                name: "GId",
                schema: "GhipCP",
                table: "Policy",
                nullable: false,
                type: "uniqueidentifier",
                defaultValue: "DF_MimeType_Id",
                defaultValueSql: "NEWSEQUENTIALID()");

            migrationBuilder.AddColumn<Guid>(
                name: "GCPPolicyId",
                schema: "GhipCP",
                table: "Members",
                nullable: false,
                type: "uniqueidentifier",
                defaultValue: "DF_MimeType_Id",
                defaultValueSql: "NEWSEQUENTIALID()");

            migrationBuilder.AddColumn<Guid>(
                name: "GId",
                schema: "GhipCP",
                table: "Members",
                nullable: false,
                type: "uniqueidentifier",
                defaultValue: "DF_MimeType_Id",
                defaultValueSql: "NEWSEQUENTIALID()");

            migrationBuilder.AddColumn<Guid>(
                name: "GId",
                schema: "GhipCP",
                table: "HRMapping",
                nullable: false,
                type: "uniqueidentifier",
                defaultValue: "DF_MimeType_Id",
                defaultValueSql: "NEWSEQUENTIALID()");

            migrationBuilder.AddColumn<Guid>(
                name: "MemberGId",
                schema: "GhipCP",
                table: "HRMapping",
                nullable: false,
                type: "uniqueidentifier",
                defaultValue: "DF_MimeType_Id",
                defaultValueSql: "NEWSEQUENTIALID()");

            migrationBuilder.AddColumn<Guid>(
                name: "GCPPolicyId",
                schema: "GhipCP",
                table: "Documents",
                nullable: false,
                type: "uniqueidentifier",
                defaultValue: "DF_MimeType_Id",
                defaultValueSql: "NEWSEQUENTIALID()");

            migrationBuilder.AddColumn<Guid>(
                name: "GBrokerId",
                schema: "GhipCP",
                table: "BrokerPolicyMapping",
                nullable: false,
                type: "uniqueidentifier",
                defaultValue: "DF_MimeType_Id",
                defaultValueSql: "NEWSEQUENTIALID()");

            migrationBuilder.AddColumn<Guid>(
                name: "GCPPolicyId",
                schema: "GhipCP",
                table: "BrokerPolicyMapping",
                nullable: false,
                type: "uniqueidentifier",
                defaultValue: "DF_MimeType_Id",
                defaultValueSql: "NEWSEQUENTIALID()");

            migrationBuilder.AddColumn<Guid>(
                name: "GId",
                schema: "GhipCP",
                table: "BrokerPolicyMapping",
                nullable: false,
                type: "uniqueidentifier",
                defaultValue: "DF_MimeType_Id",
                defaultValueSql: "NEWSEQUENTIALID()");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "RGIId",
                schema: "GhipGlobal",
                table: "SMMaster");

            migrationBuilder.DropColumn(
                name: "GId",
                schema: "GhipGlobal",
                table: "BrokerMaster");

            migrationBuilder.DropColumn(
                name: "GCPPolicyId",
                schema: "GhipCP",
                table: "SMPolicyMapping");

            migrationBuilder.DropColumn(
                name: "GCPPolicyId",
                schema: "GhipCP",
                table: "PolicyMemberFeatures");

            migrationBuilder.DropColumn(
                name: "GId",
                schema: "GhipCP",
                table: "PolicyMemberFeatures");

            migrationBuilder.DropColumn(
                name: "GId",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropColumn(
                name: "GCPPolicyId",
                schema: "GhipCP",
                table: "Members");

            migrationBuilder.DropColumn(
                name: "GId",
                schema: "GhipCP",
                table: "Members");

            migrationBuilder.DropColumn(
                name: "GId",
                schema: "GhipCP",
                table: "HRMapping");

            migrationBuilder.DropColumn(
                name: "MemberGId",
                schema: "GhipCP",
                table: "HRMapping");

            migrationBuilder.DropColumn(
                name: "GCPPolicyId",
                schema: "GhipCP",
                table: "Documents");

            migrationBuilder.DropColumn(
                name: "GBrokerId",
                schema: "GhipCP",
                table: "BrokerPolicyMapping");

            migrationBuilder.DropColumn(
                name: "GCPPolicyId",
                schema: "GhipCP",
                table: "BrokerPolicyMapping");

            migrationBuilder.DropColumn(
                name: "GId",
                schema: "GhipCP",
                table: "BrokerPolicyMapping");
        }
    }
}
