﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace RGI.GHIP.CoreAPIs.Data.Migrations
{
    public partial class RemoveKey : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipPE",
                table: "RelationshipMasters");

            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipPE",
                table: "PreEnrollmentPolicies");

            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipPE",
                table: "PreEnrollmentPeriods");

            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipPE",
                table: "PreEnrollmentMembers");

            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipPE",
                table: "PolicyRelationshipMappings");

            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipPE",
                table: "PolicyFieldMappings");

            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipPE",
                table: "FieldMasters");

            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipPE",
                table: "EmailTemplates");

            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipGlobal",
                table: "Users");

            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipGlobal",
                table: "StateMaster");

            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipGlobal",
                table: "SMMaster");

            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipGlobal",
                table: "Roles");

            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipGlobal",
                table: "RegionMaster");

            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipGlobal",
                table: "DistrictMaster");

            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipGlobal",
                table: "Corporates");

            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipGlobal",
                table: "CityOrVillageMaster");

            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipGlobal",
                table: "BrokerMaster");

            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipGlobal",
                table: "AreaMaster");

            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipCP",
                table: "SMPolicyMapping");

            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipCP",
                table: "PolicyAttached");

            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipCP",
                table: "HRMapping");

            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipCP",
                table: "Employee");

            migrationBuilder.DropColumn(
                name: "Key",
                schema: "GhipCP",
                table: "BrokerPolicyMapping");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipPE",
                table: "RelationshipMasters",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipPE",
                table: "PreEnrollmentPolicies",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipPE",
                table: "PreEnrollmentPeriods",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipPE",
                table: "PreEnrollmentMembers",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipPE",
                table: "PolicyRelationshipMappings",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipPE",
                table: "PolicyFieldMappings",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipPE",
                table: "FieldMasters",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipPE",
                table: "EmailTemplates",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipGlobal",
                table: "Users",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipGlobal",
                table: "StateMaster",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipGlobal",
                table: "SMMaster",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipGlobal",
                table: "Roles",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipGlobal",
                table: "RegionMaster",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipGlobal",
                table: "DistrictMaster",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipGlobal",
                table: "Corporates",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipGlobal",
                table: "CityOrVillageMaster",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipGlobal",
                table: "BrokerMaster",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipGlobal",
                table: "AreaMaster",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipCP",
                table: "SMPolicyMapping",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipCP",
                table: "PolicyAttached",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipCP",
                table: "Policy",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipCP",
                table: "HRMapping",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipCP",
                table: "Employee",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AddColumn<Guid>(
                name: "Key",
                schema: "GhipCP",
                table: "BrokerPolicyMapping",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));
        }
    }
}
