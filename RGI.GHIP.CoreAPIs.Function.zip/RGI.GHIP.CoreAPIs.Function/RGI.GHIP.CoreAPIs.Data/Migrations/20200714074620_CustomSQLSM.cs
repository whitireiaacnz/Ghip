﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RGI.GHIP.CoreAPIs.Data.Migrations
{
    public partial class CustomSQLSM : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("update GhipCP.SMPolicyMapping set SMGId = GhipGlobal.SMMaster.GId from GhipCP.SMPolicyMapping inner join GhipGlobal.SMMaster on GhipCP.SMPolicyMapping.SMId = GhipGlobal.SMMaster.Id");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
        }
    }
}
