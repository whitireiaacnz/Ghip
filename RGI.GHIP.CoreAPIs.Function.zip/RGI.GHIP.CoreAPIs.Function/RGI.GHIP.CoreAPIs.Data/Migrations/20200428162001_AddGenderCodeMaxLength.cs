﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RGI.GHIP.CoreAPIs.Data.Migrations
{
    public partial class AddGenderCodeMaxLength : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Gender",
                schema: "GHIP",
                table: "RelationshipMasters",
                nullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Code",
                schema: "GHIP",
                table: "Corporates",
                maxLength: 10,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(8)",
                oldMaxLength: 8);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Gender",
                schema: "GHIP",
                table: "RelationshipMasters");

            migrationBuilder.AlterColumn<string>(
                name: "Code",
                schema: "GHIP",
                table: "Corporates",
                type: "nvarchar(8)",
                maxLength: 8,
                nullable: false,
                oldClrType: typeof(string),
                oldMaxLength: 10);
        }
    }
}
