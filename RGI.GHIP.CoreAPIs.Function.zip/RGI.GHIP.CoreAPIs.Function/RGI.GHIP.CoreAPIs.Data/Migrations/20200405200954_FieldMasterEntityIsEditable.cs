﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RGI.GHIP.CoreAPIs.Data.Migrations
{
    public partial class FieldMasterEntityIsEditable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "IsEditableForDependent",
                schema: "GHIP",
                table: "PolicyFieldMappings",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "IsEditableForSelf",
                schema: "GHIP",
                table: "PolicyFieldMappings",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "IsEditableForDependent",
                schema: "GHIP",
                table: "FieldMasters",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "IsEditableForSelf",
                schema: "GHIP",
                table: "FieldMasters",
                nullable: false,
                defaultValue: false);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsEditableForDependent",
                schema: "GHIP",
                table: "PolicyFieldMappings");

            migrationBuilder.DropColumn(
                name: "IsEditableForSelf",
                schema: "GHIP",
                table: "PolicyFieldMappings");

            migrationBuilder.DropColumn(
                name: "IsEditableForDependent",
                schema: "GHIP",
                table: "FieldMasters");

            migrationBuilder.DropColumn(
                name: "IsEditableForSelf",
                schema: "GHIP",
                table: "FieldMasters");
        }
    }
}
