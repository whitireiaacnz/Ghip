﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace RGI.GHIP.CoreAPIs.Data.Migrations
{
    public partial class AddedMemberFeatureEntity : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "AdditionOfDependents",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropColumn(
                name: "ConntactUs",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropColumn(
                name: "DownloadForms",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropColumn(
                name: "FAQ",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropColumn(
                name: "HRA",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropColumn(
                name: "HealthOPedia",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropColumn(
                name: "IntimateClaims",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropColumn(
                name: "NetworkHospitalTracker",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropColumn(
                name: "RHealthAssist",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropColumn(
                name: "RHealthBeat",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropColumn(
                name: "RHealthCircle",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropColumn(
                name: "TrackClaims",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropColumn(
                name: "ValueDeals",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropColumn(
                name: "ViewECard",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropColumn(
                name: "ViewPolicyCoverage",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropColumn(
                name: "Wellness",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.CreateTable(
                name: "PolicyMemberFeatures",
                schema: "GhipCP",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Key = table.Column<Guid>(nullable: false),
                    CreatedAt = table.Column<DateTime>(nullable: false),
                    CreatedBy = table.Column<string>(nullable: true),
                    ModifiedAt = table.Column<DateTime>(nullable: false),
                    ModifiedBy = table.Column<string>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false),
                    CorporateId = table.Column<int>(nullable: true),
                    PolicyNumber = table.Column<string>(nullable: true),
                    PolicyId = table.Column<int>(nullable: false),
                    ViewPolicyCoverage = table.Column<bool>(nullable: true),
                    AdditionOfDependents = table.Column<bool>(nullable: true),
                    TrackClaims = table.Column<bool>(nullable: true),
                    ViewECard = table.Column<bool>(nullable: true),
                    NetworkHospitalTracker = table.Column<bool>(nullable: true),
                    DownloadForms = table.Column<bool>(nullable: true),
                    IntimateClaims = table.Column<bool>(nullable: true),
                    ContactUs = table.Column<bool>(nullable: true),
                    FAQ = table.Column<bool>(nullable: true),
                    Wellness = table.Column<bool>(nullable: true),
                    RHealthAssist = table.Column<bool>(nullable: true),
                    RHealthCircle = table.Column<bool>(nullable: true),
                    RHealthBeat = table.Column<bool>(nullable: true),
                    HealthOPedia = table.Column<bool>(nullable: true),
                    HRA = table.Column<bool>(nullable: true),
                    ValueDeals = table.Column<bool>(nullable: true),
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PolicyMemberFeatures", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PolicyMemberFeatures_Corporates_CorporateId",
                        column: x => x.CorporateId,
                        principalSchema: "GhipGlobal",
                        principalTable: "Corporates",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_PolicyMemberFeatures_Policy_PolicyId",
                        column: x => x.PolicyId,
                        principalSchema: "GhipCP",
                        principalTable: "Policy",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_PolicyMemberFeatures_CorporateId",
                schema: "GhipCP",
                table: "PolicyMemberFeatures",
                column: "CorporateId");

            migrationBuilder.CreateIndex(
                name: "IX_PolicyMemberFeatures_PolicyId",
                schema: "GhipCP",
                table: "PolicyMemberFeatures",
                column: "PolicyId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "PolicyMemberFeatures",
                schema: "GhipCP");

            migrationBuilder.AddColumn<bool>(
                name: "AdditionOfDependents",
                schema: "GhipCP",
                table: "Policy",
                type: "bit",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "ConntactUs",
                schema: "GhipCP",
                table: "Policy",
                type: "bit",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "DownloadForms",
                schema: "GhipCP",
                table: "Policy",
                type: "bit",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "FAQ",
                schema: "GhipCP",
                table: "Policy",
                type: "bit",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "HRA",
                schema: "GhipCP",
                table: "Policy",
                type: "bit",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "HealthOPedia",
                schema: "GhipCP",
                table: "Policy",
                type: "bit",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "IntimateClaims",
                schema: "GhipCP",
                table: "Policy",
                type: "bit",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "NetworkHospitalTracker",
                schema: "GhipCP",
                table: "Policy",
                type: "bit",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "RHealthAssist",
                schema: "GhipCP",
                table: "Policy",
                type: "bit",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "RHealthBeat",
                schema: "GhipCP",
                table: "Policy",
                type: "bit",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "RHealthCircle",
                schema: "GhipCP",
                table: "Policy",
                type: "bit",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "TrackClaims",
                schema: "GhipCP",
                table: "Policy",
                type: "bit",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "ValueDeals",
                schema: "GhipCP",
                table: "Policy",
                type: "bit",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "ViewECard",
                schema: "GhipCP",
                table: "Policy",
                type: "bit",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "ViewPolicyCoverage",
                schema: "GhipCP",
                table: "Policy",
                type: "bit",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "Wellness",
                schema: "GhipCP",
                table: "Policy",
                type: "bit",
                nullable: true);
        }
    }
}
