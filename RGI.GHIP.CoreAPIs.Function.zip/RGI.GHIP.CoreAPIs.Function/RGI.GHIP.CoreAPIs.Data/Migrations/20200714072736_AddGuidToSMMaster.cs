﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace RGI.GHIP.CoreAPIs.Data.Migrations
{
    public partial class AddGuidToSMMaster : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<Guid>(
                name: "GId",
                schema: "GhipGlobal",
                table: "SMMaster",
                nullable: false,
                type: "uniqueidentifier",
                defaultValue: "DF_MimeType_Id",
                defaultValueSql: "NEWSEQUENTIALID()");

            migrationBuilder.AddColumn<Guid>(
                name: "GId",
                schema: "GhipCP",
                table: "SMPolicyMapping",
                nullable: false,
                type: "uniqueidentifier",
                defaultValue: "DF_MimeType_Id",
                defaultValueSql: "NEWSEQUENTIALID()");

            migrationBuilder.AddColumn<Guid>(
                name: "SMGId",
                schema: "GhipCP",
                table: "SMPolicyMapping",
                nullable: false,
                type: "uniqueidentifier",
                defaultValue: "DF_MimeType_Id",
                defaultValueSql: "NEWSEQUENTIALID()");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "GId",
                schema: "GhipGlobal",
                table: "SMMaster");

            migrationBuilder.DropColumn(
                name: "GId",
                schema: "GhipCP",
                table: "SMPolicyMapping");

            migrationBuilder.DropColumn(
                name: "SMGId",
                schema: "GhipCP",
                table: "SMPolicyMapping");
        }
    }
}
