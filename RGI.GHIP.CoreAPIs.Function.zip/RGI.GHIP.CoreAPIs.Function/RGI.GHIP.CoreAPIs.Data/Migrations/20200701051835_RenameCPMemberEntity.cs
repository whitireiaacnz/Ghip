﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace RGI.GHIP.CoreAPIs.Data.Migrations
{
    public partial class RenameCPMemberEntity : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Employee",
                schema: "GhipCP");

            migrationBuilder.CreateTable(
                name: "Members",
                schema: "GhipCP",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Key = table.Column<string>(nullable: false),
                    CreatedAt = table.Column<DateTime>(nullable: false),
                    CreatedBy = table.Column<string>(nullable: true),
                    ModifiedAt = table.Column<DateTime>(nullable: false),
                    ModifiedBy = table.Column<string>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false),
                    CPPolicyAttachedId = table.Column<int>(nullable: false),
                    Name = table.Column<string>(nullable: true),
                    Email = table.Column<string>(nullable: true),
                    MobileNo = table.Column<string>(nullable: true),
                    LoginEmailSentAt = table.Column<DateTime>(nullable: false),
                    LoginSMSSentAt = table.Column<DateTime>(nullable: false),
                    CPPolicyId = table.Column<int>(nullable: true),
                    CPHRMappingEntityId = table.Column<int>(nullable: true),
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Members", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Members_HRMapping_CPHRMappingEntityId",
                        column: x => x.CPHRMappingEntityId,
                        principalSchema: "GhipCP",
                        principalTable: "HRMapping",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Members_Policy_CPPolicyId",
                        column: x => x.CPPolicyId,
                        principalSchema: "GhipCP",
                        principalTable: "Policy",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Members_CPHRMappingEntityId",
                schema: "GhipCP",
                table: "Members",
                column: "CPHRMappingEntityId");

            migrationBuilder.CreateIndex(
                name: "IX_Members_CPPolicyId",
                schema: "GhipCP",
                table: "Members",
                column: "CPPolicyId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Members",
                schema: "GhipCP");

            migrationBuilder.CreateTable(
                name: "Employee",
                schema: "GhipCP",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CPHRMappingEntityId = table.Column<int>(type: "int", nullable: true),
                    CPPolicyAttachedId = table.Column<int>(type: "int", nullable: false),
                    CPPolicyId = table.Column<int>(type: "int", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    Key = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    LoginEmailSentAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    LoginSMSSentAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    MobileNo = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ModifiedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ModifiedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Employee", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Employee_HRMapping_CPHRMappingEntityId",
                        column: x => x.CPHRMappingEntityId,
                        principalSchema: "GhipCP",
                        principalTable: "HRMapping",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Employee_Policy_CPPolicyId",
                        column: x => x.CPPolicyId,
                        principalSchema: "GhipCP",
                        principalTable: "Policy",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Employee_CPHRMappingEntityId",
                schema: "GhipCP",
                table: "Employee",
                column: "CPHRMappingEntityId");

            migrationBuilder.CreateIndex(
                name: "IX_Employee_CPPolicyId",
                schema: "GhipCP",
                table: "Employee",
                column: "CPPolicyId");
        }
    }
}
