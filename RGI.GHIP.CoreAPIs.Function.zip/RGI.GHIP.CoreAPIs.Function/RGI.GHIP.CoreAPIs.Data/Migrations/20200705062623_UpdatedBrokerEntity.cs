﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RGI.GHIP.CoreAPIs.Data.Migrations
{
    public partial class UpdatedBrokerEntity : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Code",
                schema: "GhipGlobal",
                table: "BrokerMaster",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_BrokerPolicyMapping_BrokerId",
                schema: "GhipCP",
                table: "BrokerPolicyMapping",
                column: "BrokerId");

            migrationBuilder.AddForeignKey(
                name: "FK_BrokerPolicyMapping_BrokerMaster_BrokerId",
                schema: "GhipCP",
                table: "BrokerPolicyMapping",
                column: "BrokerId",
                principalSchema: "GhipGlobal",
                principalTable: "BrokerMaster",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_BrokerPolicyMapping_BrokerMaster_BrokerId",
                schema: "GhipCP",
                table: "BrokerPolicyMapping");

            migrationBuilder.DropIndex(
                name: "IX_BrokerPolicyMapping_BrokerId",
                schema: "GhipCP",
                table: "BrokerPolicyMapping");

            migrationBuilder.DropColumn(
                name: "Code",
                schema: "GhipGlobal",
                table: "BrokerMaster");
        }
    }
}
