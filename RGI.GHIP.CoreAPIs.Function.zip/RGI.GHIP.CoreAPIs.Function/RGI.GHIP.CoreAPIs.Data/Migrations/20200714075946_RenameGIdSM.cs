﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RGI.GHIP.CoreAPIs.Data.Migrations
{
    public partial class RenameGIdSM : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                                name: "GId",
                                table: "SMPolicyMapping",
                                newName: "Id",
                                schema: "GhipCP");

            migrationBuilder.RenameColumn(
                                name: "SMGId",
                                table: "SMPolicyMapping",
                                newName: "SMId",
                                schema: "GhipCP");

            migrationBuilder.RenameColumn(
                                name: "GId",
                                table: "SMMaster",
                                newName: "Id",
                                schema: "GhipGlobal");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                                name: "Id",
                                table: "SMPolicyMapping",
                                newName: "GId",
                                schema: "GhipCP");

            migrationBuilder.RenameColumn(
                                name: "SMId",
                                table: "SMPolicyMapping",
                                newName: "SMGId",
                                schema: "GhipCP");

            migrationBuilder.RenameColumn(
                                name: "Id",
                                table: "SMMaster",
                                newName: "GId",
                                schema: "GhipGlobal");
        }
    }
}
