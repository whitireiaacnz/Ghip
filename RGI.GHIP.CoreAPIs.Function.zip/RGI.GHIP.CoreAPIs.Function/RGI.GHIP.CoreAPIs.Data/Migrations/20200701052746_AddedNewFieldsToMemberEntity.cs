﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace RGI.GHIP.CoreAPIs.Data.Migrations
{
    public partial class AddedNewFieldsToMemberEntity : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Name",
                schema: "GhipCP",
                table: "Members");

            migrationBuilder.AddColumn<string>(
                name: "Address1",
                schema: "GhipCP",
                table: "Members",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Address2",
                schema: "GhipCP",
                table: "Members",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "City",
                schema: "GhipCP",
                table: "Members",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Comm_code",
                schema: "GhipCP",
                table: "Members",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "DOB",
                schema: "GhipCP",
                table: "Members",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "DOJ",
                schema: "GhipCP",
                table: "Members",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<string>(
                name: "District",
                schema: "GhipCP",
                table: "Members",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "EmployeeId",
                schema: "GhipCP",
                table: "Members",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "EnrollmentType",
                schema: "GhipCP",
                table: "Members",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "InsuredName",
                schema: "GhipCP",
                table: "Members",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Pincode",
                schema: "GhipCP",
                table: "Members",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "PolicyNo",
                schema: "GhipCP",
                table: "Members",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Relationship",
                schema: "GhipCP",
                table: "Members",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Sex",
                schema: "GhipCP",
                table: "Members",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "State",
                schema: "GhipCP",
                table: "Members",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Taluka",
                schema: "GhipCP",
                table: "Members",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "UHID",
                schema: "GhipCP",
                table: "Members",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "WebReferenceNo",
                schema: "GhipCP",
                table: "Members",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Address1",
                schema: "GhipCP",
                table: "Members");

            migrationBuilder.DropColumn(
                name: "Address2",
                schema: "GhipCP",
                table: "Members");

            migrationBuilder.DropColumn(
                name: "City",
                schema: "GhipCP",
                table: "Members");

            migrationBuilder.DropColumn(
                name: "Comm_code",
                schema: "GhipCP",
                table: "Members");

            migrationBuilder.DropColumn(
                name: "DOB",
                schema: "GhipCP",
                table: "Members");

            migrationBuilder.DropColumn(
                name: "DOJ",
                schema: "GhipCP",
                table: "Members");

            migrationBuilder.DropColumn(
                name: "District",
                schema: "GhipCP",
                table: "Members");

            migrationBuilder.DropColumn(
                name: "EmployeeId",
                schema: "GhipCP",
                table: "Members");

            migrationBuilder.DropColumn(
                name: "EnrollmentType",
                schema: "GhipCP",
                table: "Members");

            migrationBuilder.DropColumn(
                name: "InsuredName",
                schema: "GhipCP",
                table: "Members");

            migrationBuilder.DropColumn(
                name: "Pincode",
                schema: "GhipCP",
                table: "Members");

            migrationBuilder.DropColumn(
                name: "PolicyNo",
                schema: "GhipCP",
                table: "Members");

            migrationBuilder.DropColumn(
                name: "Relationship",
                schema: "GhipCP",
                table: "Members");

            migrationBuilder.DropColumn(
                name: "Sex",
                schema: "GhipCP",
                table: "Members");

            migrationBuilder.DropColumn(
                name: "State",
                schema: "GhipCP",
                table: "Members");

            migrationBuilder.DropColumn(
                name: "Taluka",
                schema: "GhipCP",
                table: "Members");

            migrationBuilder.DropColumn(
                name: "UHID",
                schema: "GhipCP",
                table: "Members");

            migrationBuilder.DropColumn(
                name: "WebReferenceNo",
                schema: "GhipCP",
                table: "Members");

            migrationBuilder.AddColumn<string>(
                name: "Name",
                schema: "GhipCP",
                table: "Members",
                type: "nvarchar(max)",
                nullable: true);
        }
    }
}
