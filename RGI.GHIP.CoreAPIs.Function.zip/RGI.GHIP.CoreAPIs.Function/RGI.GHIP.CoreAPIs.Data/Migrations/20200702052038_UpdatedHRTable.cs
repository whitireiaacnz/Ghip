﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RGI.GHIP.CoreAPIs.Data.Migrations
{
    public partial class UpdatedHRTable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_HRMapping_Members_MemberId",
                schema: "GhipCP",
                table: "HRMapping");

            migrationBuilder.AlterColumn<int>(
                name: "MemberId",
                schema: "GhipCP",
                table: "HRMapping",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddColumn<string>(
                name: "Email",
                schema: "GhipCP",
                table: "HRMapping",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "MobileNo",
                schema: "GhipCP",
                table: "HRMapping",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Name",
                schema: "GhipCP",
                table: "HRMapping",
                nullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_HRMapping_Members_MemberId",
                schema: "GhipCP",
                table: "HRMapping",
                column: "MemberId",
                principalSchema: "GhipCP",
                principalTable: "Members",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_HRMapping_Members_MemberId",
                schema: "GhipCP",
                table: "HRMapping");

            migrationBuilder.DropColumn(
                name: "Email",
                schema: "GhipCP",
                table: "HRMapping");

            migrationBuilder.DropColumn(
                name: "MobileNo",
                schema: "GhipCP",
                table: "HRMapping");

            migrationBuilder.DropColumn(
                name: "Name",
                schema: "GhipCP",
                table: "HRMapping");

            migrationBuilder.AlterColumn<int>(
                name: "MemberId",
                schema: "GhipCP",
                table: "HRMapping",
                type: "int",
                nullable: false,
                oldClrType: typeof(int),
                oldNullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_HRMapping_Members_MemberId",
                schema: "GhipCP",
                table: "HRMapping",
                column: "MemberId",
                principalSchema: "GhipCP",
                principalTable: "Members",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
