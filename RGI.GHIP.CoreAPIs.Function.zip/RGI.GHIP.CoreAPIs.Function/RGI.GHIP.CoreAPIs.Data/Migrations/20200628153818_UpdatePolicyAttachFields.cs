﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RGI.GHIP.CoreAPIs.Data.Migrations
{
    public partial class UpdatePolicyAttachFields : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_PolicyAttached_Corporates_CorporateId",
                schema: "GhipCP",
                table: "PolicyAttached");

            migrationBuilder.AlterColumn<bool>(
                name: "Wellness",
                schema: "GhipCP",
                table: "PolicyAttached",
                nullable: true,
                oldClrType: typeof(bool),
                oldType: "bit");

            migrationBuilder.AlterColumn<bool>(
                name: "ViewPolicyCoverage",
                schema: "GhipCP",
                table: "PolicyAttached",
                nullable: true,
                oldClrType: typeof(bool),
                oldType: "bit");

            migrationBuilder.AlterColumn<bool>(
                name: "ViewECard",
                schema: "GhipCP",
                table: "PolicyAttached",
                nullable: true,
                oldClrType: typeof(bool),
                oldType: "bit");

            migrationBuilder.AlterColumn<bool>(
                name: "ValueDeals",
                schema: "GhipCP",
                table: "PolicyAttached",
                nullable: true,
                oldClrType: typeof(bool),
                oldType: "bit");

            migrationBuilder.AlterColumn<bool>(
                name: "TrackClaims",
                schema: "GhipCP",
                table: "PolicyAttached",
                nullable: true,
                oldClrType: typeof(bool),
                oldType: "bit");

            migrationBuilder.AlterColumn<bool>(
                name: "RHealthCircle",
                schema: "GhipCP",
                table: "PolicyAttached",
                nullable: true,
                oldClrType: typeof(bool),
                oldType: "bit");

            migrationBuilder.AlterColumn<bool>(
                name: "RHealthBeat",
                schema: "GhipCP",
                table: "PolicyAttached",
                nullable: true,
                oldClrType: typeof(bool),
                oldType: "bit");

            migrationBuilder.AlterColumn<bool>(
                name: "RHealthAssist",
                schema: "GhipCP",
                table: "PolicyAttached",
                nullable: true,
                oldClrType: typeof(bool),
                oldType: "bit");

            migrationBuilder.AlterColumn<bool>(
                name: "NetworkHospitalTracker",
                schema: "GhipCP",
                table: "PolicyAttached",
                nullable: true,
                oldClrType: typeof(bool),
                oldType: "bit");

            migrationBuilder.AlterColumn<bool>(
                name: "IntimateClaims",
                schema: "GhipCP",
                table: "PolicyAttached",
                nullable: true,
                oldClrType: typeof(bool),
                oldType: "bit");

            migrationBuilder.AlterColumn<bool>(
                name: "HealthOPedia",
                schema: "GhipCP",
                table: "PolicyAttached",
                nullable: true,
                oldClrType: typeof(bool),
                oldType: "bit");

            migrationBuilder.AlterColumn<bool>(
                name: "HRA",
                schema: "GhipCP",
                table: "PolicyAttached",
                nullable: true,
                oldClrType: typeof(bool),
                oldType: "bit");

            migrationBuilder.AlterColumn<int>(
                name: "GracePeriodValue",
                schema: "GhipCP",
                table: "PolicyAttached",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AlterColumn<bool>(
                name: "FAQ",
                schema: "GhipCP",
                table: "PolicyAttached",
                nullable: true,
                oldClrType: typeof(bool),
                oldType: "bit");

            migrationBuilder.AlterColumn<bool>(
                name: "DownloadForms",
                schema: "GhipCP",
                table: "PolicyAttached",
                nullable: true,
                oldClrType: typeof(bool),
                oldType: "bit");

            migrationBuilder.AlterColumn<int>(
                name: "CorporateId",
                schema: "GhipCP",
                table: "PolicyAttached",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AlterColumn<bool>(
                name: "ConntactUs",
                schema: "GhipCP",
                table: "PolicyAttached",
                nullable: true,
                oldClrType: typeof(bool),
                oldType: "bit");

            migrationBuilder.AlterColumn<bool>(
                name: "AdditionOfDependents",
                schema: "GhipCP",
                table: "PolicyAttached",
                nullable: true,
                oldClrType: typeof(bool),
                oldType: "bit");

            migrationBuilder.AddColumn<string>(
                name: "InsuredName",
                schema: "GhipCP",
                table: "PolicyAttached",
                nullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_PolicyAttached_Corporates_CorporateId",
                schema: "GhipCP",
                table: "PolicyAttached",
                column: "CorporateId",
                principalSchema: "GhipGlobal",
                principalTable: "Corporates",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_PolicyAttached_Corporates_CorporateId",
                schema: "GhipCP",
                table: "PolicyAttached");

            migrationBuilder.DropColumn(
                name: "InsuredName",
                schema: "GhipCP",
                table: "PolicyAttached");

            migrationBuilder.AlterColumn<bool>(
                name: "Wellness",
                schema: "GhipCP",
                table: "PolicyAttached",
                type: "bit",
                nullable: false,
                oldClrType: typeof(bool),
                oldNullable: true);

            migrationBuilder.AlterColumn<bool>(
                name: "ViewPolicyCoverage",
                schema: "GhipCP",
                table: "PolicyAttached",
                type: "bit",
                nullable: false,
                oldClrType: typeof(bool),
                oldNullable: true);

            migrationBuilder.AlterColumn<bool>(
                name: "ViewECard",
                schema: "GhipCP",
                table: "PolicyAttached",
                type: "bit",
                nullable: false,
                oldClrType: typeof(bool),
                oldNullable: true);

            migrationBuilder.AlterColumn<bool>(
                name: "ValueDeals",
                schema: "GhipCP",
                table: "PolicyAttached",
                type: "bit",
                nullable: false,
                oldClrType: typeof(bool),
                oldNullable: true);

            migrationBuilder.AlterColumn<bool>(
                name: "TrackClaims",
                schema: "GhipCP",
                table: "PolicyAttached",
                type: "bit",
                nullable: false,
                oldClrType: typeof(bool),
                oldNullable: true);

            migrationBuilder.AlterColumn<bool>(
                name: "RHealthCircle",
                schema: "GhipCP",
                table: "PolicyAttached",
                type: "bit",
                nullable: false,
                oldClrType: typeof(bool),
                oldNullable: true);

            migrationBuilder.AlterColumn<bool>(
                name: "RHealthBeat",
                schema: "GhipCP",
                table: "PolicyAttached",
                type: "bit",
                nullable: false,
                oldClrType: typeof(bool),
                oldNullable: true);

            migrationBuilder.AlterColumn<bool>(
                name: "RHealthAssist",
                schema: "GhipCP",
                table: "PolicyAttached",
                type: "bit",
                nullable: false,
                oldClrType: typeof(bool),
                oldNullable: true);

            migrationBuilder.AlterColumn<bool>(
                name: "NetworkHospitalTracker",
                schema: "GhipCP",
                table: "PolicyAttached",
                type: "bit",
                nullable: false,
                oldClrType: typeof(bool),
                oldNullable: true);

            migrationBuilder.AlterColumn<bool>(
                name: "IntimateClaims",
                schema: "GhipCP",
                table: "PolicyAttached",
                type: "bit",
                nullable: false,
                oldClrType: typeof(bool),
                oldNullable: true);

            migrationBuilder.AlterColumn<bool>(
                name: "HealthOPedia",
                schema: "GhipCP",
                table: "PolicyAttached",
                type: "bit",
                nullable: false,
                oldClrType: typeof(bool),
                oldNullable: true);

            migrationBuilder.AlterColumn<bool>(
                name: "HRA",
                schema: "GhipCP",
                table: "PolicyAttached",
                type: "bit",
                nullable: false,
                oldClrType: typeof(bool),
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "GracePeriodValue",
                schema: "GhipCP",
                table: "PolicyAttached",
                type: "int",
                nullable: false,
                oldClrType: typeof(int),
                oldNullable: true);

            migrationBuilder.AlterColumn<bool>(
                name: "FAQ",
                schema: "GhipCP",
                table: "PolicyAttached",
                type: "bit",
                nullable: false,
                oldClrType: typeof(bool),
                oldNullable: true);

            migrationBuilder.AlterColumn<bool>(
                name: "DownloadForms",
                schema: "GhipCP",
                table: "PolicyAttached",
                type: "bit",
                nullable: false,
                oldClrType: typeof(bool),
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "CorporateId",
                schema: "GhipCP",
                table: "PolicyAttached",
                type: "int",
                nullable: false,
                oldClrType: typeof(int),
                oldNullable: true);

            migrationBuilder.AlterColumn<bool>(
                name: "ConntactUs",
                schema: "GhipCP",
                table: "PolicyAttached",
                type: "bit",
                nullable: false,
                oldClrType: typeof(bool),
                oldNullable: true);

            migrationBuilder.AlterColumn<bool>(
                name: "AdditionOfDependents",
                schema: "GhipCP",
                table: "PolicyAttached",
                type: "bit",
                nullable: false,
                oldClrType: typeof(bool),
                oldNullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_PolicyAttached_Corporates_CorporateId",
                schema: "GhipCP",
                table: "PolicyAttached",
                column: "CorporateId",
                principalSchema: "GhipGlobal",
                principalTable: "Corporates",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
