﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RGI.GHIP.CoreAPIs.Data.Migrations
{
    public partial class UpdatedSMEntity : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Code",
                schema: "GhipGlobal",
                table: "SMMaster",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_SMPolicyMapping_SMId",
                schema: "GhipCP",
                table: "SMPolicyMapping",
                column: "SMId");

            migrationBuilder.AddForeignKey(
                name: "FK_SMPolicyMapping_SMMaster_SMId",
                schema: "GhipCP",
                table: "SMPolicyMapping",
                column: "SMId",
                principalSchema: "GhipGlobal",
                principalTable: "SMMaster",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_SMPolicyMapping_SMMaster_SMId",
                schema: "GhipCP",
                table: "SMPolicyMapping");

            migrationBuilder.DropIndex(
                name: "IX_SMPolicyMapping_SMId",
                schema: "GhipCP",
                table: "SMPolicyMapping");

            migrationBuilder.DropColumn(
                name: "Code",
                schema: "GhipGlobal",
                table: "SMMaster");
        }
    }
}
