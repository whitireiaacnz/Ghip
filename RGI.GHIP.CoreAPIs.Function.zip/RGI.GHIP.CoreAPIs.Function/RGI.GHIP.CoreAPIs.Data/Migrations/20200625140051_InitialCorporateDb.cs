﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace RGI.GHIP.CoreAPIs.Data.Migrations
{
    public partial class InitialCorporateDb : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "GhipGlobal");

            migrationBuilder.EnsureSchema(
                name: "GhipCP");

            migrationBuilder.EnsureSchema(
                name: "GhipPE");

            migrationBuilder.RenameTable(
                name: "Users",
                schema: "GHIP",
                newName: "Users",
                newSchema: "GhipGlobal");

            migrationBuilder.RenameTable(
                name: "StateMaster",
                schema: "GHIP",
                newName: "StateMaster",
                newSchema: "GhipGlobal");

            migrationBuilder.RenameTable(
                name: "Roles",
                schema: "GHIP",
                newName: "Roles",
                newSchema: "GhipGlobal");

            migrationBuilder.RenameTable(
                name: "RelationshipMasters",
                schema: "GHIP",
                newName: "RelationshipMasters",
                newSchema: "GhipPE");

            migrationBuilder.RenameTable(
                name: "RegionMaster",
                schema: "GHIP",
                newName: "RegionMaster",
                newSchema: "GhipGlobal");

            migrationBuilder.RenameTable(
                name: "PreEnrollmentPolicies",
                schema: "GHIP",
                newName: "PreEnrollmentPolicies",
                newSchema: "GhipPE");

            migrationBuilder.RenameTable(
                name: "PreEnrollmentPeriods",
                schema: "GHIP",
                newName: "PreEnrollmentPeriods",
                newSchema: "GhipPE");

            migrationBuilder.RenameTable(
                name: "PreEnrollmentMembers",
                schema: "GHIP",
                newName: "PreEnrollmentMembers",
                newSchema: "GhipPE");

            migrationBuilder.RenameTable(
                name: "PolicyRelationshipMappings",
                schema: "GHIP",
                newName: "PolicyRelationshipMappings",
                newSchema: "GhipPE");

            migrationBuilder.RenameTable(
                name: "PolicyFieldMappings",
                schema: "GHIP",
                newName: "PolicyFieldMappings",
                newSchema: "GhipPE");

            migrationBuilder.RenameTable(
                name: "FieldMasters",
                schema: "GHIP",
                newName: "FieldMasters",
                newSchema: "GhipPE");

            migrationBuilder.RenameTable(
                name: "EmailTemplates",
                schema: "GHIP",
                newName: "EmailTemplates",
                newSchema: "GhipPE");

            migrationBuilder.RenameTable(
                name: "DistrictMaster",
                schema: "GHIP",
                newName: "DistrictMaster",
                newSchema: "GhipGlobal");

            migrationBuilder.RenameTable(
                name: "Corporates",
                schema: "GHIP",
                newName: "Corporates",
                newSchema: "GhipGlobal");

            migrationBuilder.RenameTable(
                name: "CityOrVillageMaster",
                schema: "GHIP",
                newName: "CityOrVillageMaster",
                newSchema: "GhipGlobal");

            migrationBuilder.RenameTable(
                name: "AreaMaster",
                schema: "GHIP",
                newName: "AreaMaster",
                newSchema: "GhipGlobal");

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipGlobal",
                table: "Users",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(8)",
                oldMaxLength: 8,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipGlobal",
                table: "StateMaster",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(8)",
                oldMaxLength: 8,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipGlobal",
                table: "Roles",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(8)",
                oldMaxLength: 8,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipPE",
                table: "RelationshipMasters",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(8)",
                oldMaxLength: 8,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipGlobal",
                table: "RegionMaster",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(8)",
                oldMaxLength: 8,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipPE",
                table: "PreEnrollmentPolicies",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(8)",
                oldMaxLength: 8,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipPE",
                table: "PreEnrollmentPeriods",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(8)",
                oldMaxLength: 8,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipPE",
                table: "PreEnrollmentMembers",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(8)",
                oldMaxLength: 8,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipPE",
                table: "PolicyRelationshipMappings",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(8)",
                oldMaxLength: 8,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipPE",
                table: "PolicyFieldMappings",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(8)",
                oldMaxLength: 8,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipPE",
                table: "FieldMasters",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(8)",
                oldMaxLength: 8,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipPE",
                table: "EmailTemplates",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(8)",
                oldMaxLength: 8,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipGlobal",
                table: "DistrictMaster",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(8)",
                oldMaxLength: 8,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipGlobal",
                table: "Corporates",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(8)",
                oldMaxLength: 8,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipGlobal",
                table: "CityOrVillageMaster",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(8)",
                oldMaxLength: 8,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GhipGlobal",
                table: "AreaMaster",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(8)",
                oldMaxLength: 8,
                oldNullable: true);

            migrationBuilder.CreateTable(
                name: "HRMapping",
                schema: "GhipCP",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Key = table.Column<string>(nullable: true),
                    CreatedAt = table.Column<DateTime>(nullable: false),
                    CreatedBy = table.Column<string>(nullable: true),
                    ModifiedAt = table.Column<DateTime>(nullable: false),
                    ModifiedBy = table.Column<string>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false),
                    HRId = table.Column<int>(nullable: false),
                    HREmpId = table.Column<int>(nullable: false),
                    ReportAllowed = table.Column<string>(nullable: true),
                    Endoresment = table.Column<string>(nullable: true),
                    Dashboard = table.Column<string>(nullable: true),
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HRMapping", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Policy",
                schema: "GhipCP",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Key = table.Column<string>(nullable: true),
                    CreatedAt = table.Column<DateTime>(nullable: false),
                    CreatedBy = table.Column<string>(nullable: true),
                    ModifiedAt = table.Column<DateTime>(nullable: false),
                    ModifiedBy = table.Column<string>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false),
                    PolicyNumber = table.Column<string>(nullable: true),
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Policy", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "BrokerMaster",
                schema: "GhipGlobal",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Key = table.Column<string>(nullable: true),
                    CreatedAt = table.Column<DateTime>(nullable: false),
                    CreatedBy = table.Column<string>(nullable: true),
                    ModifiedAt = table.Column<DateTime>(nullable: false),
                    ModifiedBy = table.Column<string>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false),
                    Name = table.Column<string>(nullable: true),
                    Email = table.Column<string>(nullable: true),
                    MobileNo = table.Column<string>(nullable: true),
                    LoginEmailSentAt = table.Column<DateTime>(nullable: false),
                    LoginSMSSentAt = table.Column<DateTime>(nullable: false),
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BrokerMaster", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "SMMaster",
                schema: "GhipGlobal",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Key = table.Column<string>(nullable: true),
                    CreatedAt = table.Column<DateTime>(nullable: false),
                    CreatedBy = table.Column<string>(nullable: true),
                    ModifiedAt = table.Column<DateTime>(nullable: false),
                    ModifiedBy = table.Column<string>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false),
                    Name = table.Column<string>(nullable: true),
                    Email = table.Column<string>(nullable: true),
                    MobileNo = table.Column<string>(nullable: true),
                    LoginEmailSentAt = table.Column<DateTime>(nullable: false),
                    LoginSMSSentAt = table.Column<DateTime>(nullable: false),
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SMMaster", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "PolicyAttached",
                schema: "GhipCP",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Key = table.Column<string>(nullable: true),
                    CreatedAt = table.Column<DateTime>(nullable: false),
                    CreatedBy = table.Column<string>(nullable: true),
                    ModifiedAt = table.Column<DateTime>(nullable: false),
                    ModifiedBy = table.Column<string>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false),
                    CorporateId = table.Column<int>(nullable: false),
                    PolicyId = table.Column<int>(nullable: false),
                    PolicyNumber = table.Column<string>(nullable: true),
                    RiskStartDate = table.Column<DateTime>(nullable: false),
                    RiskEndDate = table.Column<DateTime>(nullable: false),
                    IssueDate = table.Column<DateTime>(nullable: false),
                    GracePeriodType = table.Column<string>(nullable: true),
                    GracePeriodValue = table.Column<int>(nullable: false),
                    UserNameType = table.Column<string>(nullable: true),
                    PasswordType = table.Column<string>(nullable: true),
                    ViewPolicyCoverage = table.Column<bool>(nullable: false),
                    AdditionOfDependents = table.Column<bool>(nullable: false),
                    TrackClaims = table.Column<bool>(nullable: false),
                    ViewECard = table.Column<bool>(nullable: false),
                    NetworkHospitalTracker = table.Column<bool>(nullable: false),
                    DownloadForms = table.Column<bool>(nullable: false),
                    IntimateClaims = table.Column<bool>(nullable: false),
                    ConntactUs = table.Column<bool>(nullable: false),
                    FAQ = table.Column<bool>(nullable: false),
                    Wellness = table.Column<bool>(nullable: false),
                    RHealthAssist = table.Column<bool>(nullable: false),
                    RHealthCircle = table.Column<bool>(nullable: false),
                    RHealthBeat = table.Column<bool>(nullable: false),
                    HealthOPedia = table.Column<bool>(nullable: false),
                    HRA = table.Column<bool>(nullable: false),
                    ValueDeals = table.Column<bool>(nullable: false),
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PolicyAttached", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PolicyAttached_Corporates_CorporateId",
                        column: x => x.CorporateId,
                        principalSchema: "GhipGlobal",
                        principalTable: "Corporates",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_PolicyAttached_Policy_PolicyId",
                        column: x => x.PolicyId,
                        principalSchema: "GhipCP",
                        principalTable: "Policy",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "BrokerPolicyMapping",
                schema: "GhipCP",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Key = table.Column<string>(nullable: true),
                    CreatedAt = table.Column<DateTime>(nullable: false),
                    CreatedBy = table.Column<string>(nullable: true),
                    ModifiedAt = table.Column<DateTime>(nullable: false),
                    ModifiedBy = table.Column<string>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false),
                    CPPolicyAttachedId = table.Column<int>(nullable: false),
                    BrokerId = table.Column<int>(nullable: false),
                    ReportAllowed = table.Column<string>(nullable: true),
                    Endoresment = table.Column<string>(nullable: true),
                    Dashboard = table.Column<string>(nullable: true),
                    CPPolicyId = table.Column<int>(nullable: true),
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BrokerPolicyMapping", x => x.Id);
                    table.ForeignKey(
                        name: "FK_BrokerPolicyMapping_PolicyAttached_CPPolicyId",
                        column: x => x.CPPolicyId,
                        principalSchema: "GhipCP",
                        principalTable: "PolicyAttached",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Employee",
                schema: "GhipCP",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Key = table.Column<string>(nullable: true),
                    CreatedAt = table.Column<DateTime>(nullable: false),
                    CreatedBy = table.Column<string>(nullable: true),
                    ModifiedAt = table.Column<DateTime>(nullable: false),
                    ModifiedBy = table.Column<string>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false),
                    CPPolicyAttachedId = table.Column<int>(nullable: false),
                    Name = table.Column<string>(nullable: true),
                    Email = table.Column<string>(nullable: true),
                    MobileNo = table.Column<string>(nullable: true),
                    LoginEmailSentAt = table.Column<DateTime>(nullable: false),
                    LoginSMSSentAt = table.Column<DateTime>(nullable: false),
                    CPPolicyId = table.Column<int>(nullable: true),
                    CPHRMappingEntityId = table.Column<int>(nullable: true),
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Employee", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Employee_HRMapping_CPHRMappingEntityId",
                        column: x => x.CPHRMappingEntityId,
                        principalSchema: "GhipCP",
                        principalTable: "HRMapping",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Employee_PolicyAttached_CPPolicyId",
                        column: x => x.CPPolicyId,
                        principalSchema: "GhipCP",
                        principalTable: "PolicyAttached",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "SMPolicyMapping",
                schema: "GhipCP",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Key = table.Column<string>(nullable: true),
                    CreatedAt = table.Column<DateTime>(nullable: false),
                    CreatedBy = table.Column<string>(nullable: true),
                    ModifiedAt = table.Column<DateTime>(nullable: false),
                    ModifiedBy = table.Column<string>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false),
                    CPPolicyAttachedId = table.Column<int>(nullable: false),
                    SMId = table.Column<int>(nullable: false),
                    ReportAllowed = table.Column<string>(nullable: true),
                    Endoresment = table.Column<string>(nullable: true),
                    Dashboard = table.Column<string>(nullable: true),
                    CPPolicyId = table.Column<int>(nullable: true),
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SMPolicyMapping", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SMPolicyMapping_PolicyAttached_CPPolicyId",
                        column: x => x.CPPolicyId,
                        principalSchema: "GhipCP",
                        principalTable: "PolicyAttached",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_BrokerPolicyMapping_CPPolicyId",
                schema: "GhipCP",
                table: "BrokerPolicyMapping",
                column: "CPPolicyId");

            migrationBuilder.CreateIndex(
                name: "IX_Employee_CPHRMappingEntityId",
                schema: "GhipCP",
                table: "Employee",
                column: "CPHRMappingEntityId");

            migrationBuilder.CreateIndex(
                name: "IX_Employee_CPPolicyId",
                schema: "GhipCP",
                table: "Employee",
                column: "CPPolicyId");

            migrationBuilder.CreateIndex(
                name: "IX_PolicyAttached_CorporateId",
                schema: "GhipCP",
                table: "PolicyAttached",
                column: "CorporateId");

            migrationBuilder.CreateIndex(
                name: "IX_PolicyAttached_PolicyId",
                schema: "GhipCP",
                table: "PolicyAttached",
                column: "PolicyId");

            migrationBuilder.CreateIndex(
                name: "IX_SMPolicyMapping_CPPolicyId",
                schema: "GhipCP",
                table: "SMPolicyMapping",
                column: "CPPolicyId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "BrokerPolicyMapping",
                schema: "GhipCP");

            migrationBuilder.DropTable(
                name: "Employee",
                schema: "GhipCP");

            migrationBuilder.DropTable(
                name: "SMPolicyMapping",
                schema: "GhipCP");

            migrationBuilder.DropTable(
                name: "BrokerMaster",
                schema: "GhipGlobal");

            migrationBuilder.DropTable(
                name: "SMMaster",
                schema: "GhipGlobal");

            migrationBuilder.DropTable(
                name: "HRMapping",
                schema: "GhipCP");

            migrationBuilder.DropTable(
                name: "PolicyAttached",
                schema: "GhipCP");

            migrationBuilder.DropTable(
                name: "Policy",
                schema: "GhipCP");

            migrationBuilder.EnsureSchema(
                name: "GHIP");

            migrationBuilder.RenameTable(
                name: "RelationshipMasters",
                schema: "GhipPE",
                newName: "RelationshipMasters",
                newSchema: "GHIP");

            migrationBuilder.RenameTable(
                name: "PreEnrollmentPolicies",
                schema: "GhipPE",
                newName: "PreEnrollmentPolicies",
                newSchema: "GHIP");

            migrationBuilder.RenameTable(
                name: "PreEnrollmentPeriods",
                schema: "GhipPE",
                newName: "PreEnrollmentPeriods",
                newSchema: "GHIP");

            migrationBuilder.RenameTable(
                name: "PreEnrollmentMembers",
                schema: "GhipPE",
                newName: "PreEnrollmentMembers",
                newSchema: "GHIP");

            migrationBuilder.RenameTable(
                name: "PolicyRelationshipMappings",
                schema: "GhipPE",
                newName: "PolicyRelationshipMappings",
                newSchema: "GHIP");

            migrationBuilder.RenameTable(
                name: "PolicyFieldMappings",
                schema: "GhipPE",
                newName: "PolicyFieldMappings",
                newSchema: "GHIP");

            migrationBuilder.RenameTable(
                name: "FieldMasters",
                schema: "GhipPE",
                newName: "FieldMasters",
                newSchema: "GHIP");

            migrationBuilder.RenameTable(
                name: "EmailTemplates",
                schema: "GhipPE",
                newName: "EmailTemplates",
                newSchema: "GHIP");

            migrationBuilder.RenameTable(
                name: "Users",
                schema: "GhipGlobal",
                newName: "Users",
                newSchema: "GHIP");

            migrationBuilder.RenameTable(
                name: "StateMaster",
                schema: "GhipGlobal",
                newName: "StateMaster",
                newSchema: "GHIP");

            migrationBuilder.RenameTable(
                name: "Roles",
                schema: "GhipGlobal",
                newName: "Roles",
                newSchema: "GHIP");

            migrationBuilder.RenameTable(
                name: "RegionMaster",
                schema: "GhipGlobal",
                newName: "RegionMaster",
                newSchema: "GHIP");

            migrationBuilder.RenameTable(
                name: "DistrictMaster",
                schema: "GhipGlobal",
                newName: "DistrictMaster",
                newSchema: "GHIP");

            migrationBuilder.RenameTable(
                name: "Corporates",
                schema: "GhipGlobal",
                newName: "Corporates",
                newSchema: "GHIP");

            migrationBuilder.RenameTable(
                name: "CityOrVillageMaster",
                schema: "GhipGlobal",
                newName: "CityOrVillageMaster",
                newSchema: "GHIP");

            migrationBuilder.RenameTable(
                name: "AreaMaster",
                schema: "GhipGlobal",
                newName: "AreaMaster",
                newSchema: "GHIP");

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GHIP",
                table: "RelationshipMasters",
                type: "nvarchar(8)",
                maxLength: 8,
                nullable: true,
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GHIP",
                table: "PreEnrollmentPolicies",
                type: "nvarchar(8)",
                maxLength: 8,
                nullable: true,
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GHIP",
                table: "PreEnrollmentPeriods",
                type: "nvarchar(8)",
                maxLength: 8,
                nullable: true,
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GHIP",
                table: "PreEnrollmentMembers",
                type: "nvarchar(8)",
                maxLength: 8,
                nullable: true,
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GHIP",
                table: "PolicyRelationshipMappings",
                type: "nvarchar(8)",
                maxLength: 8,
                nullable: true,
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GHIP",
                table: "PolicyFieldMappings",
                type: "nvarchar(8)",
                maxLength: 8,
                nullable: true,
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GHIP",
                table: "FieldMasters",
                type: "nvarchar(8)",
                maxLength: 8,
                nullable: true,
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GHIP",
                table: "EmailTemplates",
                type: "nvarchar(8)",
                maxLength: 8,
                nullable: true,
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GHIP",
                table: "Users",
                type: "nvarchar(8)",
                maxLength: 8,
                nullable: true,
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GHIP",
                table: "StateMaster",
                type: "nvarchar(8)",
                maxLength: 8,
                nullable: true,
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GHIP",
                table: "Roles",
                type: "nvarchar(8)",
                maxLength: 8,
                nullable: true,
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GHIP",
                table: "RegionMaster",
                type: "nvarchar(8)",
                maxLength: 8,
                nullable: true,
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GHIP",
                table: "DistrictMaster",
                type: "nvarchar(8)",
                maxLength: 8,
                nullable: true,
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GHIP",
                table: "Corporates",
                type: "nvarchar(8)",
                maxLength: 8,
                nullable: true,
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GHIP",
                table: "CityOrVillageMaster",
                type: "nvarchar(8)",
                maxLength: 8,
                nullable: true,
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Key",
                schema: "GHIP",
                table: "AreaMaster",
                type: "nvarchar(8)",
                maxLength: 8,
                nullable: true,
                oldClrType: typeof(string),
                oldNullable: true);
        }
    }
}
