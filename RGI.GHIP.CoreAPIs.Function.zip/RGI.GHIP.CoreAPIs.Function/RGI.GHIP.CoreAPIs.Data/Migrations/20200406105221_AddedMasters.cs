﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace RGI.GHIP.CoreAPIs.Data.Migrations
{
    public partial class AddedMasters : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "RegionMaster",
                schema: "GHIP",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Key = table.Column<string>(maxLength: 8, nullable: true),
                    CreatedAtUtc = table.Column<DateTime>(nullable: false),
                    CreatedBy = table.Column<string>(nullable: true),
                    ModifiedAtUtc = table.Column<DateTime>(nullable: false),
                    ModifiedBy = table.Column<string>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false),
                    SystemRegionId = table.Column<int>(nullable: true),
                    RegionZoneIdFk = table.Column<int>(nullable: false),
                    ZoneCode = table.Column<string>(nullable: true),
                    RegionCode = table.Column<string>(nullable: true),
                    RegionName = table.Column<string>(nullable: true),
                    Field1 = table.Column<string>(nullable: true),
                    Field2 = table.Column<string>(nullable: true),
                    RegionArc = table.Column<bool>(nullable: false),
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RegionMaster", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "StateMaster",
                schema: "GHIP",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Key = table.Column<string>(maxLength: 8, nullable: true),
                    CreatedAtUtc = table.Column<DateTime>(nullable: false),
                    CreatedBy = table.Column<string>(nullable: true),
                    ModifiedAtUtc = table.Column<DateTime>(nullable: false),
                    ModifiedBy = table.Column<string>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false),
                    StateCountryIdFk = table.Column<int>(nullable: false),
                    StateCode = table.Column<string>(maxLength: 50, nullable: true),
                    StateName = table.Column<string>(maxLength: 250, nullable: false),
                    Field1 = table.Column<string>(maxLength: 50, nullable: true),
                    Field2 = table.Column<string>(maxLength: 50, nullable: true),
                    StateArc = table.Column<bool>(nullable: false),
                    GstCode = table.Column<string>(maxLength: 50, nullable: true),
                    IsUnionTerritory = table.Column<bool>(nullable: true),
                    OmbudsmanAddress = table.Column<string>(maxLength: 4000, nullable: true),
                    GrievanceClause = table.Column<string>(nullable: true),
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_StateMaster", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "DistrictMaster",
                schema: "GHIP",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Key = table.Column<string>(maxLength: 8, nullable: true),
                    CreatedAtUtc = table.Column<DateTime>(nullable: false),
                    CreatedBy = table.Column<string>(nullable: true),
                    ModifiedAtUtc = table.Column<DateTime>(nullable: false),
                    ModifiedBy = table.Column<string>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false),
                    StateId = table.Column<int>(nullable: false),
                    DistrictCode = table.Column<string>(maxLength: 50, nullable: true),
                    DistrictName = table.Column<string>(maxLength: 250, nullable: true),
                    EqZone = table.Column<string>(maxLength: 50, nullable: true),
                    Field1 = table.Column<string>(maxLength: 50, nullable: true),
                    Field2 = table.Column<string>(maxLength: 50, nullable: true),
                    CityDistrictArc = table.Column<bool>(nullable: false),
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DistrictMaster", x => x.Id);
                    table.ForeignKey(
                        name: "FK_DistrictMaster_StateMaster_StateId",
                        column: x => x.StateId,
                        principalSchema: "GHIP",
                        principalTable: "StateMaster",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "CityOrVillageMaster",
                schema: "GHIP",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Key = table.Column<string>(maxLength: 8, nullable: true),
                    CreatedAtUtc = table.Column<DateTime>(nullable: false),
                    CreatedBy = table.Column<string>(nullable: true),
                    ModifiedAtUtc = table.Column<DateTime>(nullable: false),
                    ModifiedBy = table.Column<string>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false),
                    DistrictId = table.Column<int>(nullable: false),
                    CityOrVillageCode = table.Column<string>(maxLength: 250, nullable: true),
                    CityOrVillageName = table.Column<string>(maxLength: 250, nullable: true),
                    CityType = table.Column<string>(maxLength: 250, nullable: true),
                    Tahsil = table.Column<string>(maxLength: 250, nullable: true),
                    Pincode = table.Column<string>(maxLength: 50, nullable: true),
                    Field1 = table.Column<string>(maxLength: 50, nullable: true),
                    Field2 = table.Column<string>(maxLength: 50, nullable: true),
                    CityCityOrVillageArc = table.Column<bool>(nullable: false),
                    BranchIdFk = table.Column<int>(nullable: true),
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CityOrVillageMaster", x => x.Id);
                    table.ForeignKey(
                        name: "FK_CityOrVillageMaster_DistrictMaster_DistrictId",
                        column: x => x.DistrictId,
                        principalSchema: "GHIP",
                        principalTable: "DistrictMaster",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AreaMaster",
                schema: "GHIP",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Key = table.Column<string>(maxLength: 8, nullable: true),
                    CreatedAtUtc = table.Column<DateTime>(nullable: false),
                    CreatedBy = table.Column<string>(nullable: true),
                    ModifiedAtUtc = table.Column<DateTime>(nullable: false),
                    ModifiedBy = table.Column<string>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false),
                    CityId = table.Column<int>(nullable: false),
                    AreaName = table.Column<string>(maxLength: 250, nullable: false),
                    PinCode = table.Column<string>(nullable: false),
                    Field1 = table.Column<string>(maxLength: 50, nullable: true),
                    Field2 = table.Column<string>(maxLength: 50, nullable: true),
                    AreaArc = table.Column<bool>(nullable: false),
                    DistrictId = table.Column<int>(nullable: false),
                    Latitude = table.Column<string>(maxLength: 100, nullable: true),
                    Longitude = table.Column<string>(maxLength: 100, nullable: true),
                    LatLongAddress = table.Column<string>(maxLength: 200, nullable: true),
                    IsError = table.Column<bool>(nullable: true),
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AreaMaster", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AreaMaster_CityOrVillageMaster_CityId",
                        column: x => x.CityId,
                        principalSchema: "GHIP",
                        principalTable: "CityOrVillageMaster",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_AreaMaster_CityId",
                schema: "GHIP",
                table: "AreaMaster",
                column: "CityId");

            migrationBuilder.CreateIndex(
                name: "IX_CityOrVillageMaster_DistrictId",
                schema: "GHIP",
                table: "CityOrVillageMaster",
                column: "DistrictId");

            migrationBuilder.CreateIndex(
                name: "IX_DistrictMaster_StateId",
                schema: "GHIP",
                table: "DistrictMaster",
                column: "StateId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AreaMaster",
                schema: "GHIP");

            migrationBuilder.DropTable(
                name: "RegionMaster",
                schema: "GHIP");

            migrationBuilder.DropTable(
                name: "CityOrVillageMaster",
                schema: "GHIP");

            migrationBuilder.DropTable(
                name: "DistrictMaster",
                schema: "GHIP");

            migrationBuilder.DropTable(
                name: "StateMaster",
                schema: "GHIP");
        }
    }
}
