﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace RGI.GHIP.CoreAPIs.Data.Migrations
{
    public partial class MemberEntity : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Age",
                schema: "GHIP",
                table: "PreEnrollmentMembers");

            migrationBuilder.DropColumn(
                name: "DateOfBirth",
                schema: "GHIP",
                table: "PreEnrollmentMembers");

            migrationBuilder.DropColumn(
                name: "EmailAddress",
                schema: "GHIP",
                table: "PreEnrollmentMembers");

            migrationBuilder.DropColumn(
                name: "Gender",
                schema: "GHIP",
                table: "PreEnrollmentMembers");

            migrationBuilder.DropColumn(
                name: "Grade",
                schema: "GHIP",
                table: "PreEnrollmentMembers");

            migrationBuilder.DropColumn(
                name: "InsuredName",
                schema: "GHIP",
                table: "PreEnrollmentMembers");

            migrationBuilder.DropColumn(
                name: "MobileNumber",
                schema: "GHIP",
                table: "PreEnrollmentMembers");

            migrationBuilder.DropColumn(
                name: "SumInsured",
                schema: "GHIP",
                table: "PreEnrollmentMembers");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "Age",
                schema: "GHIP",
                table: "PreEnrollmentMembers",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<DateTime>(
                name: "DateOfBirth",
                schema: "GHIP",
                table: "PreEnrollmentMembers",
                type: "DateTime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<string>(
                name: "EmailAddress",
                schema: "GHIP",
                table: "PreEnrollmentMembers",
                type: "nvarchar(64)",
                maxLength: 64,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Gender",
                schema: "GHIP",
                table: "PreEnrollmentMembers",
                type: "nvarchar(8)",
                maxLength: 8,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Grade",
                schema: "GHIP",
                table: "PreEnrollmentMembers",
                type: "nvarchar(32)",
                maxLength: 32,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "InsuredName",
                schema: "GHIP",
                table: "PreEnrollmentMembers",
                type: "nvarchar(256)",
                maxLength: 256,
                nullable: false,
                defaultValue: string.Empty);

            migrationBuilder.AddColumn<string>(
                name: "MobileNumber",
                schema: "GHIP",
                table: "PreEnrollmentMembers",
                type: "nvarchar(16)",
                maxLength: 16,
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "SumInsured",
                schema: "GHIP",
                table: "PreEnrollmentMembers",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }
    }
}
