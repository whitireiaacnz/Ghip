﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RGI.GHIP.CoreAPIs.Data.Migrations
{
    public partial class CoporateEntityAddress : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<long>(
                name: "AreaId",
                schema: "GHIP",
                table: "Corporates",
                nullable: false,
                defaultValue: 0L);

            migrationBuilder.AddColumn<int>(
                name: "CityId",
                schema: "GHIP",
                table: "Corporates",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "DistrictId",
                schema: "GHIP",
                table: "Corporates",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "StateId",
                schema: "GHIP",
                table: "Corporates",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "AreaId",
                schema: "GHIP",
                table: "Corporates");

            migrationBuilder.DropColumn(
                name: "CityId",
                schema: "GHIP",
                table: "Corporates");

            migrationBuilder.DropColumn(
                name: "DistrictId",
                schema: "GHIP",
                table: "Corporates");

            migrationBuilder.DropColumn(
                name: "StateId",
                schema: "GHIP",
                table: "Corporates");
        }
    }
}
