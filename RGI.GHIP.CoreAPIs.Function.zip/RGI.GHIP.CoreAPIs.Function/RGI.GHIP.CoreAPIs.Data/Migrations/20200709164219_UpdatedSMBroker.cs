﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RGI.GHIP.CoreAPIs.Data.Migrations
{
    public partial class UpdatedSMBroker : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<bool>(
                name: "ReportAllowed",
                schema: "GhipCP",
                table: "SMPolicyMapping",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<bool>(
                name: "Endoresment",
                schema: "GhipCP",
                table: "SMPolicyMapping",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<bool>(
                name: "Dashboard",
                schema: "GhipCP",
                table: "SMPolicyMapping",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "ReimbersementReport",
                schema: "GhipCP",
                table: "SMPolicyMapping",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "CashlessReport",
                schema: "GhipCP",
                table: "SMPolicyMapping",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "DyanamicDashboard",
                schema: "GhipCP",
                table: "SMPolicyMapping",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "EnhancementReport",
                schema: "GhipCP",
                table: "SMPolicyMapping",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "StaticDashboard",
                schema: "GhipCP",
                table: "SMPolicyMapping",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AlterColumn<bool>(
                name: "ReportAllowed",
                schema: "GhipCP",
                table: "BrokerPolicyMapping",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<bool>(
                name: "Endoresment",
                schema: "GhipCP",
                table: "BrokerPolicyMapping",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<bool>(
                name: "Dashboard",
                schema: "GhipCP",
                table: "BrokerPolicyMapping",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "ReimbersementReport",
                schema: "GhipCP",
                table: "BrokerPolicyMapping",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "CashlessReport",
                schema: "GhipCP",
                table: "BrokerPolicyMapping",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "DyanamicDashboard",
                schema: "GhipCP",
                table: "BrokerPolicyMapping",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "EnhancementReport",
                schema: "GhipCP",
                table: "BrokerPolicyMapping",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "StaticDashboard",
                schema: "GhipCP",
                table: "BrokerPolicyMapping",
                nullable: false,
                defaultValue: false);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ReimbersementReport",
                schema: "GhipCP",
                table: "SMPolicyMapping");

            migrationBuilder.DropColumn(
                name: "CashlessReport",
                schema: "GhipCP",
                table: "SMPolicyMapping");

            migrationBuilder.DropColumn(
                name: "DyanamicDashboard",
                schema: "GhipCP",
                table: "SMPolicyMapping");

            migrationBuilder.DropColumn(
                name: "EnhancementReport",
                schema: "GhipCP",
                table: "SMPolicyMapping");

            migrationBuilder.DropColumn(
                name: "StaticDashboard",
                schema: "GhipCP",
                table: "SMPolicyMapping");

            migrationBuilder.DropColumn(
                name: "ReimbersementReport",
                schema: "GhipCP",
                table: "BrokerPolicyMapping");

            migrationBuilder.DropColumn(
                name: "CashlessReport",
                schema: "GhipCP",
                table: "BrokerPolicyMapping");

            migrationBuilder.DropColumn(
                name: "DyanamicDashboard",
                schema: "GhipCP",
                table: "BrokerPolicyMapping");

            migrationBuilder.DropColumn(
                name: "EnhancementReport",
                schema: "GhipCP",
                table: "BrokerPolicyMapping");

            migrationBuilder.DropColumn(
                name: "StaticDashboard",
                schema: "GhipCP",
                table: "BrokerPolicyMapping");

            migrationBuilder.AlterColumn<string>(
                name: "ReportAllowed",
                schema: "GhipCP",
                table: "SMPolicyMapping",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(bool));

            migrationBuilder.AlterColumn<string>(
                name: "Endoresment",
                schema: "GhipCP",
                table: "SMPolicyMapping",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(bool));

            migrationBuilder.AlterColumn<string>(
                name: "Dashboard",
                schema: "GhipCP",
                table: "SMPolicyMapping",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(bool));

            migrationBuilder.AlterColumn<string>(
                name: "ReportAllowed",
                schema: "GhipCP",
                table: "BrokerPolicyMapping",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(bool));

            migrationBuilder.AlterColumn<string>(
                name: "Endoresment",
                schema: "GhipCP",
                table: "BrokerPolicyMapping",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(bool));

            migrationBuilder.AlterColumn<string>(
                name: "Dashboard",
                schema: "GhipCP",
                table: "BrokerPolicyMapping",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(bool));
        }
    }
}
