﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RGI.GHIP.CoreAPIs.Data.Migrations
{
    public partial class Email : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "ConfirmationEmailTemplate",
                schema: "GHIP",
                table: "PreEnrollmentMembers",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "WelcomeEmailTemplate",
                schema: "GHIP",
                table: "PreEnrollmentMembers",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ConfirmationEmailTemplate",
                schema: "GHIP",
                table: "PreEnrollmentMembers");

            migrationBuilder.DropColumn(
                name: "WelcomeEmailTemplate",
                schema: "GHIP",
                table: "PreEnrollmentMembers");
        }
    }
}
