﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RGI.GHIP.CoreAPIs.Data.Migrations
{
    public partial class RemovedCorporateFKFromMemberFeatures : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "PolicyNumber",
                schema: "GhipCP",
                table: "PolicyMemberFeatures");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "PolicyNumber",
                schema: "GhipCP",
                table: "PolicyMemberFeatures",
                type: "nvarchar(max)",
                nullable: true);
        }
    }
}
