﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RGI.GHIP.CoreAPIs.Data.Migrations
{
    public partial class UpdatedHR : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_HRMapping_Members_MemberId",
                schema: "GhipCP",
                table: "HRMapping");

            migrationBuilder.AlterColumn<bool>(
                name: "ReportAllowed",
                schema: "GhipCP",
                table: "HRMapping",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "MemberId",
                schema: "GhipCP",
                table: "HRMapping",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<bool>(
                name: "Endoresment",
                schema: "GhipCP",
                table: "HRMapping",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<bool>(
                name: "Dashboard",
                schema: "GhipCP",
                table: "HRMapping",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "ReimbersementReport",
                schema: "GhipCP",
                table: "HRMapping",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "CashlessReport",
                schema: "GhipCP",
                table: "HRMapping",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "DyanamicDashboard",
                schema: "GhipCP",
                table: "HRMapping",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "EnhancementReport",
                schema: "GhipCP",
                table: "HRMapping",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "StaticDashboard",
                schema: "GhipCP",
                table: "HRMapping",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddForeignKey(
                name: "FK_HRMapping_Members_MemberId",
                schema: "GhipCP",
                table: "HRMapping",
                column: "MemberId",
                principalSchema: "GhipCP",
                principalTable: "Members",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_HRMapping_Members_MemberId",
                schema: "GhipCP",
                table: "HRMapping");

            migrationBuilder.DropColumn(
                name: "ReimbersementReport",
                schema: "GhipCP",
                table: "HRMapping");

            migrationBuilder.DropColumn(
                name: "CashlessReport",
                schema: "GhipCP",
                table: "HRMapping");

            migrationBuilder.DropColumn(
                name: "DyanamicDashboard",
                schema: "GhipCP",
                table: "HRMapping");

            migrationBuilder.DropColumn(
                name: "EnhancementReport",
                schema: "GhipCP",
                table: "HRMapping");

            migrationBuilder.DropColumn(
                name: "StaticDashboard",
                schema: "GhipCP",
                table: "HRMapping");

            migrationBuilder.AlterColumn<string>(
                name: "ReportAllowed",
                schema: "GhipCP",
                table: "HRMapping",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(bool));

            migrationBuilder.AlterColumn<int>(
                name: "MemberId",
                schema: "GhipCP",
                table: "HRMapping",
                type: "int",
                nullable: true,
                oldClrType: typeof(int));

            migrationBuilder.AlterColumn<string>(
                name: "Endoresment",
                schema: "GhipCP",
                table: "HRMapping",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(bool));

            migrationBuilder.AlterColumn<string>(
                name: "Dashboard",
                schema: "GhipCP",
                table: "HRMapping",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(bool));

            migrationBuilder.AddForeignKey(
                name: "FK_HRMapping_Members_MemberId",
                schema: "GhipCP",
                table: "HRMapping",
                column: "MemberId",
                principalSchema: "GhipCP",
                principalTable: "Members",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
