﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace RGI.GHIP.CoreAPIs.Data.Migrations
{
    public partial class MemberEntityFinalsubmission : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<DateTime>(
                name: "FinalSubmissionCompletedAt",
                schema: "GHIP",
                table: "PreEnrollmentMembers",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<bool>(
                name: "IsFinalSubmissionLocked",
                schema: "GHIP",
                table: "PreEnrollmentMembers",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<DateTime>(
                name: "LastLoggedInAt",
                schema: "GHIP",
                table: "PreEnrollmentMembers",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "WelcomeEmailSentAt",
                schema: "GHIP",
                table: "PreEnrollmentMembers",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "FinalSubmissionCompletedAt",
                schema: "GHIP",
                table: "PreEnrollmentMembers");

            migrationBuilder.DropColumn(
                name: "IsFinalSubmissionLocked",
                schema: "GHIP",
                table: "PreEnrollmentMembers");

            migrationBuilder.DropColumn(
                name: "LastLoggedInAt",
                schema: "GHIP",
                table: "PreEnrollmentMembers");

            migrationBuilder.DropColumn(
                name: "WelcomeEmailSentAt",
                schema: "GHIP",
                table: "PreEnrollmentMembers");
        }
    }
}
