﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace RGI.GHIP.CoreAPIs.Data.Migrations
{
    public partial class UpdateBaseEntity : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "CreatedAtUtc",
                schema: "GHIP",
                table: "Users");

            migrationBuilder.DropColumn(
                name: "ModifiedAtUtc",
                schema: "GHIP",
                table: "Users");

            migrationBuilder.DropColumn(
                name: "CreatedAtUtc",
                schema: "GHIP",
                table: "StateMaster");

            migrationBuilder.DropColumn(
                name: "ModifiedAtUtc",
                schema: "GHIP",
                table: "StateMaster");

            migrationBuilder.DropColumn(
                name: "CreatedAtUtc",
                schema: "GHIP",
                table: "Roles");

            migrationBuilder.DropColumn(
                name: "ModifiedAtUtc",
                schema: "GHIP",
                table: "Roles");

            migrationBuilder.DropColumn(
                name: "CreatedAtUtc",
                schema: "GHIP",
                table: "RelationshipMasters");

            migrationBuilder.DropColumn(
                name: "ModifiedAtUtc",
                schema: "GHIP",
                table: "RelationshipMasters");

            migrationBuilder.DropColumn(
                name: "CreatedAtUtc",
                schema: "GHIP",
                table: "RegionMaster");

            migrationBuilder.DropColumn(
                name: "ModifiedAtUtc",
                schema: "GHIP",
                table: "RegionMaster");

            migrationBuilder.DropColumn(
                name: "CreatedAtUtc",
                schema: "GHIP",
                table: "PreEnrollmentPolicies");

            migrationBuilder.DropColumn(
                name: "ModifiedAtUtc",
                schema: "GHIP",
                table: "PreEnrollmentPolicies");

            migrationBuilder.DropColumn(
                name: "CreatedAtUtc",
                schema: "GHIP",
                table: "PreEnrollmentPeriods");

            migrationBuilder.DropColumn(
                name: "ModifiedAtUtc",
                schema: "GHIP",
                table: "PreEnrollmentPeriods");

            migrationBuilder.DropColumn(
                name: "CreatedAtUtc",
                schema: "GHIP",
                table: "PreEnrollmentMembers");

            migrationBuilder.DropColumn(
                name: "ModifiedAtUtc",
                schema: "GHIP",
                table: "PreEnrollmentMembers");

            migrationBuilder.DropColumn(
                name: "CreatedAtUtc",
                schema: "GHIP",
                table: "PolicyRelationshipMappings");

            migrationBuilder.DropColumn(
                name: "ModifiedAtUtc",
                schema: "GHIP",
                table: "PolicyRelationshipMappings");

            migrationBuilder.DropColumn(
                name: "CreatedAtUtc",
                schema: "GHIP",
                table: "PolicyFieldMappings");

            migrationBuilder.DropColumn(
                name: "ModifiedAtUtc",
                schema: "GHIP",
                table: "PolicyFieldMappings");

            migrationBuilder.DropColumn(
                name: "CreatedAtUtc",
                schema: "GHIP",
                table: "FieldMasters");

            migrationBuilder.DropColumn(
                name: "ModifiedAtUtc",
                schema: "GHIP",
                table: "FieldMasters");

            migrationBuilder.DropColumn(
                name: "CreatedAtUtc",
                schema: "GHIP",
                table: "EmailTemplates");

            migrationBuilder.DropColumn(
                name: "ModifiedAtUtc",
                schema: "GHIP",
                table: "EmailTemplates");

            migrationBuilder.DropColumn(
                name: "CreatedAtUtc",
                schema: "GHIP",
                table: "DistrictMaster");

            migrationBuilder.DropColumn(
                name: "ModifiedAtUtc",
                schema: "GHIP",
                table: "DistrictMaster");

            migrationBuilder.DropColumn(
                name: "CreatedAtUtc",
                schema: "GHIP",
                table: "Corporates");

            migrationBuilder.DropColumn(
                name: "ModifiedAtUtc",
                schema: "GHIP",
                table: "Corporates");

            migrationBuilder.DropColumn(
                name: "CreatedAtUtc",
                schema: "GHIP",
                table: "CityOrVillageMaster");

            migrationBuilder.DropColumn(
                name: "ModifiedAtUtc",
                schema: "GHIP",
                table: "CityOrVillageMaster");

            migrationBuilder.DropColumn(
                name: "CreatedAtUtc",
                schema: "GHIP",
                table: "AreaMaster");

            migrationBuilder.DropColumn(
                name: "ModifiedAtUtc",
                schema: "GHIP",
                table: "AreaMaster");

            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedAt",
                schema: "GHIP",
                table: "Users",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "ModifiedAt",
                schema: "GHIP",
                table: "Users",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedAt",
                schema: "GHIP",
                table: "StateMaster",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "ModifiedAt",
                schema: "GHIP",
                table: "StateMaster",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedAt",
                schema: "GHIP",
                table: "Roles",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "ModifiedAt",
                schema: "GHIP",
                table: "Roles",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedAt",
                schema: "GHIP",
                table: "RelationshipMasters",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "ModifiedAt",
                schema: "GHIP",
                table: "RelationshipMasters",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedAt",
                schema: "GHIP",
                table: "RegionMaster",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "ModifiedAt",
                schema: "GHIP",
                table: "RegionMaster",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedAt",
                schema: "GHIP",
                table: "PreEnrollmentPolicies",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "ModifiedAt",
                schema: "GHIP",
                table: "PreEnrollmentPolicies",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedAt",
                schema: "GHIP",
                table: "PreEnrollmentPeriods",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "ModifiedAt",
                schema: "GHIP",
                table: "PreEnrollmentPeriods",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedAt",
                schema: "GHIP",
                table: "PreEnrollmentMembers",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "ModifiedAt",
                schema: "GHIP",
                table: "PreEnrollmentMembers",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedAt",
                schema: "GHIP",
                table: "PolicyRelationshipMappings",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "ModifiedAt",
                schema: "GHIP",
                table: "PolicyRelationshipMappings",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedAt",
                schema: "GHIP",
                table: "PolicyFieldMappings",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "ModifiedAt",
                schema: "GHIP",
                table: "PolicyFieldMappings",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedAt",
                schema: "GHIP",
                table: "FieldMasters",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "ModifiedAt",
                schema: "GHIP",
                table: "FieldMasters",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedAt",
                schema: "GHIP",
                table: "EmailTemplates",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "ModifiedAt",
                schema: "GHIP",
                table: "EmailTemplates",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedAt",
                schema: "GHIP",
                table: "DistrictMaster",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "ModifiedAt",
                schema: "GHIP",
                table: "DistrictMaster",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedAt",
                schema: "GHIP",
                table: "Corporates",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "ModifiedAt",
                schema: "GHIP",
                table: "Corporates",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedAt",
                schema: "GHIP",
                table: "CityOrVillageMaster",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "ModifiedAt",
                schema: "GHIP",
                table: "CityOrVillageMaster",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedAt",
                schema: "GHIP",
                table: "AreaMaster",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "ModifiedAt",
                schema: "GHIP",
                table: "AreaMaster",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "CreatedAt",
                schema: "GHIP",
                table: "Users");

            migrationBuilder.DropColumn(
                name: "ModifiedAt",
                schema: "GHIP",
                table: "Users");

            migrationBuilder.DropColumn(
                name: "CreatedAt",
                schema: "GHIP",
                table: "StateMaster");

            migrationBuilder.DropColumn(
                name: "ModifiedAt",
                schema: "GHIP",
                table: "StateMaster");

            migrationBuilder.DropColumn(
                name: "CreatedAt",
                schema: "GHIP",
                table: "Roles");

            migrationBuilder.DropColumn(
                name: "ModifiedAt",
                schema: "GHIP",
                table: "Roles");

            migrationBuilder.DropColumn(
                name: "CreatedAt",
                schema: "GHIP",
                table: "RelationshipMasters");

            migrationBuilder.DropColumn(
                name: "ModifiedAt",
                schema: "GHIP",
                table: "RelationshipMasters");

            migrationBuilder.DropColumn(
                name: "CreatedAt",
                schema: "GHIP",
                table: "RegionMaster");

            migrationBuilder.DropColumn(
                name: "ModifiedAt",
                schema: "GHIP",
                table: "RegionMaster");

            migrationBuilder.DropColumn(
                name: "CreatedAt",
                schema: "GHIP",
                table: "PreEnrollmentPolicies");

            migrationBuilder.DropColumn(
                name: "ModifiedAt",
                schema: "GHIP",
                table: "PreEnrollmentPolicies");

            migrationBuilder.DropColumn(
                name: "CreatedAt",
                schema: "GHIP",
                table: "PreEnrollmentPeriods");

            migrationBuilder.DropColumn(
                name: "ModifiedAt",
                schema: "GHIP",
                table: "PreEnrollmentPeriods");

            migrationBuilder.DropColumn(
                name: "CreatedAt",
                schema: "GHIP",
                table: "PreEnrollmentMembers");

            migrationBuilder.DropColumn(
                name: "ModifiedAt",
                schema: "GHIP",
                table: "PreEnrollmentMembers");

            migrationBuilder.DropColumn(
                name: "CreatedAt",
                schema: "GHIP",
                table: "PolicyRelationshipMappings");

            migrationBuilder.DropColumn(
                name: "ModifiedAt",
                schema: "GHIP",
                table: "PolicyRelationshipMappings");

            migrationBuilder.DropColumn(
                name: "CreatedAt",
                schema: "GHIP",
                table: "PolicyFieldMappings");

            migrationBuilder.DropColumn(
                name: "ModifiedAt",
                schema: "GHIP",
                table: "PolicyFieldMappings");

            migrationBuilder.DropColumn(
                name: "CreatedAt",
                schema: "GHIP",
                table: "FieldMasters");

            migrationBuilder.DropColumn(
                name: "ModifiedAt",
                schema: "GHIP",
                table: "FieldMasters");

            migrationBuilder.DropColumn(
                name: "CreatedAt",
                schema: "GHIP",
                table: "EmailTemplates");

            migrationBuilder.DropColumn(
                name: "ModifiedAt",
                schema: "GHIP",
                table: "EmailTemplates");

            migrationBuilder.DropColumn(
                name: "CreatedAt",
                schema: "GHIP",
                table: "DistrictMaster");

            migrationBuilder.DropColumn(
                name: "ModifiedAt",
                schema: "GHIP",
                table: "DistrictMaster");

            migrationBuilder.DropColumn(
                name: "CreatedAt",
                schema: "GHIP",
                table: "Corporates");

            migrationBuilder.DropColumn(
                name: "ModifiedAt",
                schema: "GHIP",
                table: "Corporates");

            migrationBuilder.DropColumn(
                name: "CreatedAt",
                schema: "GHIP",
                table: "CityOrVillageMaster");

            migrationBuilder.DropColumn(
                name: "ModifiedAt",
                schema: "GHIP",
                table: "CityOrVillageMaster");

            migrationBuilder.DropColumn(
                name: "CreatedAt",
                schema: "GHIP",
                table: "AreaMaster");

            migrationBuilder.DropColumn(
                name: "ModifiedAt",
                schema: "GHIP",
                table: "AreaMaster");

            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedAtUtc",
                schema: "GHIP",
                table: "Users",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "ModifiedAtUtc",
                schema: "GHIP",
                table: "Users",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedAtUtc",
                schema: "GHIP",
                table: "StateMaster",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "ModifiedAtUtc",
                schema: "GHIP",
                table: "StateMaster",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedAtUtc",
                schema: "GHIP",
                table: "Roles",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "ModifiedAtUtc",
                schema: "GHIP",
                table: "Roles",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedAtUtc",
                schema: "GHIP",
                table: "RelationshipMasters",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "ModifiedAtUtc",
                schema: "GHIP",
                table: "RelationshipMasters",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedAtUtc",
                schema: "GHIP",
                table: "RegionMaster",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "ModifiedAtUtc",
                schema: "GHIP",
                table: "RegionMaster",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedAtUtc",
                schema: "GHIP",
                table: "PreEnrollmentPolicies",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "ModifiedAtUtc",
                schema: "GHIP",
                table: "PreEnrollmentPolicies",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedAtUtc",
                schema: "GHIP",
                table: "PreEnrollmentPeriods",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "ModifiedAtUtc",
                schema: "GHIP",
                table: "PreEnrollmentPeriods",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedAtUtc",
                schema: "GHIP",
                table: "PreEnrollmentMembers",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "ModifiedAtUtc",
                schema: "GHIP",
                table: "PreEnrollmentMembers",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedAtUtc",
                schema: "GHIP",
                table: "PolicyRelationshipMappings",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "ModifiedAtUtc",
                schema: "GHIP",
                table: "PolicyRelationshipMappings",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedAtUtc",
                schema: "GHIP",
                table: "PolicyFieldMappings",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "ModifiedAtUtc",
                schema: "GHIP",
                table: "PolicyFieldMappings",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedAtUtc",
                schema: "GHIP",
                table: "FieldMasters",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "ModifiedAtUtc",
                schema: "GHIP",
                table: "FieldMasters",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedAtUtc",
                schema: "GHIP",
                table: "EmailTemplates",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "ModifiedAtUtc",
                schema: "GHIP",
                table: "EmailTemplates",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedAtUtc",
                schema: "GHIP",
                table: "DistrictMaster",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "ModifiedAtUtc",
                schema: "GHIP",
                table: "DistrictMaster",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedAtUtc",
                schema: "GHIP",
                table: "Corporates",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "ModifiedAtUtc",
                schema: "GHIP",
                table: "Corporates",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedAtUtc",
                schema: "GHIP",
                table: "CityOrVillageMaster",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "ModifiedAtUtc",
                schema: "GHIP",
                table: "CityOrVillageMaster",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedAtUtc",
                schema: "GHIP",
                table: "AreaMaster",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "ModifiedAtUtc",
                schema: "GHIP",
                table: "AreaMaster",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));
        }
    }
}
