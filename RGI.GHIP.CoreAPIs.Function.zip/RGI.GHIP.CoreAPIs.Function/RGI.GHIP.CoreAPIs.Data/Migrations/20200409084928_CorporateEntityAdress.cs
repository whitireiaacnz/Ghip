﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RGI.GHIP.CoreAPIs.Data.Migrations
{
    public partial class CorporateEntityAdress : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "LogoUrl",
                schema: "GHIP",
                table: "Corporates");

            migrationBuilder.AddColumn<string>(
                name: "Area",
                schema: "GHIP",
                table: "Corporates",
                maxLength: 256,
                nullable: false,
                defaultValue: string.Empty);

            migrationBuilder.AddColumn<string>(
                name: "District",
                schema: "GHIP",
                table: "Corporates",
                maxLength: 256,
                nullable: false,
                defaultValue: string.Empty);

            migrationBuilder.AddColumn<string>(
                name: "EmailId",
                schema: "GHIP",
                table: "Corporates",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Area",
                schema: "GHIP",
                table: "Corporates");

            migrationBuilder.DropColumn(
                name: "District",
                schema: "GHIP",
                table: "Corporates");

            migrationBuilder.DropColumn(
                name: "EmailId",
                schema: "GHIP",
                table: "Corporates");

            migrationBuilder.AddColumn<string>(
                name: "LogoUrl",
                schema: "GHIP",
                table: "Corporates",
                type: "nvarchar(512)",
                maxLength: 512,
                nullable: true);
        }
    }
}
