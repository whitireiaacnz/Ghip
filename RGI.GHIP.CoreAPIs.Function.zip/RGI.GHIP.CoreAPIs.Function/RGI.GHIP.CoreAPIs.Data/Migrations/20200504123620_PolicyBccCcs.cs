﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RGI.GHIP.CoreAPIs.Data.Migrations
{
    public partial class PolicyBccCcs : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "RegistrationConfirmationEmailBccs",
                schema: "GHIP",
                table: "PreEnrollmentPolicies",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "RegistrationConfirmationEmailCcs",
                schema: "GHIP",
                table: "PreEnrollmentPolicies",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "RegistrationConfirmationEmailBccs",
                schema: "GHIP",
                table: "PreEnrollmentPolicies");

            migrationBuilder.DropColumn(
                name: "RegistrationConfirmationEmailCcs",
                schema: "GHIP",
                table: "PreEnrollmentPolicies");
        }
    }
}
