﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RGI.GHIP.CoreAPIs.Data.Migrations
{
    public partial class UpdatedHRMemberMapping : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Members_HRMapping_CPHRMappingEntityId",
                schema: "GhipCP",
                table: "Members");

            migrationBuilder.DropIndex(
                name: "IX_Members_CPHRMappingEntityId",
                schema: "GhipCP",
                table: "Members");

            migrationBuilder.DropColumn(
                name: "CPHRMappingEntityId",
                schema: "GhipCP",
                table: "Members");

            migrationBuilder.DropColumn(
                name: "HRId",
                schema: "GhipCP",
                table: "HRMapping");

            migrationBuilder.AddColumn<int>(
                name: "EmployeesId",
                schema: "GhipCP",
                table: "HRMapping",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "HRMemberId",
                schema: "GhipCP",
                table: "HRMapping",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_HRMapping_EmployeesId",
                schema: "GhipCP",
                table: "HRMapping",
                column: "EmployeesId");

            migrationBuilder.AddForeignKey(
                name: "FK_HRMapping_Members_EmployeesId",
                schema: "GhipCP",
                table: "HRMapping",
                column: "EmployeesId",
                principalSchema: "GhipCP",
                principalTable: "Members",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_HRMapping_Members_EmployeesId",
                schema: "GhipCP",
                table: "HRMapping");

            migrationBuilder.DropIndex(
                name: "IX_HRMapping_EmployeesId",
                schema: "GhipCP",
                table: "HRMapping");

            migrationBuilder.DropColumn(
                name: "EmployeesId",
                schema: "GhipCP",
                table: "HRMapping");

            migrationBuilder.DropColumn(
                name: "HRMemberId",
                schema: "GhipCP",
                table: "HRMapping");

            migrationBuilder.AddColumn<int>(
                name: "CPHRMappingEntityId",
                schema: "GhipCP",
                table: "Members",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "HRId",
                schema: "GhipCP",
                table: "HRMapping",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Members_CPHRMappingEntityId",
                schema: "GhipCP",
                table: "Members",
                column: "CPHRMappingEntityId");

            migrationBuilder.AddForeignKey(
                name: "FK_Members_HRMapping_CPHRMappingEntityId",
                schema: "GhipCP",
                table: "Members",
                column: "CPHRMappingEntityId",
                principalSchema: "GhipCP",
                principalTable: "HRMapping",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
