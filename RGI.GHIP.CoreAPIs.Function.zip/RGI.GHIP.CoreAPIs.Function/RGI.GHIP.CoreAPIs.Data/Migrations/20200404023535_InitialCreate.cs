﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace RGI.GHIP.CoreAPIs.Data.Migrations
{
    public partial class InitialCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "GHIP");

            migrationBuilder.CreateTable(
                name: "Corporates",
                schema: "GHIP",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Key = table.Column<string>(maxLength: 8, nullable: true),
                    CreatedAtUtc = table.Column<DateTime>(nullable: false),
                    CreatedBy = table.Column<string>(nullable: true),
                    ModifiedAtUtc = table.Column<DateTime>(nullable: false),
                    ModifiedBy = table.Column<string>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false),
                    Name = table.Column<string>(maxLength: 256, nullable: false),
                    Code = table.Column<string>(maxLength: 8, nullable: false),
                    LogoUrl = table.Column<string>(maxLength: 512, nullable: true),
                    LogoImage = table.Column<string>(nullable: true),
                    AddressLine1 = table.Column<string>(maxLength: 256, nullable: true),
                    AddressLine2 = table.Column<string>(maxLength: 256, nullable: true),
                    Website = table.Column<string>(maxLength: 512, nullable: true),
                    City = table.Column<string>(maxLength: 256, nullable: false),
                    State = table.Column<string>(maxLength: 256, nullable: false),
                    Pincode = table.Column<string>(maxLength: 16, nullable: false),
                    ContactName = table.Column<string>(maxLength: 256, nullable: false),
                    MobileNo = table.Column<string>(maxLength: 16, nullable: true),
                    LandlineNo = table.Column<string>(maxLength: 16, nullable: true),
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Corporates", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "EmailTemplates",
                schema: "GHIP",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Key = table.Column<string>(maxLength: 8, nullable: true),
                    CreatedAtUtc = table.Column<DateTime>(nullable: false),
                    CreatedBy = table.Column<string>(nullable: true),
                    ModifiedAtUtc = table.Column<DateTime>(nullable: false),
                    ModifiedBy = table.Column<string>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false),
                    WelcomeEmailTemplate = table.Column<string>(nullable: true),
                    ConfirmationEmailTemplate = table.Column<string>(nullable: true),
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EmailTemplates", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "FieldMasters",
                schema: "GHIP",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Key = table.Column<string>(maxLength: 8, nullable: true),
                    CreatedAtUtc = table.Column<DateTime>(nullable: false),
                    CreatedBy = table.Column<string>(nullable: true),
                    ModifiedAtUtc = table.Column<DateTime>(nullable: false),
                    ModifiedBy = table.Column<string>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false),
                    Label = table.Column<string>(maxLength: 256, nullable: false),
                    IsEnabled = table.Column<bool>(nullable: false),
                    IsMandatoryForSelf = table.Column<bool>(nullable: false),
                    IsMandatoryForDependent = table.Column<bool>(nullable: false),
                    IsVisibleForSelf = table.Column<bool>(nullable: false),
                    IsVisibleForDependent = table.Column<bool>(nullable: false),
                    DataType = table.Column<string>(maxLength: 32, nullable: true),
                    IsConfigurable = table.Column<bool>(nullable: false),
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FieldMasters", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "RelationshipMasters",
                schema: "GHIP",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Key = table.Column<string>(maxLength: 8, nullable: true),
                    CreatedAtUtc = table.Column<DateTime>(nullable: false),
                    CreatedBy = table.Column<string>(nullable: true),
                    ModifiedAtUtc = table.Column<DateTime>(nullable: false),
                    ModifiedBy = table.Column<string>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false),
                    Label = table.Column<string>(maxLength: 256, nullable: false),
                    Type = table.Column<string>(maxLength: 256, nullable: false),
                    MinAgeLimit = table.Column<int>(nullable: false),
                    MaxAgeLimit = table.Column<int>(nullable: false),
                    IsConfigurable = table.Column<bool>(nullable: false),
                    Count = table.Column<int>(nullable: false),
                    IsEnabled = table.Column<bool>(nullable: false),
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RelationshipMasters", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Roles",
                schema: "GHIP",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Key = table.Column<string>(maxLength: 8, nullable: true),
                    CreatedAtUtc = table.Column<DateTime>(nullable: false),
                    CreatedBy = table.Column<string>(nullable: true),
                    ModifiedAtUtc = table.Column<DateTime>(nullable: false),
                    ModifiedBy = table.Column<string>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false),
                    RoleType = table.Column<string>(nullable: false),
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Roles", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "PreEnrollmentPolicies",
                schema: "GHIP",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Key = table.Column<string>(maxLength: 8, nullable: true),
                    CreatedAtUtc = table.Column<DateTime>(nullable: false),
                    CreatedBy = table.Column<string>(nullable: true),
                    ModifiedAtUtc = table.Column<DateTime>(nullable: false),
                    ModifiedBy = table.Column<string>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false),
                    CorporateId = table.Column<int>(nullable: false),
                    Year = table.Column<int>(nullable: false),
                    Name = table.Column<string>(nullable: false),
                    Plan = table.Column<string>(nullable: true),
                    TotalMembers = table.Column<int>(nullable: false),
                    MaxNumOfMembersPerFamily = table.Column<int>(nullable: false),
                    MaxNumOfChildrenAllowed = table.Column<int>(nullable: false),
                    AllowedSumInsured = table.Column<string>(nullable: false),
                    PasswordPolicy = table.Column<string>(maxLength: 32, nullable: false),
                    AllowEmployeeEditHisProfile = table.Column<bool>(nullable: false),
                    AllowEmployeeViewHisProfile = table.Column<bool>(nullable: false),
                    AllowHRResetProfile = table.Column<bool>(nullable: false),
                    AllowDeletingMember = table.Column<bool>(nullable: false),
                    ParentInLawCondition = table.Column<bool>(nullable: false),
                    AreTwinsAllowed = table.Column<bool>(nullable: false),
                    AreParentOptInAllowed = table.Column<bool>(nullable: false),
                    PSIType = table.Column<string>(maxLength: 32, nullable: true),
                    PSIValues = table.Column<string>(maxLength: 512, nullable: true),
                    IsPSIAllowed = table.Column<bool>(nullable: false),
                    IsESIAllowed = table.Column<bool>(nullable: false),
                    PSIPlan = table.Column<string>(nullable: true),
                    ESIType = table.Column<string>(maxLength: 32, nullable: true),
                    ESIValues = table.Column<string>(maxLength: 512, nullable: true),
                    ESIPlan = table.Column<string>(nullable: true),
                    PSIInstructions = table.Column<string>(nullable: true),
                    TopupInstructions = table.Column<string>(nullable: true),
                    ESIInstructions = table.Column<string>(nullable: true),
                    IsTopupAllowed = table.Column<bool>(nullable: false),
                    TopupType = table.Column<string>(maxLength: 32, nullable: true),
                    TopupValues = table.Column<string>(maxLength: 512, nullable: true),
                    TopUpPlan = table.Column<string>(nullable: true),
                    SendWelcomeEmail = table.Column<bool>(nullable: false),
                    WelcomeEmailDate = table.Column<DateTime>(nullable: false),
                    WelcomeEmailHrs = table.Column<int>(nullable: false),
                    WelcomeEmailMin = table.Column<int>(nullable: false),
                    WelcomeEmailTemplate = table.Column<string>(nullable: true),
                    SendConfirmationEmail = table.Column<bool>(nullable: false),
                    ConfirmationEmailTemplate = table.Column<string>(nullable: true),
                    StartDate = table.Column<DateTime>(nullable: false),
                    EndDate = table.Column<DateTime>(nullable: false),
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PreEnrollmentPolicies", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PreEnrollmentPolicies_Corporates_CorporateId",
                        column: x => x.CorporateId,
                        principalSchema: "GHIP",
                        principalTable: "Corporates",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Users",
                schema: "GHIP",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Key = table.Column<string>(maxLength: 8, nullable: true),
                    CreatedAtUtc = table.Column<DateTime>(nullable: false),
                    CreatedBy = table.Column<string>(nullable: true),
                    ModifiedAtUtc = table.Column<DateTime>(nullable: false),
                    ModifiedBy = table.Column<string>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false),
                    IdentityServiceUserId = table.Column<string>(nullable: false),
                    UserName = table.Column<string>(nullable: false),
                    RoleId = table.Column<int>(nullable: false),
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Users_Roles_RoleId",
                        column: x => x.RoleId,
                        principalSchema: "GHIP",
                        principalTable: "Roles",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "PolicyFieldMappings",
                schema: "GHIP",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Key = table.Column<string>(maxLength: 8, nullable: true),
                    CreatedAtUtc = table.Column<DateTime>(nullable: false),
                    CreatedBy = table.Column<string>(nullable: true),
                    ModifiedAtUtc = table.Column<DateTime>(nullable: false),
                    ModifiedBy = table.Column<string>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false),
                    PreEnrollmentPolicyId = table.Column<int>(nullable: false),
                    FieldMasterId = table.Column<int>(nullable: false),
                    IsMandatoryForSelf = table.Column<bool>(nullable: false),
                    IsVisibleForSelf = table.Column<bool>(nullable: false),
                    IsMandatoryForDependent = table.Column<bool>(nullable: false),
                    IsVisibleForDependent = table.Column<bool>(nullable: false),
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PolicyFieldMappings", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PolicyFieldMappings_FieldMasters_FieldMasterId",
                        column: x => x.FieldMasterId,
                        principalSchema: "GHIP",
                        principalTable: "FieldMasters",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_PolicyFieldMappings_PreEnrollmentPolicies_PreEnrollmentPolicyId",
                        column: x => x.PreEnrollmentPolicyId,
                        principalSchema: "GHIP",
                        principalTable: "PreEnrollmentPolicies",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "PolicyRelationshipMappings",
                schema: "GHIP",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Key = table.Column<string>(maxLength: 8, nullable: true),
                    CreatedAtUtc = table.Column<DateTime>(nullable: false),
                    CreatedBy = table.Column<string>(nullable: true),
                    ModifiedAtUtc = table.Column<DateTime>(nullable: false),
                    ModifiedBy = table.Column<string>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false),
                    PreEnrollmentPolicyId = table.Column<int>(nullable: false),
                    RelationshipMasterId = table.Column<int>(nullable: false),
                    MinAgeLimit = table.Column<int>(nullable: false),
                    MaxAgeLimit = table.Column<int>(nullable: false),
                    Count = table.Column<int>(nullable: false),
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PolicyRelationshipMappings", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PolicyRelationshipMappings_PreEnrollmentPolicies_PreEnrollmentPolicyId",
                        column: x => x.PreEnrollmentPolicyId,
                        principalSchema: "GHIP",
                        principalTable: "PreEnrollmentPolicies",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_PolicyRelationshipMappings_RelationshipMasters_RelationshipMasterId",
                        column: x => x.RelationshipMasterId,
                        principalSchema: "GHIP",
                        principalTable: "RelationshipMasters",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "PreEnrollmentMembers",
                schema: "GHIP",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Key = table.Column<string>(maxLength: 8, nullable: true),
                    CreatedAtUtc = table.Column<DateTime>(nullable: false),
                    CreatedBy = table.Column<string>(nullable: true),
                    ModifiedAtUtc = table.Column<DateTime>(nullable: false),
                    ModifiedBy = table.Column<string>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false),
                    PreEnrollmentPolicyId = table.Column<int>(nullable: false),
                    RelationshipMasterId = table.Column<int>(nullable: false),
                    EmpId = table.Column<string>(maxLength: 128, nullable: false),
                    InsuredName = table.Column<string>(maxLength: 256, nullable: false),
                    Grade = table.Column<string>(maxLength: 32, nullable: true),
                    SumInsured = table.Column<int>(nullable: false),
                    PSI = table.Column<int>(nullable: false),
                    ESI = table.Column<int>(nullable: false),
                    Topup = table.Column<int>(nullable: false),
                    DateOfBirth = table.Column<DateTime>(type: "DateTime2", nullable: false),
                    Age = table.Column<int>(nullable: false),
                    Gender = table.Column<string>(maxLength: 8, nullable: true),
                    MobileNumber = table.Column<string>(maxLength: 16, nullable: true),
                    EmailAddress = table.Column<string>(maxLength: 64, nullable: true),
                    WelcomeEmailErrorReason = table.Column<string>(nullable: true),
                    WelcomeEmailSentTrials = table.Column<int>(nullable: false),
                    IsWelcomeEmailSent = table.Column<bool>(nullable: false),
                    OtherFieldsJson = table.Column<string>(nullable: true),
                    FieldsJson = table.Column<string>(nullable: true),
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PreEnrollmentMembers", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PreEnrollmentMembers_PreEnrollmentPolicies_PreEnrollmentPolicyId",
                        column: x => x.PreEnrollmentPolicyId,
                        principalSchema: "GHIP",
                        principalTable: "PreEnrollmentPolicies",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_PreEnrollmentMembers_RelationshipMasters_RelationshipMasterId",
                        column: x => x.RelationshipMasterId,
                        principalSchema: "GHIP",
                        principalTable: "RelationshipMasters",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "PreEnrollmentPeriods",
                schema: "GHIP",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Key = table.Column<string>(maxLength: 8, nullable: true),
                    CreatedAtUtc = table.Column<DateTime>(nullable: false),
                    CreatedBy = table.Column<string>(nullable: true),
                    ModifiedAtUtc = table.Column<DateTime>(nullable: false),
                    ModifiedBy = table.Column<string>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false),
                    PreEnrollmentPolicyId = table.Column<int>(nullable: false),
                    StartDateTime = table.Column<DateTime>(nullable: false),
                    EndDateTime = table.Column<DateTime>(nullable: false),
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PreEnrollmentPeriods", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PreEnrollmentPeriods_PreEnrollmentPolicies_PreEnrollmentPolicyId",
                        column: x => x.PreEnrollmentPolicyId,
                        principalSchema: "GHIP",
                        principalTable: "PreEnrollmentPolicies",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_PolicyFieldMappings_FieldMasterId",
                schema: "GHIP",
                table: "PolicyFieldMappings",
                column: "FieldMasterId");

            migrationBuilder.CreateIndex(
                name: "IX_PolicyFieldMappings_PreEnrollmentPolicyId",
                schema: "GHIP",
                table: "PolicyFieldMappings",
                column: "PreEnrollmentPolicyId");

            migrationBuilder.CreateIndex(
                name: "IX_PolicyRelationshipMappings_PreEnrollmentPolicyId",
                schema: "GHIP",
                table: "PolicyRelationshipMappings",
                column: "PreEnrollmentPolicyId");

            migrationBuilder.CreateIndex(
                name: "IX_PolicyRelationshipMappings_RelationshipMasterId",
                schema: "GHIP",
                table: "PolicyRelationshipMappings",
                column: "RelationshipMasterId");

            migrationBuilder.CreateIndex(
                name: "IX_PreEnrollmentMembers_PreEnrollmentPolicyId",
                schema: "GHIP",
                table: "PreEnrollmentMembers",
                column: "PreEnrollmentPolicyId");

            migrationBuilder.CreateIndex(
                name: "IX_PreEnrollmentMembers_RelationshipMasterId",
                schema: "GHIP",
                table: "PreEnrollmentMembers",
                column: "RelationshipMasterId");

            migrationBuilder.CreateIndex(
                name: "IX_PreEnrollmentPeriods_PreEnrollmentPolicyId",
                schema: "GHIP",
                table: "PreEnrollmentPeriods",
                column: "PreEnrollmentPolicyId");

            migrationBuilder.CreateIndex(
                name: "IX_PreEnrollmentPolicies_CorporateId",
                schema: "GHIP",
                table: "PreEnrollmentPolicies",
                column: "CorporateId");

            migrationBuilder.CreateIndex(
                name: "IX_Users_RoleId",
                schema: "GHIP",
                table: "Users",
                column: "RoleId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "EmailTemplates",
                schema: "GHIP");

            migrationBuilder.DropTable(
                name: "PolicyFieldMappings",
                schema: "GHIP");

            migrationBuilder.DropTable(
                name: "PolicyRelationshipMappings",
                schema: "GHIP");

            migrationBuilder.DropTable(
                name: "PreEnrollmentMembers",
                schema: "GHIP");

            migrationBuilder.DropTable(
                name: "PreEnrollmentPeriods",
                schema: "GHIP");

            migrationBuilder.DropTable(
                name: "Users",
                schema: "GHIP");

            migrationBuilder.DropTable(
                name: "FieldMasters",
                schema: "GHIP");

            migrationBuilder.DropTable(
                name: "RelationshipMasters",
                schema: "GHIP");

            migrationBuilder.DropTable(
                name: "PreEnrollmentPolicies",
                schema: "GHIP");

            migrationBuilder.DropTable(
                name: "Roles",
                schema: "GHIP");

            migrationBuilder.DropTable(
                name: "Corporates",
                schema: "GHIP");
        }
    }
}
