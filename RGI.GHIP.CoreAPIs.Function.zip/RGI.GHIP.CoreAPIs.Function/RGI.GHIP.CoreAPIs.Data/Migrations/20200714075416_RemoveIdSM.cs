﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RGI.GHIP.CoreAPIs.Data.Migrations
{
    public partial class RemoveIdSM : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_SMPolicyMapping_SMMaster_SMId",
                schema: "GhipCP",
                table: "SMPolicyMapping");

            migrationBuilder.DropPrimaryKey(
                name: "PK_SMMaster",
                schema: "GhipGlobal",
                table: "SMMaster");

            migrationBuilder.DropPrimaryKey(
                name: "PK_SMPolicyMapping",
                schema: "GhipCP",
                table: "SMPolicyMapping");

            migrationBuilder.DropIndex(
                name: "IX_SMPolicyMapping_SMId",
                schema: "GhipCP",
                table: "SMPolicyMapping");

            migrationBuilder.DropColumn(
                name: "Id",
                schema: "GhipGlobal",
                table: "SMMaster");

            migrationBuilder.DropColumn(
                name: "Id",
                schema: "GhipCP",
                table: "SMPolicyMapping");

            migrationBuilder.DropColumn(
                name: "SMId",
                schema: "GhipCP",
                table: "SMPolicyMapping");

            migrationBuilder.AddPrimaryKey(
                name: "PK_SMMaster",
                schema: "GhipGlobal",
                table: "SMMaster",
                column: "GId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_SMPolicyMapping",
                schema: "GhipCP",
                table: "SMPolicyMapping",
                column: "GId");

            migrationBuilder.CreateIndex(
                name: "IX_SMPolicyMapping_SMGId",
                schema: "GhipCP",
                table: "SMPolicyMapping",
                column: "SMGId");

            migrationBuilder.AddForeignKey(
                name: "FK_SMPolicyMapping_SMMaster_SMGId",
                schema: "GhipCP",
                table: "SMPolicyMapping",
                column: "SMGId",
                principalSchema: "GhipGlobal",
                principalTable: "SMMaster",
                principalColumn: "GId",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_SMPolicyMapping_SMMaster_SMGId",
                schema: "GhipCP",
                table: "SMPolicyMapping");

            migrationBuilder.DropPrimaryKey(
                name: "PK_SMMaster",
                schema: "GhipGlobal",
                table: "SMMaster");

            migrationBuilder.DropPrimaryKey(
                name: "PK_SMPolicyMapping",
                schema: "GhipCP",
                table: "SMPolicyMapping");

            migrationBuilder.DropIndex(
                name: "IX_SMPolicyMapping_SMGId",
                schema: "GhipCP",
                table: "SMPolicyMapping");

            migrationBuilder.AddColumn<int>(
                name: "Id",
                schema: "GhipGlobal",
                table: "SMMaster",
                type: "int",
                nullable: false,
                defaultValue: 0)
                .Annotation("SqlServer:Identity", "1, 1");

            migrationBuilder.AddColumn<int>(
                name: "Id",
                schema: "GhipCP",
                table: "SMPolicyMapping",
                type: "int",
                nullable: false,
                defaultValue: 0)
                .Annotation("SqlServer:Identity", "1, 1");

            migrationBuilder.AddColumn<int>(
                name: "SMId",
                schema: "GhipCP",
                table: "SMPolicyMapping",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddPrimaryKey(
                name: "PK_SMMaster",
                schema: "GhipGlobal",
                table: "SMMaster",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_SMPolicyMapping",
                schema: "GhipCP",
                table: "SMPolicyMapping",
                column: "Id");

            migrationBuilder.CreateIndex(
                name: "IX_SMPolicyMapping_SMId",
                schema: "GhipCP",
                table: "SMPolicyMapping",
                column: "SMId");

            migrationBuilder.AddForeignKey(
                name: "FK_SMPolicyMapping_SMMaster_SMId",
                schema: "GhipCP",
                table: "SMPolicyMapping",
                column: "SMId",
                principalSchema: "GhipGlobal",
                principalTable: "SMMaster",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
