﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RGI.GHIP.CoreAPIs.Data.Migrations
{
    public partial class UpdatedPolicyEntity2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ProductType",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.AlterColumn<bool>(
                name: "IsDependentCovered",
                schema: "GhipCP",
                table: "Policy",
                nullable: true,
                oldClrType: typeof(bool),
                oldType: "bit");

            migrationBuilder.AlterColumn<int>(
                name: "FamilySize",
                schema: "GhipCP",
                table: "Policy",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AlterColumn<int>(
                name: "BranchId",
                schema: "GhipCP",
                table: "Policy",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddColumn<string>(
                name: "PolicyType",
                schema: "GhipCP",
                table: "Policy",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "PolicyType",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.AlterColumn<bool>(
                name: "IsDependentCovered",
                schema: "GhipCP",
                table: "Policy",
                type: "bit",
                nullable: false,
                oldClrType: typeof(bool),
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "FamilySize",
                schema: "GhipCP",
                table: "Policy",
                type: "int",
                nullable: false,
                oldClrType: typeof(int),
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "BranchId",
                schema: "GhipCP",
                table: "Policy",
                type: "int",
                nullable: false,
                oldClrType: typeof(int),
                oldNullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ProductType",
                schema: "GhipCP",
                table: "Policy",
                type: "nvarchar(max)",
                nullable: true);
        }
    }
}
