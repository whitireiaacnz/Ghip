﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RGI.GHIP.CoreAPIs.Data.Migrations
{
    public partial class UpdatedHRMemberMapping1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_HRMapping_Members_EmployeesId",
                schema: "GhipCP",
                table: "HRMapping");

            migrationBuilder.DropIndex(
                name: "IX_HRMapping_EmployeesId",
                schema: "GhipCP",
                table: "HRMapping");

            migrationBuilder.DropColumn(
                name: "EmployeesId",
                schema: "GhipCP",
                table: "HRMapping");

            migrationBuilder.DropColumn(
                name: "HRMemberId",
                schema: "GhipCP",
                table: "HRMapping");

            migrationBuilder.AddColumn<int>(
                name: "MemberId",
                schema: "GhipCP",
                table: "HRMapping",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_HRMapping_MemberId",
                schema: "GhipCP",
                table: "HRMapping",
                column: "MemberId");

            migrationBuilder.AddForeignKey(
                name: "FK_HRMapping_Members_MemberId",
                schema: "GhipCP",
                table: "HRMapping",
                column: "MemberId",
                principalSchema: "GhipCP",
                principalTable: "Members",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_HRMapping_Members_MemberId",
                schema: "GhipCP",
                table: "HRMapping");

            migrationBuilder.DropIndex(
                name: "IX_HRMapping_MemberId",
                schema: "GhipCP",
                table: "HRMapping");

            migrationBuilder.DropColumn(
                name: "MemberId",
                schema: "GhipCP",
                table: "HRMapping");

            migrationBuilder.AddColumn<int>(
                name: "EmployeesId",
                schema: "GhipCP",
                table: "HRMapping",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "HRMemberId",
                schema: "GhipCP",
                table: "HRMapping",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_HRMapping_EmployeesId",
                schema: "GhipCP",
                table: "HRMapping",
                column: "EmployeesId");

            migrationBuilder.AddForeignKey(
                name: "FK_HRMapping_Members_EmployeesId",
                schema: "GhipCP",
                table: "HRMapping",
                column: "EmployeesId",
                principalSchema: "GhipCP",
                principalTable: "Members",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
