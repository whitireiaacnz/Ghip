﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace RGI.GHIP.CoreAPIs.Data.Migrations
{
    public partial class UpdatedGuidAsKey : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_BrokerPolicyMapping_BrokerMaster_BrokerId",
                schema: "GhipCP",
                table: "BrokerPolicyMapping");

            migrationBuilder.DropForeignKey(
                name: "FK_BrokerPolicyMapping_Policy_CPPolicyId",
                schema: "GhipCP",
                table: "BrokerPolicyMapping");

            migrationBuilder.DropForeignKey(
                name: "FK_HRMapping_Members_MemberId",
                schema: "GhipCP",
                table: "HRMapping");

            migrationBuilder.DropForeignKey(
                name: "FK_Members_Policy_CPPolicyId",
                schema: "GhipCP",
                table: "Members");

            migrationBuilder.DropForeignKey(
                name: "FK_PolicyMemberFeatures_Policy_PolicyId",
                schema: "GhipCP",
                table: "PolicyMemberFeatures");

            migrationBuilder.DropForeignKey(
                name: "FK_SMPolicyMapping_Policy_CPPolicyId",
                schema: "GhipCP",
                table: "SMPolicyMapping");

            migrationBuilder.DropPrimaryKey(
                name: "PK_BrokerMaster",
                schema: "GhipGlobal",
                table: "BrokerMaster");

            migrationBuilder.DropIndex(
                name: "IX_SMPolicyMapping_CPPolicyId",
                schema: "GhipCP",
                table: "SMPolicyMapping");

            migrationBuilder.DropPrimaryKey(
                name: "PK_PolicyMemberFeatures",
                schema: "GhipCP",
                table: "PolicyMemberFeatures");

            migrationBuilder.DropIndex(
                name: "IX_PolicyMemberFeatures_PolicyId",
                schema: "GhipCP",
                table: "PolicyMemberFeatures");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Policy",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Members",
                schema: "GhipCP",
                table: "Members");

            migrationBuilder.DropIndex(
                name: "IX_Members_CPPolicyId",
                schema: "GhipCP",
                table: "Members");

            migrationBuilder.DropPrimaryKey(
                name: "PK_HRMapping",
                schema: "GhipCP",
                table: "HRMapping");

            migrationBuilder.DropIndex(
                name: "IX_HRMapping_MemberId",
                schema: "GhipCP",
                table: "HRMapping");

            migrationBuilder.DropPrimaryKey(
                name: "PK_BrokerPolicyMapping",
                schema: "GhipCP",
                table: "BrokerPolicyMapping");

            migrationBuilder.DropIndex(
                name: "IX_BrokerPolicyMapping_BrokerId",
                schema: "GhipCP",
                table: "BrokerPolicyMapping");

            migrationBuilder.DropIndex(
                name: "IX_BrokerPolicyMapping_CPPolicyId",
                schema: "GhipCP",
                table: "BrokerPolicyMapping");

            migrationBuilder.DropColumn(
                name: "CPPolicyId",
                schema: "GhipCP",
                table: "SMPolicyMapping");

            migrationBuilder.DropColumn(
                name: "PolicyId",
                schema: "GhipCP",
                table: "PolicyMemberFeatures");

            migrationBuilder.DropColumn(
                name: "CPPolicyId",
                schema: "GhipCP",
                table: "Members");

            migrationBuilder.DropColumn(
                name: "MemberId",
                schema: "GhipCP",
                table: "HRMapping");

            migrationBuilder.DropColumn(
                name: "BrokerId",
                schema: "GhipCP",
                table: "BrokerPolicyMapping");

            migrationBuilder.DropColumn(
                name: "CPPolicyId",
                schema: "GhipCP",
                table: "BrokerPolicyMapping");

            migrationBuilder.AddColumn<Guid>(
                name: "CPPolicyGId",
                schema: "GhipCP",
                table: "SMPolicyMapping",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "CPPolicyGId",
                schema: "GhipCP",
                table: "Members",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "CPPolicyGId",
                schema: "GhipCP",
                table: "BrokerPolicyMapping",
                nullable: true);

            migrationBuilder.AddPrimaryKey(
                name: "PK_BrokerMaster",
                schema: "GhipGlobal",
                table: "BrokerMaster",
                column: "GId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_PolicyMemberFeatures",
                schema: "GhipCP",
                table: "PolicyMemberFeatures",
                column: "GId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Policy",
                schema: "GhipCP",
                table: "Policy",
                column: "GId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Members",
                schema: "GhipCP",
                table: "Members",
                column: "GId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_HRMapping",
                schema: "GhipCP",
                table: "HRMapping",
                column: "GId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_BrokerPolicyMapping",
                schema: "GhipCP",
                table: "BrokerPolicyMapping",
                column: "GId");

            migrationBuilder.CreateIndex(
                name: "IX_SMPolicyMapping_CPPolicyGId",
                schema: "GhipCP",
                table: "SMPolicyMapping",
                column: "CPPolicyGId");

            migrationBuilder.CreateIndex(
                name: "IX_PolicyMemberFeatures_GCPPolicyId",
                schema: "GhipCP",
                table: "PolicyMemberFeatures",
                column: "GCPPolicyId");

            migrationBuilder.CreateIndex(
                name: "IX_Members_CPPolicyGId",
                schema: "GhipCP",
                table: "Members",
                column: "CPPolicyGId");

            migrationBuilder.CreateIndex(
                name: "IX_HRMapping_MemberGId",
                schema: "GhipCP",
                table: "HRMapping",
                column: "MemberGId");

            migrationBuilder.CreateIndex(
                name: "IX_BrokerPolicyMapping_CPPolicyGId",
                schema: "GhipCP",
                table: "BrokerPolicyMapping",
                column: "CPPolicyGId");

            migrationBuilder.CreateIndex(
                name: "IX_BrokerPolicyMapping_GBrokerId",
                schema: "GhipCP",
                table: "BrokerPolicyMapping",
                column: "GBrokerId");

            migrationBuilder.AddForeignKey(
                name: "FK_BrokerPolicyMapping_Policy_CPPolicyGId",
                schema: "GhipCP",
                table: "BrokerPolicyMapping",
                column: "CPPolicyGId",
                principalSchema: "GhipCP",
                principalTable: "Policy",
                principalColumn: "GId",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_BrokerPolicyMapping_BrokerMaster_GBrokerId",
                schema: "GhipCP",
                table: "BrokerPolicyMapping",
                column: "GBrokerId",
                principalSchema: "GhipGlobal",
                principalTable: "BrokerMaster",
                principalColumn: "GId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_HRMapping_Members_MemberGId",
                schema: "GhipCP",
                table: "HRMapping",
                column: "MemberGId",
                principalSchema: "GhipCP",
                principalTable: "Members",
                principalColumn: "GId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Members_Policy_CPPolicyGId",
                schema: "GhipCP",
                table: "Members",
                column: "CPPolicyGId",
                principalSchema: "GhipCP",
                principalTable: "Policy",
                principalColumn: "GId",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_PolicyMemberFeatures_Policy_GCPPolicyId",
                schema: "GhipCP",
                table: "PolicyMemberFeatures",
                column: "GCPPolicyId",
                principalSchema: "GhipCP",
                principalTable: "Policy",
                principalColumn: "GId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_SMPolicyMapping_Policy_CPPolicyGId",
                schema: "GhipCP",
                table: "SMPolicyMapping",
                column: "CPPolicyGId",
                principalSchema: "GhipCP",
                principalTable: "Policy",
                principalColumn: "GId",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_BrokerPolicyMapping_Policy_CPPolicyGId",
                schema: "GhipCP",
                table: "BrokerPolicyMapping");

            migrationBuilder.DropForeignKey(
                name: "FK_BrokerPolicyMapping_BrokerMaster_GBrokerId",
                schema: "GhipCP",
                table: "BrokerPolicyMapping");

            migrationBuilder.DropForeignKey(
                name: "FK_HRMapping_Members_MemberGId",
                schema: "GhipCP",
                table: "HRMapping");

            migrationBuilder.DropForeignKey(
                name: "FK_Members_Policy_CPPolicyGId",
                schema: "GhipCP",
                table: "Members");

            migrationBuilder.DropForeignKey(
                name: "FK_PolicyMemberFeatures_Policy_GCPPolicyId",
                schema: "GhipCP",
                table: "PolicyMemberFeatures");

            migrationBuilder.DropForeignKey(
                name: "FK_SMPolicyMapping_Policy_CPPolicyGId",
                schema: "GhipCP",
                table: "SMPolicyMapping");

            migrationBuilder.DropPrimaryKey(
                name: "PK_BrokerMaster",
                schema: "GhipGlobal",
                table: "BrokerMaster");

            migrationBuilder.DropIndex(
                name: "IX_SMPolicyMapping_CPPolicyGId",
                schema: "GhipCP",
                table: "SMPolicyMapping");

            migrationBuilder.DropPrimaryKey(
                name: "PK_PolicyMemberFeatures",
                schema: "GhipCP",
                table: "PolicyMemberFeatures");

            migrationBuilder.DropIndex(
                name: "IX_PolicyMemberFeatures_GCPPolicyId",
                schema: "GhipCP",
                table: "PolicyMemberFeatures");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Policy",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Members",
                schema: "GhipCP",
                table: "Members");

            migrationBuilder.DropIndex(
                name: "IX_Members_CPPolicyGId",
                schema: "GhipCP",
                table: "Members");

            migrationBuilder.DropPrimaryKey(
                name: "PK_HRMapping",
                schema: "GhipCP",
                table: "HRMapping");

            migrationBuilder.DropIndex(
                name: "IX_HRMapping_MemberGId",
                schema: "GhipCP",
                table: "HRMapping");

            migrationBuilder.DropPrimaryKey(
                name: "PK_BrokerPolicyMapping",
                schema: "GhipCP",
                table: "BrokerPolicyMapping");

            migrationBuilder.DropIndex(
                name: "IX_BrokerPolicyMapping_CPPolicyGId",
                schema: "GhipCP",
                table: "BrokerPolicyMapping");

            migrationBuilder.DropIndex(
                name: "IX_BrokerPolicyMapping_GBrokerId",
                schema: "GhipCP",
                table: "BrokerPolicyMapping");

            migrationBuilder.DropColumn(
                name: "CPPolicyGId",
                schema: "GhipCP",
                table: "SMPolicyMapping");

            migrationBuilder.DropColumn(
                name: "CPPolicyGId",
                schema: "GhipCP",
                table: "Members");

            migrationBuilder.DropColumn(
                name: "CPPolicyGId",
                schema: "GhipCP",
                table: "BrokerPolicyMapping");

            migrationBuilder.AddColumn<int>(
                name: "CPPolicyId",
                schema: "GhipCP",
                table: "SMPolicyMapping",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "PolicyId",
                schema: "GhipCP",
                table: "PolicyMemberFeatures",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "CPPolicyId",
                schema: "GhipCP",
                table: "Members",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "MemberId",
                schema: "GhipCP",
                table: "HRMapping",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "BrokerId",
                schema: "GhipCP",
                table: "BrokerPolicyMapping",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "CPPolicyId",
                schema: "GhipCP",
                table: "BrokerPolicyMapping",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddPrimaryKey(
                name: "PK_BrokerMaster",
                schema: "GhipGlobal",
                table: "BrokerMaster",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_PolicyMemberFeatures",
                schema: "GhipCP",
                table: "PolicyMemberFeatures",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Policy",
                schema: "GhipCP",
                table: "Policy",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Members",
                schema: "GhipCP",
                table: "Members",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_HRMapping",
                schema: "GhipCP",
                table: "HRMapping",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_BrokerPolicyMapping",
                schema: "GhipCP",
                table: "BrokerPolicyMapping",
                column: "Id");

            migrationBuilder.CreateIndex(
                name: "IX_SMPolicyMapping_CPPolicyId",
                schema: "GhipCP",
                table: "SMPolicyMapping",
                column: "CPPolicyId");

            migrationBuilder.CreateIndex(
                name: "IX_PolicyMemberFeatures_PolicyId",
                schema: "GhipCP",
                table: "PolicyMemberFeatures",
                column: "PolicyId");

            migrationBuilder.CreateIndex(
                name: "IX_Members_CPPolicyId",
                schema: "GhipCP",
                table: "Members",
                column: "CPPolicyId");

            migrationBuilder.CreateIndex(
                name: "IX_HRMapping_MemberId",
                schema: "GhipCP",
                table: "HRMapping",
                column: "MemberId");

            migrationBuilder.CreateIndex(
                name: "IX_BrokerPolicyMapping_BrokerId",
                schema: "GhipCP",
                table: "BrokerPolicyMapping",
                column: "BrokerId");

            migrationBuilder.CreateIndex(
                name: "IX_BrokerPolicyMapping_CPPolicyId",
                schema: "GhipCP",
                table: "BrokerPolicyMapping",
                column: "CPPolicyId");

            migrationBuilder.AddForeignKey(
                name: "FK_BrokerPolicyMapping_BrokerMaster_BrokerId",
                schema: "GhipCP",
                table: "BrokerPolicyMapping",
                column: "BrokerId",
                principalSchema: "GhipGlobal",
                principalTable: "BrokerMaster",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_BrokerPolicyMapping_Policy_CPPolicyId",
                schema: "GhipCP",
                table: "BrokerPolicyMapping",
                column: "CPPolicyId",
                principalSchema: "GhipCP",
                principalTable: "Policy",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_HRMapping_Members_MemberId",
                schema: "GhipCP",
                table: "HRMapping",
                column: "MemberId",
                principalSchema: "GhipCP",
                principalTable: "Members",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Members_Policy_CPPolicyId",
                schema: "GhipCP",
                table: "Members",
                column: "CPPolicyId",
                principalSchema: "GhipCP",
                principalTable: "Policy",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_PolicyMemberFeatures_Policy_PolicyId",
                schema: "GhipCP",
                table: "PolicyMemberFeatures",
                column: "PolicyId",
                principalSchema: "GhipCP",
                principalTable: "Policy",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_SMPolicyMapping_Policy_CPPolicyId",
                schema: "GhipCP",
                table: "SMPolicyMapping",
                column: "CPPolicyId",
                principalSchema: "GhipCP",
                principalTable: "Policy",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
