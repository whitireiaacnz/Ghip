﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RGI.GHIP.CoreAPIs.Data.Migrations
{
    public partial class UpdatedPolicyEntity : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "BranchId",
                schema: "GhipCP",
                table: "Policy",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "FamilySize",
                schema: "GhipCP",
                table: "Policy",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<bool>(
                name: "IsDependentCovered",
                schema: "GhipCP",
                table: "Policy",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<string>(
                name: "ProductCode",
                schema: "GhipCP",
                table: "Policy",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "BranchId",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropColumn(
                name: "FamilySize",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropColumn(
                name: "IsDependentCovered",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropColumn(
                name: "ProductCode",
                schema: "GhipCP",
                table: "Policy");
        }
    }
}
