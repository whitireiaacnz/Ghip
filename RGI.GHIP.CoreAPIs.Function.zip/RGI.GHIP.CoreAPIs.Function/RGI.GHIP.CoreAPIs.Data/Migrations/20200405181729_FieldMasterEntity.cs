﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RGI.GHIP.CoreAPIs.Data.Migrations
{
    public partial class FieldMasterEntity : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Section",
                schema: "GHIP",
                table: "FieldMasters",
                maxLength: 32,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Validation",
                schema: "GHIP",
                table: "FieldMasters",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Section",
                schema: "GHIP",
                table: "FieldMasters");

            migrationBuilder.DropColumn(
                name: "Validation",
                schema: "GHIP",
                table: "FieldMasters");
        }
    }
}
