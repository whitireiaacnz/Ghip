﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RGI.GHIP.CoreAPIs.Data.Migrations
{
    public partial class UpdatedHRMemberMapping2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "CorporateId",
                schema: "GhipCP",
                table: "HRMapping",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_HRMapping_CorporateId",
                schema: "GhipCP",
                table: "HRMapping",
                column: "CorporateId");

            migrationBuilder.AddForeignKey(
                name: "FK_HRMapping_Corporates_CorporateId",
                schema: "GhipCP",
                table: "HRMapping",
                column: "CorporateId",
                principalSchema: "GhipGlobal",
                principalTable: "Corporates",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_HRMapping_Corporates_CorporateId",
                schema: "GhipCP",
                table: "HRMapping");

            migrationBuilder.DropIndex(
                name: "IX_HRMapping_CorporateId",
                schema: "GhipCP",
                table: "HRMapping");

            migrationBuilder.DropColumn(
                name: "CorporateId",
                schema: "GhipCP",
                table: "HRMapping");
        }
    }
}
