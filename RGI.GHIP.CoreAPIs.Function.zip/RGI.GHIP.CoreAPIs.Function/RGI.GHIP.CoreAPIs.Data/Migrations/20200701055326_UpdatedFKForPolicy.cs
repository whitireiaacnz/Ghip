﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RGI.GHIP.CoreAPIs.Data.Migrations
{
    public partial class UpdatedFKForPolicy : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_BrokerPolicyMapping_Policy_CPPolicyId",
                schema: "GhipCP",
                table: "BrokerPolicyMapping");

            migrationBuilder.DropForeignKey(
                name: "FK_Members_Policy_CPPolicyId",
                schema: "GhipCP",
                table: "Members");

            migrationBuilder.DropForeignKey(
                name: "FK_SMPolicyMapping_Policy_CPPolicyId",
                schema: "GhipCP",
                table: "SMPolicyMapping");

            migrationBuilder.DropColumn(
                name: "CPPolicyAttachedId",
                schema: "GhipCP",
                table: "SMPolicyMapping");

            migrationBuilder.DropColumn(
                name: "CPPolicyAttachedId",
                schema: "GhipCP",
                table: "Members");

            migrationBuilder.DropColumn(
                name: "CPPolicyAttachedId",
                schema: "GhipCP",
                table: "BrokerPolicyMapping");

            migrationBuilder.AlterColumn<int>(
                name: "CPPolicyId",
                schema: "GhipCP",
                table: "SMPolicyMapping",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "CPPolicyId",
                schema: "GhipCP",
                table: "Members",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "CPPolicyId",
                schema: "GhipCP",
                table: "BrokerPolicyMapping",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_BrokerPolicyMapping_Policy_CPPolicyId",
                schema: "GhipCP",
                table: "BrokerPolicyMapping",
                column: "CPPolicyId",
                principalSchema: "GhipCP",
                principalTable: "Policy",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Members_Policy_CPPolicyId",
                schema: "GhipCP",
                table: "Members",
                column: "CPPolicyId",
                principalSchema: "GhipCP",
                principalTable: "Policy",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_SMPolicyMapping_Policy_CPPolicyId",
                schema: "GhipCP",
                table: "SMPolicyMapping",
                column: "CPPolicyId",
                principalSchema: "GhipCP",
                principalTable: "Policy",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_BrokerPolicyMapping_Policy_CPPolicyId",
                schema: "GhipCP",
                table: "BrokerPolicyMapping");

            migrationBuilder.DropForeignKey(
                name: "FK_Members_Policy_CPPolicyId",
                schema: "GhipCP",
                table: "Members");

            migrationBuilder.DropForeignKey(
                name: "FK_SMPolicyMapping_Policy_CPPolicyId",
                schema: "GhipCP",
                table: "SMPolicyMapping");

            migrationBuilder.AlterColumn<int>(
                name: "CPPolicyId",
                schema: "GhipCP",
                table: "SMPolicyMapping",
                type: "int",
                nullable: true,
                oldClrType: typeof(int));

            migrationBuilder.AddColumn<int>(
                name: "CPPolicyAttachedId",
                schema: "GhipCP",
                table: "SMPolicyMapping",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AlterColumn<int>(
                name: "CPPolicyId",
                schema: "GhipCP",
                table: "Members",
                type: "int",
                nullable: true,
                oldClrType: typeof(int));

            migrationBuilder.AddColumn<int>(
                name: "CPPolicyAttachedId",
                schema: "GhipCP",
                table: "Members",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AlterColumn<int>(
                name: "CPPolicyId",
                schema: "GhipCP",
                table: "BrokerPolicyMapping",
                type: "int",
                nullable: true,
                oldClrType: typeof(int));

            migrationBuilder.AddColumn<int>(
                name: "CPPolicyAttachedId",
                schema: "GhipCP",
                table: "BrokerPolicyMapping",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddForeignKey(
                name: "FK_BrokerPolicyMapping_Policy_CPPolicyId",
                schema: "GhipCP",
                table: "BrokerPolicyMapping",
                column: "CPPolicyId",
                principalSchema: "GhipCP",
                principalTable: "Policy",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Members_Policy_CPPolicyId",
                schema: "GhipCP",
                table: "Members",
                column: "CPPolicyId",
                principalSchema: "GhipCP",
                principalTable: "Policy",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_SMPolicyMapping_Policy_CPPolicyId",
                schema: "GhipCP",
                table: "SMPolicyMapping",
                column: "CPPolicyId",
                principalSchema: "GhipCP",
                principalTable: "Policy",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
