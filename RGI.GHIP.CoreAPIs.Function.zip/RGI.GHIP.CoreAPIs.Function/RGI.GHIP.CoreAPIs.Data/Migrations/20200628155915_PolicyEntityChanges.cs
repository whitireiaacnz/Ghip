﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace RGI.GHIP.CoreAPIs.Data.Migrations
{
    public partial class PolicyEntityChanges : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_BrokerPolicyMapping_PolicyAttached_CPPolicyId",
                schema: "GhipCP",
                table: "BrokerPolicyMapping");

            migrationBuilder.DropForeignKey(
                name: "FK_Employee_PolicyAttached_CPPolicyId",
                schema: "GhipCP",
                table: "Employee");

            migrationBuilder.DropForeignKey(
                name: "FK_SMPolicyMapping_PolicyAttached_CPPolicyId",
                schema: "GhipCP",
                table: "SMPolicyMapping");

            migrationBuilder.DropTable(
                name: "PolicyAttached",
                schema: "GhipCP");

            migrationBuilder.AddColumn<bool>(
                name: "AdditionOfDependents",
                schema: "GhipCP",
                table: "Policy",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "ConntactUs",
                schema: "GhipCP",
                table: "Policy",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "CorporateId",
                schema: "GhipCP",
                table: "Policy",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "DownloadForms",
                schema: "GhipCP",
                table: "Policy",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "FAQ",
                schema: "GhipCP",
                table: "Policy",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "GracePeriodType",
                schema: "GhipCP",
                table: "Policy",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "GracePeriodValue",
                schema: "GhipCP",
                table: "Policy",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "HRA",
                schema: "GhipCP",
                table: "Policy",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "HealthOPedia",
                schema: "GhipCP",
                table: "Policy",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "InsuredName",
                schema: "GhipCP",
                table: "Policy",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "IntimateClaims",
                schema: "GhipCP",
                table: "Policy",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "IssueDate",
                schema: "GhipCP",
                table: "Policy",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<bool>(
                name: "NetworkHospitalTracker",
                schema: "GhipCP",
                table: "Policy",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "PasswordType",
                schema: "GhipCP",
                table: "Policy",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "RHealthAssist",
                schema: "GhipCP",
                table: "Policy",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "RHealthBeat",
                schema: "GhipCP",
                table: "Policy",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "RHealthCircle",
                schema: "GhipCP",
                table: "Policy",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "RiskEndDate",
                schema: "GhipCP",
                table: "Policy",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "RiskStartDate",
                schema: "GhipCP",
                table: "Policy",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<bool>(
                name: "TrackClaims",
                schema: "GhipCP",
                table: "Policy",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "UserNameType",
                schema: "GhipCP",
                table: "Policy",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "ValueDeals",
                schema: "GhipCP",
                table: "Policy",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "ViewECard",
                schema: "GhipCP",
                table: "Policy",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "ViewPolicyCoverage",
                schema: "GhipCP",
                table: "Policy",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "Wellness",
                schema: "GhipCP",
                table: "Policy",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Policy_CorporateId",
                schema: "GhipCP",
                table: "Policy",
                column: "CorporateId");

            migrationBuilder.AddForeignKey(
                name: "FK_BrokerPolicyMapping_Policy_CPPolicyId",
                schema: "GhipCP",
                table: "BrokerPolicyMapping",
                column: "CPPolicyId",
                principalSchema: "GhipCP",
                principalTable: "Policy",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Employee_Policy_CPPolicyId",
                schema: "GhipCP",
                table: "Employee",
                column: "CPPolicyId",
                principalSchema: "GhipCP",
                principalTable: "Policy",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Policy_Corporates_CorporateId",
                schema: "GhipCP",
                table: "Policy",
                column: "CorporateId",
                principalSchema: "GhipGlobal",
                principalTable: "Corporates",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_SMPolicyMapping_Policy_CPPolicyId",
                schema: "GhipCP",
                table: "SMPolicyMapping",
                column: "CPPolicyId",
                principalSchema: "GhipCP",
                principalTable: "Policy",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_BrokerPolicyMapping_Policy_CPPolicyId",
                schema: "GhipCP",
                table: "BrokerPolicyMapping");

            migrationBuilder.DropForeignKey(
                name: "FK_Employee_Policy_CPPolicyId",
                schema: "GhipCP",
                table: "Employee");

            migrationBuilder.DropForeignKey(
                name: "FK_Policy_Corporates_CorporateId",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropForeignKey(
                name: "FK_SMPolicyMapping_Policy_CPPolicyId",
                schema: "GhipCP",
                table: "SMPolicyMapping");

            migrationBuilder.DropIndex(
                name: "IX_Policy_CorporateId",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropColumn(
                name: "AdditionOfDependents",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropColumn(
                name: "ConntactUs",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropColumn(
                name: "CorporateId",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropColumn(
                name: "DownloadForms",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropColumn(
                name: "FAQ",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropColumn(
                name: "GracePeriodType",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropColumn(
                name: "GracePeriodValue",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropColumn(
                name: "HRA",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropColumn(
                name: "HealthOPedia",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropColumn(
                name: "InsuredName",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropColumn(
                name: "IntimateClaims",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropColumn(
                name: "IssueDate",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropColumn(
                name: "NetworkHospitalTracker",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropColumn(
                name: "PasswordType",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropColumn(
                name: "RHealthAssist",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropColumn(
                name: "RHealthBeat",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropColumn(
                name: "RHealthCircle",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropColumn(
                name: "RiskEndDate",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropColumn(
                name: "RiskStartDate",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropColumn(
                name: "TrackClaims",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropColumn(
                name: "UserNameType",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropColumn(
                name: "ValueDeals",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropColumn(
                name: "ViewECard",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropColumn(
                name: "ViewPolicyCoverage",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.DropColumn(
                name: "Wellness",
                schema: "GhipCP",
                table: "Policy");

            migrationBuilder.CreateTable(
                name: "PolicyAttached",
                schema: "GhipCP",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AdditionOfDependents = table.Column<bool>(type: "bit", nullable: true),
                    ConntactUs = table.Column<bool>(type: "bit", nullable: true),
                    CorporateId = table.Column<int>(type: "int", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DownloadForms = table.Column<bool>(type: "bit", nullable: true),
                    FAQ = table.Column<bool>(type: "bit", nullable: true),
                    GracePeriodType = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    GracePeriodValue = table.Column<int>(type: "int", nullable: true),
                    HRA = table.Column<bool>(type: "bit", nullable: true),
                    HealthOPedia = table.Column<bool>(type: "bit", nullable: true),
                    InsuredName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    IntimateClaims = table.Column<bool>(type: "bit", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    IssueDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Key = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ModifiedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ModifiedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    NetworkHospitalTracker = table.Column<bool>(type: "bit", nullable: true),
                    PasswordType = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PolicyId = table.Column<int>(type: "int", nullable: false),
                    PolicyNumber = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    RHealthAssist = table.Column<bool>(type: "bit", nullable: true),
                    RHealthBeat = table.Column<bool>(type: "bit", nullable: true),
                    RHealthCircle = table.Column<bool>(type: "bit", nullable: true),
                    RiskEndDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    RiskStartDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    TrackClaims = table.Column<bool>(type: "bit", nullable: true),
                    UserNameType = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ValueDeals = table.Column<bool>(type: "bit", nullable: true),
                    ViewECard = table.Column<bool>(type: "bit", nullable: true),
                    ViewPolicyCoverage = table.Column<bool>(type: "bit", nullable: true),
                    Wellness = table.Column<bool>(type: "bit", nullable: true),
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PolicyAttached", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PolicyAttached_Corporates_CorporateId",
                        column: x => x.CorporateId,
                        principalSchema: "GhipGlobal",
                        principalTable: "Corporates",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_PolicyAttached_Policy_PolicyId",
                        column: x => x.PolicyId,
                        principalSchema: "GhipCP",
                        principalTable: "Policy",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_PolicyAttached_CorporateId",
                schema: "GhipCP",
                table: "PolicyAttached",
                column: "CorporateId");

            migrationBuilder.CreateIndex(
                name: "IX_PolicyAttached_PolicyId",
                schema: "GhipCP",
                table: "PolicyAttached",
                column: "PolicyId");

            migrationBuilder.AddForeignKey(
                name: "FK_BrokerPolicyMapping_PolicyAttached_CPPolicyId",
                schema: "GhipCP",
                table: "BrokerPolicyMapping",
                column: "CPPolicyId",
                principalSchema: "GhipCP",
                principalTable: "PolicyAttached",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Employee_PolicyAttached_CPPolicyId",
                schema: "GhipCP",
                table: "Employee",
                column: "CPPolicyId",
                principalSchema: "GhipCP",
                principalTable: "PolicyAttached",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_SMPolicyMapping_PolicyAttached_CPPolicyId",
                schema: "GhipCP",
                table: "SMPolicyMapping",
                column: "CPPolicyId",
                principalSchema: "GhipCP",
                principalTable: "PolicyAttached",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
